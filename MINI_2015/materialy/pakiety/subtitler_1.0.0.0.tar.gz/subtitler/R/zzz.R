.onAttach <- function(libname, pkgname) {
    packageStartupMessage("Welcome to subtitler")
} 
