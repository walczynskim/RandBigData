library(testthat)
library(subtitler)

test_check("subtitler")

expect_equal(10, 10 + 1e-7)
