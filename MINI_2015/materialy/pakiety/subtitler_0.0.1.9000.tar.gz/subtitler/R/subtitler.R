#' subtitler: An Easy Access to the OpenSubtitles Database
#'
#' @docType package
#' @name subtitler
NULL 
