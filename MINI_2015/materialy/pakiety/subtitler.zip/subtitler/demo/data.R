cat("Dzisiaj jest", as.character(Sys.Date()), "\n")

cat("I to jest dobry dzień na ćwiczenia z OpenCPU!!")
