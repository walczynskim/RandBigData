## ----, fig.show='hold'---------------------------------------------------
library(subtitler)
napi <- readSubtitle("http://dl.opensubtitles.org/pl/download/file/1954081967")
head(napi, 30)

