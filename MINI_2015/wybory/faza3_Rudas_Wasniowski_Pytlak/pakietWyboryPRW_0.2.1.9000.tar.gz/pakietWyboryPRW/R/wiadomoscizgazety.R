#' Pobieranie informacji z artykulow z portalu gazeta.pl ktorych daty sa pozniejsze od zadanej
#'
#' Funkcja \code{wiadomoscizgazety} sciaga artykuly z portalu gazeta.pl z zakladki wybory o dacie powstania pozniejszej od zadanej.
#'
#' @usage
#' \code{wiadomoscizgazety(czas)}
#'
#' @param czas czas od ktorego zaczynamy pobieranie (wpisywany jako czas POSIX).
#' @details \code{wiadomoscizgazety} przeszukuje strony artykulow z portalu gazeta.pl, z zakladki wybory, o dacie powstania pozniejszej od zadanej w argumencie.
#' Szuka przydatnych informacji o nich takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, komentarze.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to gazeta.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy z artykulow o dacie pozniejszej od zadanej w argumencie.
#'
#' @examples
#' wiadomoscizgazety(strptime("01-05-2015 10:00","%d-%m-%Y %H:%M"))
#'
wiadomoscizgazety<-function(czas)
{
   #link z zakladki wyborow
   link<-"http://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=wybory+prezydenckie+2015"
   adres<-html(link)
   adres_nodes<-html_nodes(adres,"h2 a")
   #adresy artykulow
   adresy_artykulow<-html_attr(adres_nodes,"href")
   dl<-length(adresy_artykulow)
   #w ta ramke bedziemy zapisywac dane
   informacje<-data.frame()
   for(i in 1:dl)
   {
      #ramka tymczasowa
      temp<-data.frame()
      #Sprobuj pobrac info z artykulu
      try(temp<-gazetapl_artykul_info(adresy_artykulow[i],i),silent=TRUE)
      #Jesli sie udalo to:
      if(length(temp)!=0)
      {
         temp1<-NULL
         #Sprobuj pobrac date
         try(temp1<-strptime(temp$data,"%d-%m-%Y %H:%M"),silent=TRUE)
         #Jesli sie udalo to:
         if(length(temp1)!=0)
         {
            #Jesli data pozniejsza od zadanej to:
            if(unclass(czas-temp1)<=0)
            {
               #Dopisuj do ramki
               informacje<-rbind(informacje,temp)
            }  
         }
         
      }
      
   }
   #Zwroc ramke
   informacje
}