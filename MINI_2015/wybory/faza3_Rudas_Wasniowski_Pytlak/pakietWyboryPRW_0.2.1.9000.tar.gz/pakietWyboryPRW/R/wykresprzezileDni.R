#' zmiana wartosci miary liczba dni z wystapieniami/liczba dni w ogole w czasie
#'
#' Funkcja \code{wykresprzezileDni} rysuje wykres przedstawiajacy zmiane wartosci miary liczba dni z wystapieniami/liczba dni wzgledem czasu.
#'
#' @usage
#' \code{wykresprzezileDni(dane,zrodlo,co,coile,od_ktorego,do_ktorego,ktorzykandydaci=
#' c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param coile wartosc liczbowa co jaki okres czasu liczymy wartosci miary.
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresprzezileDni} rysuje wykres, na osi x mamy czasy, na osi y wartosc miary liczba dni z wystapieniami/liczba dni ogolnie.
#' Dla kazdego czasu liczona jest miara liczba dni z wystapieniami/liczba dni dla wbranych kandydatow, punkty sa laczone liniami (powstaja lamane).
#'
#' @return wykres zaleznosci miedzy wartoscia miary liczba dni z wystapieniami/liczba dni a czasem.
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' wykresprzezileDni(d,"brak","tytul",7,as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
wykresprzezileDni<-function(dane,zrodlo,co,coile,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                         "Wilk","Braun","Kukiz"))
{

   #Co ile dni uzyskujmey wartosci miary
   ruchomy<-od_ktorego
   #Tu przechowujemy wartosci miar
   df<-data.frame()
   #A tu czasy koncowe (zmieniaja sie w kazdym obrocie petli o coile az do osiagniecia dzisiejszego czasu)
   czas<-c()

   while(ruchomy<=do_ktorego)
   {
      temp<-przezileDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                           "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                           "$3-$2-$1"),stri_replace_all_regex(as.character(ruchomy) ,
                                                                                              "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                              "$3-$2-$1"))
      temp1<-as.character(ruchomy)



      ruchomy<-ruchomy+coile
      df<-rbind(df,temp)
      czas<-c(czas,temp1)
   }
   kolory<-c("black","yellow","blue","red","purple","green","brown","orange","magenta","cyan")
   names(kolory)<-c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                    "Wilk","Braun","Kukiz")
   colnames(df)<-names(kolory)
   df<-cbind(czas,df)
   for(i in 2:11)
   {
      df[,i]<-df[,i]+0.00005*i*(-1)^i
   }

   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tylko tych ktorzy nas interesuja
   df<-df[,c("czas",ktorzykandydaci,"id")]
   #kolory wykresow

   kolory<-kolory[ktorzykandydaci]
   dfm <- melt(df, id.var = c("id","czas"))
   #wykres
   p<-ggplot(dfm, aes(czas,value,group= variable,colour = variable)) +geom_line()+scale_colour_manual(values=kolory)+
      ggtitle("liczba dni wystapien/liczba dni vs czas") +
      theme(plot.title = element_text(size = 16))
   p+xlab("czas") + ylab("liczba dni wystapien/liczba dni")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
