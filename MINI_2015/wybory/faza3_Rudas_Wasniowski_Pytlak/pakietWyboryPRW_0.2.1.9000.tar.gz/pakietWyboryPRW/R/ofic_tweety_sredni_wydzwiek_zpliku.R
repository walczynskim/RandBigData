#' Wyliczenie sredniego wydzwieku tweetow umieszczanych na oficjalnych profilach kanydatow, w podziale na dni 
#' 
#' Funkcja \code{ofic_tweety_sredni_wydzwiek_zpliku} na podstawie plikow tekstowych zawierajacych oficjalne tweety poszczegolnych kandydata wylicza sredni wydzwiek tych tweetow w podziale na dni. Wyniki zapisuje je w oddzielnych plikach tekstowych. 
#' 
#' @usage \code{ofic_tweety_sredni_wydzwiek_zpliku(katalog, sciezka_slownik)}
#' 
#' @param katalog sciezka do katalogu, w ktorym przechowywane sa pliki z tweetami
#' @param sciezka_slownik sciezka do pliku w formacie .csv ze slownikem wydzwieku pobranym ze strony "http://zil.ipipan.waw.pl/SlownikWydzwieku"
#' 
#' @return lista nazwana
#' 
#' @examples 
#' katalog1 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\faza3\\oficjalne_tweety\\sentyment_ofic"
#' sciezka_slownik1 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\slownik_wydzwieku.csv"
#' ofic_tweety_sredni_wydzwiek_zpliku(katalog1, sciezka_slownik1)
#' 
#' @import stringi
#'   


ofic_tweety_sredni_wydzwiek_zpliku <- function(katalog, sciezka_slownik){
   
   setwd(katalog)
   
   kandydaci <- c("Andrzej_Duda", "Bronislaw_Komorowski", 
                  "Magdalena_Ogorek", "Adam_Jarubas", "Janusz_Palikot", 
                  "Janusz_Korwin-Mikke", "Pawel_Kukiz")
   
   #wczytujemy slownik wydzwieku
   slownik <- read.table(sciezka_slownik, fileEncoding = "utf-8")
   
   sredni_wydzwiek <- list()
   
   #dla kazdego tweeta poszczegolnych kandydatow wyliczamy wydzwiek wypowiedzi 
   for(i in seq_along(kandydaci)){
      nazwisko <- read.table(stri_paste(katalog, "\\", kandydaci[i], ".txt"), 
                             header = TRUE, sep = "", row.names = NULL)
      teksty <- nazwisko$row.names
      male <- stri_trans_tolower(teksty)
      bez_n <- stri_replace_all_regex(male, "\n", " ") 
      nie_adresy <- stri_replace_all_regex(bez_n, 
                                           "http(s?)\\S* | http(s?)\\S*", "")
      slowa <- stri_extract_all_words(nie_adresy)
      
      n <- length(slowa)
      wydzwieki <- numeric(n)
      
      for(j in seq_along(slowa)){
         m <- length(slowa[[j]])
         wydzwiek <- numeric(m)
         for(k in seq_along(slowa[[j]])){
            indeks <- which(slownik[, 1] == slowa[[j]][k])
            if(length(indeks) > 0){
               wydzwiek[k] <- slownik[indeks, 5]
            } else {
               wydzwiek[k] <- 0
            }
         }
         wydzwieki[j] <- sum(wydzwiek)
      }
      
      nazwisko$wydzwiek <- wydzwieki
      dzien <- nazwisko$retweety
      
      #dla kazdego kandydata wyliczamy sredni wydzwiek wypowiedzi w podziale na dni
      rozdziel <- split(nazwisko$wydzwiek, dzien)
      sredni_wydzwiek[[i]] <- sapply(rozdziel, mean)
      
      #wyniki zapisujemy w oddzielnych plikach tekstowych
      write.table(sredni_wydzwiek[[i]], 
                  file = stri_paste("wydzwiek-", kandydaci[i], ".txt"))
   }
   
   #generujemy nazwana liste
   structure(sredni_wydzwiek, 
             names = c("Andrzej Duda", "Bronislaw Komorowski", 
                       "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", 
                       "Janusz Korwin-Mikke", "Pawel Kukiz"))
}


