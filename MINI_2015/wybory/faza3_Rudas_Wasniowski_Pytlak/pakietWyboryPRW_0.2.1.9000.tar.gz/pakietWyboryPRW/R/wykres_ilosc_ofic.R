
wykres_ilosc_ofic <- function(katalog, kandydaci, data_od, data_do){
   
   ilosc_na_dzien <- list()
   
   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   nazwy_plikow <- c("Andrzej_Duda", "Bronislaw_Komorowski", "Magdalena_Ogorek", 
                     "Adam_Jarubas", "Janusz_Palikot", "Janusz_Korwin-Mikke", 
                     "Pawel_Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          nazwa_pliku = nazwy_plikow, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   wybrani <- zbiorcze[ktorzy, ]
   
   for(i in seq_along(wybrani$nazwa_pliku)){
      
      wczytaj_plik <- read.table(stri_paste(katalog, "\\ilosc-", 
                                            wybrani$nazwa_pliku[i], ".txt"), 
                                 header = FALSE, sep = "", row.names = NULL)
      
      n <- nrow(wczytaj_plik)
      
      liczba_tweetow <- data.frame(kandydat = rep(wybrani$nazwisko[i], n), 
                                   data = as.Date(wczytaj_plik$V1), 
                                   ilosc = wczytaj_plik$V2)
      
      daty <- liczba_tweetow$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      liczba_tweetow_od_do <- liczba_tweetow[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(wybrani$nazwisko[i], m), 
                                    data = brakujace_dni, ilosc = rep(0, m))
         
         ilosc_na_dzien[[i]] <- rbind(liczba_tweetow_od_do, brak_tweetow)
      }
   }
   
   duza_ramka <- do.call("rbind", ilosc_na_dzien)
   
   #duza_ramka$data <- as.Date(duza_ramka$data)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = ilosc, col = kandydat)) + geom_line() + 
      ggtitle("Liczba oficjalnych tweetow na dzien") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("liczba tweetow") + scale_colour_manual(values = wybrane_kolory)
}


