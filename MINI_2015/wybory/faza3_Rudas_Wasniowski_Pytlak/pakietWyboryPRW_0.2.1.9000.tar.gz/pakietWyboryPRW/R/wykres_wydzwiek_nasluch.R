
wykres_wydzwiek_nasluch <- function(katalog, kandydaci, data_od, data_do){

   wydzwiek_na_dzien <- list()
   
   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   nazwy_plikow <- c("Andrzej_Duda", "Bronislaw_Komorowski", "Magdalena_Ogorek", 
                  "Adam_Jarubas", "Janusz_Palikot", "Janusz_Korwin-Mikke", 
                  "Pawel_Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          nazwa_pliku = nazwy_plikow, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   wybrani <- zbiorcze[ktorzy, ]
   
   for(i in seq_along(wybrani$nazwa_pliku)){
      
      wczytaj_plik <- read.table(stri_paste(katalog, "\\nasluch_wydzwiek-", 
                                            wybrani$nazwa_pliku[i], ".txt"), 
                                 header = TRUE, sep = "", row.names = NULL)
      
      n <- nrow(wczytaj_plik)
      
      wydzwiek_tweety <- data.frame(kandydat = rep(wybrani$nazwisko[i], n), 
                                        data = as.Date(wczytaj_plik$row.names), 
                                        wydzwiek = wczytaj_plik$x)
      
      daty <- wydzwiek_tweety$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      wydzwiek_tweety_od_do <- wydzwiek_tweety[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(wybrani$nazwisko[i], m), 
                                    data = brakujace_dni, wydzwiek = rep(0, m))
         
         wydzwiek_na_dzien[[i]] <- rbind(wydzwiek_tweety_od_do, brak_tweetow)
      }
   }
   
   duza_ramka <- do.call("rbind", wydzwiek_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = wydzwiek, col = kandydat)) + geom_line() + 
      ggtitle("Tweety z nasluchu - sredni wydzwiek na dzien (w skali od -2 do 2)") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("srednia wartosc wydzwieku") + scale_colour_manual(values = wybrane_kolory)
}








