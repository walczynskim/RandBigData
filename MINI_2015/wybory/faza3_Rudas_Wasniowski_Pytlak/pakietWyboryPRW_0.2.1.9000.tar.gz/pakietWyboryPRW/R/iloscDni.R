#' Wyznaczenie maksymalnej serii/liczby serii dla kandydatow
#'
#' Funkcja \code{iloscDni} wyznacza maksymalna dlugosc serii dla kazdego kandydata lub liczbe serii o zadanej dlugosci.
#'
#' @usage
#' \code{iloscDni(dane,podajzrodlo,co,datapocz,datakonc,maks=TRUE,dlserii=2)}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param podajzrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow: dostepne wartosci "tytul","tagi","tresc".
#' @param datapocz data w postaci napisu dd-mm-YYYY od ktorej rozpatrujemy artykuly (wczesniejszych nie bierzemy pod uwage).
#' @param datakonc data data w postaci napisu dd-mm-YYYY do ktorej rozpatrujemy artykuly (pozniejszych nie bierzemy pod uwage).
#' @param maks wartosc logiczna czy bierzemy maksymlana dlugosc(TRUE) czy liczbe serii (FALSE).
#' @param dlserii wartosc liczbowa liczymy liczbe serii o dlugosci zadaniej przez ten argument.
#' @details \code{iloscDni} zwraca albo maksymalna dlugosc serii albo liczbe serii o zadanej dlugosci. Seria
#' jest rozumiana jako ciag dni pod rzad, taki ze kazdego dnia kandydat byl widoczny
#'
#' @return jesli maks=TRUE zwraca wektor maksymalnych dlugosci serii dla poszczegolnych kandydatow, jesli
#' maks=FALSE wowczas zwraca wektor liczby serii o zadanej dlugosci dla kazdego kandydata.
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' iloscDni(d,"gazeta.pl","tytul",datapierwszgopobrania(d,"gazeta.pl"),aktualnydzien())
#' iloscDni(d,"brak","tagi",datapierwszgopobrania(d,"brak"),aktualnydzien())
#'
iloscDni<-function(dane,podajzrodlo,co,datapocz,datakonc,maks=TRUE,dlserii=2)
{
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   #Przerobienie na POSIX
   pocz<-strptime(datapocz,"%d-%m-%Y")
   konc<-strptime(datakonc,"%d-%m-%Y")


   #Jesli podajzrodlo!="brak" to rozpatrujemy z podanego zrodla
   if(podajzrodlo!="brak")
   {
      danegazeta<-dane[dane$zrodlo==podajzrodlo,]
   }
   else
   {
      danegazeta<-dane
   }
   #wektor zliczajacy dlugosc maksymalnej serii dla danego kandydata
   maksymalnadlugosc<-rep(0,length(kandydat))
   names(maksymalnadlugosc)<-nazwiska
   #wektor zliczajacy liczbe seri o dlugosci niemniejszej niz dlserii
   liczba<-rep(0,length(kandydat))
   names(liczba)<-nazwiska
   for(i in 1:length(kandydat))
   {
      #czasy artykulow kandydatow
      artykulykandydatow<-danegazeta[stri_detect_regex(danegazeta[,co],kandydat[i]),]$data
      artykulykandydatow <- stri_replace_all_regex(artykulykandydatow ,
                                                   "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                   "$3-$2-$1")

      times<-unique(sort(strptime(artykulykandydatow, "%d-%m-%Y")))
      #chcemy miec tylko z zadanego przedzialu czasowego
      times<-times[which(times>=pocz&times<=konc)]

      if (length(times)!=0)
      {
         #jesli mamy dlugosc times rowna 1 to mamy tylko serie dlugosci 1
         if(length(times)==1)
         {
            maksymalnadlugosc[i]<-1
            if(dlserii==1)
            {
               liczba[i]<-1
            }
            else
            {
               liczba[i]<-0
            }

         }
         else
         {
            times1<-times[-1]
            times2<-times[-length(times)]
            iledni<-ceiling(as.numeric(times1-times2,unit="days"))

            #iterator petli
            j<-1
            #zmienna pomocnicza zliczajaca aktualna dlugosc serii
            pom<-0
            #zmienna pomocnicza zliczajaca dlugosci serii dla kandydata
            wektorilosci<-c()
            while(j<=length(iledni))
            {
               if(iledni[j]==1)
               {
                  pom<-pom+1
                  if(j==length(iledni))
                  {
                     wektorilosci<-c(wektorilosci,pom)
                  }
               }
               else
               {
                  wektorilosci<-c(wektorilosci,pom)
                  pom<-0
               }
               if(pom+1>maksymalnadlugosc[i])
               {
                  maksymalnadlugosc[i]<-pom+1
               }
               j<-j+1

            }
            wektorilosci<-wektorilosci+1
            #wybierz tylko te ktore maja wartosc nie mniejsza niz dlserii
            liczba[i]<-length(wektorilosci[wektorilosci>=dlserii])


         }
      }


   }
   if(maks)
   {
      maksymalnadlugosc
   }
   else
   {
      liczba
   }

}
