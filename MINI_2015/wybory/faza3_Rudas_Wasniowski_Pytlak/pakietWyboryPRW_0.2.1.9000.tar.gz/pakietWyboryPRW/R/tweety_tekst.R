
tweety_tekst <- function(sciezka_wejscie, sciezka_wyjscie){
   
   # przeksztalcamy plik w formacie .json na ramke danych
   parsuj <- parseTweets(sciezka_wejscie, simplify = FALSE, verbose = TRUE)
   
   # niektore sposrod pobranych tweetow nie dotyczylo kandydatow na prezydenta, 
   # a np. pilkarzy; w tym celu postanowiono zlokalizowac podejrzane tweety, 
   # poprzez wpisanie pewnych slow kluczowych zwiazanych z polska liga pilki
   # noznej
   wykryjInne <- lapply(parsuj$text, function(x) 
      stri_detect_regex(x, 
                        c("Ondrej Duda", "Ondreja Dudy", "Ondrejowi Dudzie", 
                          "Ondreja Dudę", "Ondreja Dude", "Ondrejem Dudą", 
                          "Ondrejem Duda", "Ondreju Dudzie", 
                          "Marcin Komorowski", "Marcina Komorowskiego", 
                          "Marcinowi Komorowskiemu", "Marcinem Komorowskim", 
                          "Marcinie Komorowskim", "LegiaWarszawa", "Legia", 
                          "Legii", "Legię", "Legie", "Legią", 
                          "Legia Warszawa", "mecz", "meczu", "meczowi", 
                          "meczem", "KoltonRoman", "piłka", "pilka", 
                          "piłki", "pilki", "piłce", "pilce", "piłkę", 
                          "pilke", "piłką", "Ekstraklasa", "Ekstraklasy", 
                          "Ekstraklasie", "Ekstraklasę", "Ekstraklase", 
                          "Ekstraklasą", "bramka", "bramki", "bramce", 
                          "bramkę", "bramką", "gol", "gola", "golem", 
                          "golu", "Żyro", "Zyro", "uzupełnienia", 
                          "napastnik", "napastnika", "napastnikowi", 
                          "napastnikiem", "napastniku", "Dossa Junior", 
                          "Kuciak", "Kuciaka", "Kuciakowi", "Kuciakiem", 
                          "Kuciaku", "Jałocha", "Jalocha", "Jałochy", 
                          "Jalochy", "Jałosze", "Jalosze", "Jałochę", 
                          "Jaloche", "Jałochą", "Jalocha", "Lewczuk", 
                          "Lewczuka", "Lewczukowi", "Lewczukiem", 
                          "Lewczuku", "Wieteska", "Wieteski", "Wietesce", 
                          "Wieteskę", "Wieteske", "Wieteską", "Astiz", 
                          "Astiza", "Astizowi", "Astizem", "Astizie", 
                          "Brzyski", "Brzyskiego", "Brzyskiemu", "Brzyskim", 
                          "Broź", "Brozia", "Broziowi", "Broziem", "Broziu", 
                          "Marques", "Marquesa", "Marquesowi", "Marquesem", 
                          "Marquesie", "Szwoch", "Szwocha", "Szwochowi", 
                          "Szwochem", "Szwochu", "Vrdoljak", "Vrdoljaka", 
                          "Vrdoljakowi", "Vrdoljakiem", "Vrdoljaku", 
                          "Pinto", "Bartczak", "Bartczaka", "Bartczakowi", 
                          "Bartczakiem", "Bartczaku", "Saganowski", 
                          "Saganowskiego", "Saganowskiemu", "Saganowskim", 
                          "Ryczkowski", "Ryczkowskiego", "Ryczkowskiemu", 
                          "Ryczkowskim", "Orlando Sa", "Henning Berg", 
                          "Jodłowiec", "Jodlowiec", "Jodłowca", "Jodlowca", 
                          "Jodłowcu", "Jodlowcu", "Jodłowcowi", 
                          "Jodlowcowi", "Jodłowcem", "Jodlowcem")))
   
   # ustalamy indeksy tych tweetow, ktore z duzym prawdopobienstwem dotycza
   # wyborow prezydenckich
   prawidlowe <- unlist(lapply(wykryjInne, function(y) all(y == FALSE)))
   tweetyWybory <- parsuj$text[prawidlowe == TRUE]
   ktore <- which(parsuj$text %in% tweetyWybory)
   
   # zmieniamy format daty na bardziej przyjazny
   moje_locale <- Sys.setlocale("LC_TIME")
   Sys.setlocale("LC_TIME", "English")
   data_tweeta <- strptime(parsuj$created_at, "%a %b %d %H:%M:%S %z %Y")
   od_kiedy <- strptime(parsuj$user_created_at, "%a %b %d %H:%M:%S %z %Y")
   Sys.setlocale("LC_TIME", moje_locale)
   
   #wyciagamy dane na temat urzadzenia, z ktorego zostal wyslany tweet 
   zrodla_brudno <- parsuj[,7]
   zrodla <- unlist(stri_extract_all_regex(zrodla_brudno, "(?<=>).+(?=</a>)"))
   
   # tworzymy ramke danych zawierajaca tresci tweetow, jak rowniez podstawowe
   # informacje na temat autora, czasu powstania wiadomosci, lokalizacji oraz 
   # liczby uzytkownikow obserwujacych danego autora
   ramka <- data.frame(tekst = tweetyWybory, 
                       ktory_retweet = parsuj$retweet_count[ktore],
                       czy_ulubiony = parsuj$favorited[ktore],
                       zrodlo = zrodla[ktore], 
                       data = data_tweeta[ktore],
                       lokalizacja = parsuj$location[ktore], 
                       data_zalozenia = od_kiedy[ktore],
                       obserwujacy = parsuj$followers_count[ktore], 
                       autor = parsuj$name[ktore],
                       nick = parsuj$screen_name[ktore],
                       stringsAsFactors = FALSE)

   f <- file(sciezka_wyjscie, open = "a")
   
   write.table(ramka, file = f, append = FALSE, quote = TRUE, sep = " ", 
                  row.names = FALSE, col.names = TRUE)
   
   close(f)
}

