#' Tworzenie folderow na dane/wypelnanie folderow danymi
#'
#' Funkcja \code{dodajdane} tworzy foldery na dane pobierane z portali i na czas ostatniego pobierania
#' i aktualizuje pliki z danymi i z data ostatniego pobierania przy kazdym pobieraniu.
#'
#' @usage
#' \code{dodajdane(path)}
#'
#' @param path napis bedacy sciezka dostepu do folderu w ktorym utworzymy folder przechowujacy dane.
#' @details \code{dodajdane} tworzy w zadanej lokalizacji (jesli jeszcze nie ma) folder projekt_wybory_R_i_big_data. W nim znajduja
#' sie dwa foldery czas i artykuly. W folderze czas zostaje utworzony plik tekstowy o nazwie czas.txt z czasem w ktorym funkcja zostala wywolana.
#' Jesli folder projekt_wybory_R_i_big_data istnieje, wowczas jesli jest to pierwsze pobieranie danych, funckja
#' w folderze artykuly tworzy plik tekstowy z pobranymi danymi o nazwie artykuly.txt i uaktualnia plik czas.txt
#' zmieniajac date ktora byla na date ostatniego wywolania funkcji. Pobierane sa dane ze zrodel wp.pl, onet.pl,
#' gazeta.pl i tvn24.pl. Pobierane sa dane z tych artykulow ktorych daty byly pozniejsze od tej, ktora byla uprzednio
#' w pliku czas.txt. Jesli jest to kolejne pobieranie to swiezo pobrane dane sa dolaczane do istniejacego pliku artykuly.txt.,
#' a plik czas.txt jest aktualizowany jak poprzednio.
#'
#' @return Nie zostaje zwrocona zadna wartosc.
#'
#' @examples
#' dodajdane(getwd())
#'
dodajdane<-function(sciezka)
{
   #Sciezka do folderu projekt_wybory_R_i_big_data
   do_pliku<-file.path(sciezka,"projekt_wybory_R_i_big_data")
   #Jesli  mamy folder projekt_wybory_R_i_big_data
   if(file.exists(do_pliku))
   {
      #Sciezka do folderu czas (bedacym w folderze projekt_wybory_R_i_big_data)
      do_czasu_txt<-file.path(do_pliku,"czas","czas.txt")
      #Pobierz czas od ostatniego pobierania/utworzenia folderow
      czas<-readLines(do_czasu_txt)
      czas<-strptime(czas,"%Y-%m-%d %H:%M")
      #Pobieraj informacje z portali
      df_onet<-wiadomoscizonet(czas)
      df_wp<-wiadomoscizwp(czas)
      df_tvn24<-wiadomosciztvn24(czas)
      df_gaz<-wiadomoscizgazety(czas)
      #Ramka do ktorej wkladamy wszystkie nowopobrane
      df1<-data.frame()
      if(length(df_onet)!=0)
      {
         df1<-rbind(df1,df_onet)
      }
      if(length(df_wp)!=0)
      {

         df1<-rbind(df1,df_wp)


      }
      if(length(df_tvn24)!=0)
      {

         df1<-rbind(df1,df_tvn24)


      }
      if(length(df_gaz)!=0)
      {
         df1<-rbind(df1,df_gaz)

      }
      #jesli cos sie pobralo to:
      if(length(df1)!=0)
      {
         #przenominujmy id aby sie nie powtarzaly
         df1$id<-1:nrow(df1)
         #popraw rownames
         rownames(df1)<-df1$id
         #tworzymy sciezke do majacego powstac/powstalego pliku artykuly.txt(bedacego/majacego byc w folderze artykuly)
         do_tresci_txt<-file.path(do_pliku,"artykuly","artykuly.txt")
         #Jesli jest to kolejne(nie pierwsze pobieranie to)
         if(file.exists(do_tresci_txt))
         {
            #Zczytujemy co bylo
            d<-read.table(do_tresci_txt)
            #patrzymy ile dotychczas bylo artykulow
            liczbaart<-nrow(d)
            #zmieniamy id pobranych aby byla unikatowosc id
            df1$id<-(liczbaart+1):(nrow(df1)+liczbaart)
            #popraw rownames
            rownames(df1)<-df1$id
            #nie chcemy, zeby znow dodawalo nazwy kolumn
            names(df1)<-NULL


         }
         #dodaj pobrane do istniejacego pliku/utworz plik z danymi
         write.table(df1,do_tresci_txt,append=TRUE)

      }
      #Aktualizuj czas
      czas<-Sys.time()
      czas<-strftime(czas,"%Y-%m-%d %H:%M:%S")
      writeLines(czas,do_czasu_txt)
   }
   #Jesli nie ma folderu projekt_wybory_R_i_big_data
   else
   {
      #Utworz ten folder
      dir.create(do_pliku)
      #Utworz sciezke do folderu artykuly (majacego powstac w folderze projekt_wybory_R_i_big_data)
      do_tresci<-file.path(do_pliku,"artykuly")
      #Utworz w nim folder artykuly
      dir.create(do_tresci)
      #Utworz sciezke do folderu czas (majacego powstac w folderze projekt_wybory_R_i_big_data)
      do_czasu<-file.path(do_pliku,"czas")
      #Utworz w nim folder czas
      dir.create(do_czasu)
      odroznik<-Sys.time()
      odroznik1<-strftime(odroznik,"%Y-%m-%d %H:%M:%S %Z")
      #Utworz sciezke do pliku czas.txt (majacego powstac w folderze czas)
      do_czasu_txt<-file.path(do_czasu,"czas.txt")
      #W folderze czas utworz plik czas.txt z aktualnym czasem
      writeLines(odroznik1,do_czasu_txt)
   }

}

