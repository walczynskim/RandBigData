#` Wykres liczby wyst�pien kandydata z podzia�em na dni
#'
#' Funkcja \code{wykres_ile_dziennie} rysuje liczbe wystapien nazwiska kandydata 
#' w tytule lub w tresci z podzia�em na dni
#' 
#' @param dane dane o artyku�ach z portali
#' @param co gdzie nazwsiko kandydata ma by� wyszukiwane (tytul, tresc)
#' @param zrodlo1 napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly 
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl",
#' "brak"
#' @param od.daty data, od ktorej rysujemy wykres
#' @param od.daty data, do ktorej rysujemy wykres
#' @param ktorzykandydaci ktorych kandydatow chcemy widziec na wykresie
#' 
#' @examples 
#' ## Not run:
#' wykres_ile_dziennie(dane, co="tytul", od_kiedy=as.Date("01-04-2015"))
#' wykres_ile_dziennie(dane, "tresc",zrodlo1 = "tvn24.pl",
#'                    ktorzykandydaci=c("Korwin-Mikke", "Kukiz"))
#' ## End(**Not run**)
#' 
#' @import dplyr
#' @import stringi
#' @import ggplot2
#' @import tidyr
#' @import scales

wykres_ile_dziennie<-function(dane, co, zrodlo1="brak", 
                              od_kiedy=as.Date("12-03-2015", "%d-%m-%Y"),
                              do_kiedy=as.Date("14-05-2015", "%d-%m-%Y"),
                              ktorzykandydaci=c("Komorowski","Kowalski",
                                                "Duda", "Palikot", "Jarubas",
                                                "Ogorek", "Korwin-Mikke","Wilk",
                                                "Braun","Kukiz")) {

   
   # przefiltrowanie danych
   if (!(zrodlo1=="brak")){
      dane<-dplyr::filter(dane, zrodlo==zrodlo1)
   }
   w<-ile_dziennie(dane, co, FALSE)
   
   w<-w[, c("dzien", ktorzykandydaci)]
   w<-gather(w, kandydat, wartosc,-dzien)
   w<-mutate(w, dzien= as.Date(w$dzien, "%d-%m-%Y"))
      
   # wybieramy interesujace nas daty:
   w<-filter(w,dzien>=od_kiedy, dzien<=do_kiedy)
   
   kolory<-c("black","yellow","blue","red","purple","green","brown","orange",
             "magenta","cyan")
   names(kolory)<-c("Komorowski","Kowalski", "Duda", "Palikot", 
                    "Jarubas", "Ogorek", "Korwin-Mikke","Wilk","Braun","Kukiz")
   kolory<-kolory[names(kolory) %in% ktorzykandydaci]
   
   if (co == "tytul"){
      tytul_wyk<-"Nazwiska w tytule na dzie�"
   } else {
      tytul_wyk<-"Nazwiska w tresci na dzie�"
   }
   if (zrodlo1 != "brak"){
      tytul_wyk<-paste0(tytul_wyk," dla ", zrodlo1)
   }
   xlab1<-paste0("do dnia ", strftime(od_kiedy), " do dnia ", strftime(do_kiedy))
   p<-ggplot(w, aes(dzien, wartosc, group= kandydat, colour=kandydat))+
      geom_line()+
      scale_colour_manual(values=kolory)+
      scale_x_date()+
      ggtitle(tytul_wyk)+
      xlab(xlab1)+
      ylab("liczba wystapien")
   p
}



