#' Wyszukiwanie informacji z portalu wp.pl z zakladki wybory
#'
#' Funkcja \code{wp_artykul_info} sciaga artykuly z portalu wp.pl z zakladki wybory.
#'
#' @usage
#' \code{wp_artykul_info(link,id)}
#'
#' @param link napis bedacy linkiem do strony danego artykulu z portalu wp.pl(struktura linku jak w przykladzie).
#' @param id liczba bedaca id  pobranego artykulu (aby pobrane dane byly uporzadkowane).
#' @details \code{wp_artykul_info} przeszukuje strone danego artykulu z portalu wp.pl szukajac
#' przydatnych informacji o nim takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, liczba komentarzy.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to wp.pl) czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy.
#'
#' @examples
#' wp_artykul_info("http://wiadomosci.wp.pl/kat,140394,title,Panstwowa-Komisja-Wyborcza-na-godz-12-frekwencja-1461-proc,wid,17525931,wiadomosc.html",1)
#'
wp_artykul_info<-function(link,id){
   adresartykulu<-html(link)
   #Pobierz czas
   czas<-html_text(html_nodes(adresartykulu,"time")[[1]],encoding="UTF-8")
   #Pobierz date
   data<-unlist(stri_extract_all_regex(czas,"[0-9]{4}\\.[0-9]{2}\\.[0-9]{2}"))
   data<-stri_replace_all_regex(data,"\\.","-")
   #Pobierz godzine
   godzina<-unlist(stri_extract_all_regex(czas,"[0-9]{2}:[0-9]{2}"))
   czas<-stri_paste(data,godzina,sep=" ")
   
   #Pobierz zrodlo
   zrodlo<-"wiadomosci.wp.pl"
   #Pobierz tytul
   tytul<-html_text(html_nodes(adresartykulu,".fullWidth .h1")[[1]],encoding="UTF-8")
   #Pobierz tagi
   tagi<-html_text(html_nodes(adresartykulu,".fullWidth .ST-BX-Tagi-dol a"),encoding="UTF-8")
   tagi<-stri_paste(tagi,collapse = "-")
   
   
   #Pobierz tresc
   tresc1<-html_nodes(adresartykulu,".lead")[[1]]%>%html_text(encoding="UTF-8")
   tresc<-html_nodes(adresartykulu,"section.artCnt:nth-child(1) > main:nth-child(3) > div:nth-child(4)")   
   tresc<-stri_replace_all_regex(html_text(tresc,encoding="UTF-8"),"(if(\\n|.)+\\}|\\n|\\r|\\t)","")
   tresc<-stri_paste(tresc1,tresc)
   
   #Pobierz liczbe komentarzy
   liczba_kom<-html_text(html_nodes(adresartykulu,"#stgOpinie .opStron+ .opNNav .opAllCom"))
   if (length(liczba_kom)==0){
      liczba_kom<-html_text(html_nodes(adresartykulu,"#opOpinie+ .opNNav .opAllCom"))
   }
   liczba_kom<-unlist(stri_extract_all_regex(liczba_kom,"[0-9]+"))
   #Zwroc ramke danych
   data.frame("id"=id,"zrodlo"=zrodlo,"data"=czas,"tytul"=tytul,"tresc"=tresc,
              "tagi"=tagi,"liczba komentarzy"=liczba_kom)
   
}