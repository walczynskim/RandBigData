#' Boxploty liczby komentarzy dla kandydatow
#'
#' Funkcja \code{wykres_komentarzy} rysuje boxploty dla liczby komentarzy, 
#' dla artykulow, w ktorych wystapilo nazwisko kandydata 
#' 
#' @param dane dane o artyku�ach z portali
#' @param co gdzie nazwsiko kandydata ma by� wyszukiwane (tytul, tresc)
#' @param Zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly 
#' dostepne wartosci: "gazeta.pl", "tvn24.pl", "wiadomosci.wp.pl", "wiadomosci.onet.pl",
#' "brak"
#' @param od_ktorego data, od ktorej bierzemy artykuly
#' @param do_ktorego data, do ktorej bierzemy artykuly
#' @param ktorzykandydaci ktorych kandydatow chcemy widziec na wykresie
#' 
#' @examples 
#' ## Not run:
#' wykres_komentarzy(dane,co="tresc",Zrodlo="gazeta.pl", 
#'                ktorzykandydaci=c("Komorowski","Kowalski", "Duda"))
#' wykres_komentarzy(dane, Zrodlo="wiadomosci.wp.pl", co="tresc",
#'                   od_ktorego=as.Date("12-03-2015", "%d-%m-%Y"),
#'                   do_ktorego=as.Date("12-05-2015", "%d-%m-%Y"),
#'                   ktorzykandydaci=c("Komorowski","Kowalski"))
#' wykres_komentarzy(dane,co="tytul",Zrodlo="gazeta.pl"),
#'                        ktorzykandydaci=c("Komorowski","Duda"))
#' ## End(**Not run**)
#' 
#' @import dplyr
#' @import stringi
#' @import ggplot2
#' @import tidyr
#' @import scales

wykres_komentarzy<-function(dane, co="tresc",
                            Zrodlo="brak",
                            od_ktorego=as.Date("12-03-2015", "%d-%m-%Y"),
                            do_ktorego=as.Date("14-05-2015", "%d-%m-%Y"),
                            ktorzykandydaci=c("Komorowski","Kowalski",
                                              "Duda", "Palikot", "Jarubas",
                                              "Ogorek", "Korwin-Mikke","Wilk",
                                              "Braun","Kukiz")) {
   
   
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski", "Duda", "Palikot", "Jarubas", "Ogorek", 
                 "Korwin-Mikke","Wilk","Braun","Kukiz")
   names(kandydat) <- nazwiska
   
   # przefiltrowanie danych zrodle
   if (!(Zrodlo=="brak")){
      dane<-dplyr::filter(dane, zrodlo==Zrodlo)
   }
   # przefiltrowanie danych po dacie
   daty<-stri_replace_all_regex(dane$data, "([0-9]{4})-([0-9]{2})-([0-9]{2})", "$3-$2-$1")
   daty<-as.Date(daty,"%d-%m-%Y")
   dane<-dane[daty >= od_ktorego & daty<=do_ktorego ,]
   
   #funkcja pomocnicza 
   kto_w_tresci <- function(dane){
      kandydat <- c(
         "Komorowski\\p{L}*",
         "Marian(\\p{L})* Kowalsk(\\p{L})*",
         "(Dud(\\p{L})*)",
         "Paliko(\\p{L})*",
         "Jarubas(\\p{L})*",
         "Og�rek|Ogórek",
         "Korwin(\\p{L})*",
         "Wilk(\\p{L})*",
         "Braun(\\p{L})*",
         "Kukiz(\\p{L})*"
      )
      nazwiska <- c("Komorowski","Kowalski", "Duda", "Palikot", "Jarubas", "Ogorek", 
                    "Korwin-Mikke","Wilk","Braun","Kukiz")
      names(kandydat) <- nazwiska
      
         czy_nazwisko<-lapply(kandydat,function(x){
            stri_count_regex(dane$tresc,x)
         })
         cbind(dane, czy_nazwisko)
      }
   
   # funkcja pomocnicza  
   komentarze <- function(dane, fun=mean, co, po.zrodle = TRUE){
      if (co == "tytul"){
         d<-kto_w_tyt(dane)
      } else {
         d<-kto_w_tresci(dane)
      }

      
      if (po.zrodle) {
         zrodla <- unique(d$zrodlo)
         d3<-data.frame()
         for (i in 1:length(zrodla)){
            d2 <- d[d$zrodlo == zrodla[i],]
            f <- sapply(names(kandydat),function(x){
               j <- which(d2[,x]>0)
               fun(d[j,"liczba.komentarzy"])
            })
            d3 <- rbind(d3,f)
         }
         names(d3) <- names(kandydat)
         d3 <- cbind(zrodla,d3)
      } else {
         d3 <- lapply(names(kandydat), function(x){
            j <- which(d[, x]>0)
            fun(d[j, "liczba.komentarzy"])
         })
      }
      names(d3)<-names(kandydat)
      d3
   }
   
   
   # oblicznie wskaznika
   k<-komentarze(dane,c, co ,po.zrodle = FALSE)
   # polaczenie wszystkiego w ramke danych
   w<-data.frame()
   for (i in 1:10){
      if (length(k[[i]])>0){
         temp<-cbind(names(k[i]),k[[i]])
         w<-rbind(w,temp)
      }
   }
   
   names(w)<-c("kandydat","ile")
   
   # wybranie interesujachy nas kandydatow:
   w<-filter(w, kandydat %in% ktorzykandydaci )
   w$ile<-as.numeric(levels(w$ile)[w[,2]])
   tytul_wyk<-"Boxploty liczby komentarzy"
   if (Zrodlo!= "brak"){
      tytul_wyk<-paste0(tytul_wyk," dla ", Zrodlo)
   }
   xlab1<-stri_paste("od dnia", strftime(od_ktorego), "do dnia", 
                     strftime(do_ktorego), sep=" ")
   
   # narysowanie wykresu
   ggplot(w,aes(x=kandydat, y=ile)) +
      geom_boxplot()+
      ylab("Liczba komentarzy")+
      xlab(xlab1)+
      ggtitle(tytul_wyk)

}




