#' Pobieranie informacji z artykulow z portalu onet.pl ktorych daty sa pozniejsze od zadanej
#'
#' Funkcja \code{wiadomoscizonet} sciaga artykuly z portalu onet.pl z zakladki wybory o dacie pozniejszej od zadanej.
#'
#' @usage
#' \code{wiadomoscizonet(czas)}
#'
#' @param czas czas od ktorego zaczynamy pobieranie (wpisywany jako czas POSIX).
#' @details \code{wiadomoscizonet} przeszukuje strony artykulow z portalu onet.pl,z zakladki wybory, o dacie powstania pozniejszej od zadanej w argumencie.
#' Szuka przydatnych informacji o nich takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, komentarze.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to onet.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy z artykulow o dacie pozniejszej od zadanej w argumencie.
#'
#' @examples
#' wiadomoscizonet(strptime("01-05-2015 10:00","%d-%m-%Y %H:%M"))
#'
wiadomoscizonet<-function(czas)
{
   #link z zakladki wyborow
   link<-"http://wiadomosci.onet.pl/wybory-prezydenckie-2015"
   adres<-html(link)
   adres_nodes<-html_nodes(adres,"#staticStreamContent > div > a")
   #adresy artykulow
   adresy_artykulow<-html_attr(adres_nodes,"href")
   adresy_artykulow<-unique(adresy_artykulow)
   dl<-length(adresy_artykulow)
   #w ta ramke bedziemy zapisywac dane
   informacje<-data.frame()
   for(i in 1:dl)
   {
      #ramka tymczasowa
      temp<-data.frame()
      #Sprobuj pobrac info z artykulu
      try(temp<-onet_artykul_info(adresy_artykulow[i],i),silent=TRUE)
      #Jesli sie udalo to:
      if(length(temp)!=0)
      {
         temp1<-NULL
         #Sprobuj pobrac date
         try(temp1<-strptime(temp$data,"%Y-%m-%d %H:%M"),silent=TRUE)
         #Jesli sie udalo to:
         if(length(temp1)!=0)
         {
            #Jesli data pozniejsza od zadanej to:
            if(unclass(czas-temp1)<=0)
            {
               #Dopisuj do ramki
               informacje<-rbind(informacje,temp)
            }  
         }
         
      }
      
   }
   #Zwroc ramke
   informacje
}