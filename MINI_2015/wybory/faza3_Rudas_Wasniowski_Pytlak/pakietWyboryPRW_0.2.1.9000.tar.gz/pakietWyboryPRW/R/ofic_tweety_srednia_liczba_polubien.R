#' Wyliczenie sredniej liczby tweetow umieszczanych na oficjalnych profilach kanydatow, w podziale na dni 
#' 
#' Funkcja \code{ofic_tweety_srednia_liczba_polubien} pobiera oficjalne tweety kanydatow, zapisuje je w oddzielnych plikach tekstowych. Nastepnie dla kazdego kandydata wylicza srednia liczbe polubien w podziale na dni, rowniez zapisujac je w oddzielnych plikach tekstowych. Nowe tweety przy powtornych pobieraniach sa nadpisywane do plikow.
#' 
#' @usage \code{ofic_tweety_srednia_liczba_polubien(katalog, data, data_pob, liczba)}
#' 
#' @param katalog sciezka do katalogu, w ktorym przechowywane beda pliki tesktowe
#' @param data data, od ktorej pobieramy oficjalne tweety kandydatow
#' @param data_pob data ostatniego poboru tweetow
#' @param liczba maksymalna ilosc tweetow, jaka chcemy pobrac dla poszczegolnych kandydatow
#' 
#' @return lista nazwana
#' 
#' @examples 
#' katalog3 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\faza3\\oficjalne_tweety\\ulubione_ofic"
#' data3 <- "2015-02-07"
#' data_pob3 <- "data_poboru.txt"
#' liczba3 <- 2000
#' ofic_tweety_ilosc_na_dzien(katalog3, data3, data_pob3, liczba3)
#' 
#' @import twitteR
#' @import stringi
#'   

ofic_tweety_srednia_liczba_polubien <- function(katalog, data, data_pob, liczba){
   
   consumerKey <- "mruTEgk5DpvU0XM8dk3aPRhVx"
   consumerSecret <- "B2NOHpA7uVrap95LOwTssStx8HfWUgSDbtTo0OJhQrXQEmi1oT"
   access_token <- "51761035-QqJMM7EYxwwV5QnGAelnEq6HVg6RQrUYOFMyw9pho"
   access_secret <- "FteRrg5TjcjyW37qMfLBeXaDsFeYQ7AUFgWFmHS1cJqO5"
   
   setup_twitter_oauth(consumerKey, consumerSecret, access_token, 
                       access_secret)
   
   setwd(katalog)
   
   listaTweetow <- list()
   
   kandydaci <- c("Andrzej_Duda", "Bronislaw_Komorowski", 
                  "Magdalena_Ogorek", "Adam_Jarubas", "Janusz_Palikot", 
                  "Janusz_Korwin-Mikke", "Pawel_Kukiz")
   
   oficjalneProfile <- c("AndrzejDuda2015", "Komorowski", "ogorekmagda", 
                         "JarubasAdam", "Palikot_Janusz", "JkmMikke", 
                         "PrezydentKukiz")
   
   #przypadek, gdy tweety byly juz wczesniej pobierane
   if(file.exists(stri_paste(katalog, "/", data_pob))){
      
      wczytajDate <- readLines(stri_paste(katalog, "/", data_pob))
      data_od <- as.POSIXct(wczytajDate)
      num_od <- unclass(data_od)
      
      #nadpisujemy do istniejacych juz plikow tweety umiesczone po ostatnim pobraniu 
      for(i in seq_along(oficjalneProfile)){
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         
         df_tweety_od <- df_tweety[num_daty > num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         #kazda ramka danych zawiera tweety, oficjalna nazwe profilu kandydata 
         #na Twitterze oraz czas powstania tweeta
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         kandydat = df_tweety_od$favoriteCount, 
                                         data = df_tweety_od$created)
         
         #kazda ramka danych zapisywana jest jako plik tekstowy, nowe dane sa
         #nadpisywane
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE, col.names = FALSE)
      }
      
      #zapisujemy w pliku tekstowym date naszego ostatniego poboru
      writeLines(as.character(Sys.time()), stri_paste(katalog, "/", data_pob))
      
      structure(listaTweetow, names = c("Andrzej Duda", "Bronislaw Komorowski", 
                                        "Magdalena Ogorek", "Adam Jarubas", 
                                        "Janusz Palikot", 
                                        "Janusz Korwin-Mikke", "Pawel Kukiz"))
      
   } else {
      
      #przypadek, gdy wczesniej nie pobieralismy zadnych tweetow
      for(i in seq_along(oficjalneProfile)){
         
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         #pobieramy tweety nie starsze od daty podanej jako argument funkcji 
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         num_od <- unclass(as.POSIXct(data))
         df_tweety_od <- df_tweety[num_daty >= num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         kandydat = df_tweety_od$favoriteCount, 
                                         data = df_tweety_od$created)
         
         #ramka danych zapisywana jest jako plik tekstowy
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE)
      }
      
      writeLines(as.character(Sys.time()), stri_paste(katalog, "/", data_pob))
      
   }

   ulubione <- list()
   
   #wczytujemy powstale wczesniej pliki z tweetami
   for(i in seq_along(kandydaci)){
      nazwisko <- read.table(stri_paste(katalog, "/", kandydaci[i], ".txt"), 
                             header = TRUE, sep = "", row.names = NULL)
      ulub <- nazwisko$tekst
      daty <- nazwisko$kandydat
      
      #liczymy srednia liczbe polubien dla poszczegolnych dni
      rozdziel <- split(ulub, daty)
      srednia <- sapply(rozdziel, mean)
      ulubione[[i]] <- sapply(srednia, round)
      
      #wyniki zapisujemy w oddzielnych plikach tekstowych
      write.table(ulubione[[i]], file = stri_paste("ulubione", "-", kandydaci[i], 
                                                ".txt"))   
   }
   
   #dodatkowo generujemy liste nazwana
   structure(ulubione, 
             names = c("Andrzej Duda", "Bronislaw Komorowski", 
                       "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", 
                       "Janusz Korwin-Mikke", "Pawel Kukiz"))
}

