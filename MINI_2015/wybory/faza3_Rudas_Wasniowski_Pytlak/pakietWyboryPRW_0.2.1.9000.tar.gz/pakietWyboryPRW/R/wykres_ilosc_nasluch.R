#' Rysowanie wykresu obrazujacego liczbe tweetow z nasluchu na temat poszczegolnych kandydatow, w podziale na dni 
#' 
#' Funkcja \code{wykres_ilosc_nasluch} wczytuje pliki z obliczonymi wskaznikami dla poszczegolnych kandydatow, a nastepnie rysuje wykres dla wybranych kandydatow i wybranego przedzialu czasu.
#' 
#' @usage \code{wykres_ilosc_nasluch(katalog, kandydaci, data_od, data_do)}
#' 
#' @param katalog sciezka do katalogu, w ktorym przechowywane sa pliki tesktowe ze wskaznikami
#' @param kandydaci wektor imion i nazwisk wybranych kandydatow
#' @param data_od dzien, od ktorego chcemy wyswietlac wyliczone wskazniki 
#' @param data do dzien, do ktorego chcemy wyswietlac wyliczone wskazniki
#' 
#' @return wykres obrazujacy zaleznosc liczby tweetow od dnia
#' 
#' @examples 
#' katalog1 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\faza3\\tweety_nasluch"
#' kandydaci1 <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", "Pawel Kukiz")
#' data_od1 <- as.Date("2015-03-21")
#' data_do1 <- as.Date("2015-05-13")
#' wykres_ilosc_nasluch(katalog1, kandydaci1, data_od1, data_do1)
#' 
#' @import ggplot2
#' @import stringi
#'   



wykres_ilosc_nasluch <- function(katalog, kandydaci, data_od, data_do){

   ilosc_na_dzien <- list()
   
   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   nazwy_plikow <- c("Andrzej_Duda", "Bronislaw_Komorowski", "Magdalena_Ogorek", 
                  "Adam_Jarubas", "Janusz_Palikot", "Janusz_Korwin-Mikke", 
                  "Pawel_Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          nazwa_pliku = nazwy_plikow, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   wybrani <- zbiorcze[ktorzy, ]
   
   for(i in seq_along(wybrani$nazwa_pliku)){
      
      wczytaj_plik <- read.table(stri_paste(katalog, "\\nasluch_ilosc-", 
                                            wybrani$nazwa_pliku[i], ".txt"), 
                                 header = TRUE, sep = "", row.names = NULL)
      
      n <- nrow(wczytaj_plik)
      
      liczba_tweetow <- data.frame(kandydat = rep(wybrani$nazwisko[i], n), 
                                        data = as.Date(wczytaj_plik$row.names), 
                                        ilosc = wczytaj_plik$x)
      
      daty <- liczba_tweetow$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      liczba_tweetow_od_do <- liczba_tweetow[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(wybrani$nazwisko[i], m), 
                                    data = brakujace_dni, ilosc = rep(0, m))
         
         ilosc_na_dzien[[i]] <- rbind(liczba_tweetow_od_do, brak_tweetow)
      }
   }
   
   duza_ramka <- do.call("rbind", ilosc_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = ilosc, col = kandydat)) + geom_line() + 
      ggtitle("Tweety o danym kandydacie - liczba na dzien") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("liczba tweetow") + scale_colour_manual(values = wybrane_kolory)
}


