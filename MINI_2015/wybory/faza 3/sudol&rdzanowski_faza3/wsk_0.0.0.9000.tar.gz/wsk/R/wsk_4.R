#' Policz szanse wystapienia tekstu o wydzwieku pozytywnym, negatywnym lub neutralnym!
#'
#' Funkcje \code{szansa_poz}, \code{szansa_neg}, \code{szansa_neu} wyliczaja szanse wystapienia tekstu o wydzwieku pozytywnym, negatywnym lub neutralnym.
#' @aliases szansa_poz szansa_neg szansa_neu
#' @param wektor_nazwisko 0-1 wektor numeryczny okreslajacy, czy dany tekst jest na temat danego kandydata.
#' @param wektor_sentyment Wektor numeryczny okreslajacy czy (lub w jakim stopniu) dany tekst jest pozytywny (liczby dodatnie), negatywny (liczby ujemne) lub neutralny (liczba 0).
#' @return Wektor numeryczny dlugosci 1. Liczba okreslajaca szanse wystapienia tekstu o wydzwieku pozytywnym, negatywnym lub neutralnym.
#' @examples
#' library("dplyr")
#' data(wybory2015)
#' szansa_poz(wybory2015$ogorek, wybory2015$sentyment_1)
#' szansa_neg(wybory2015$ogorek, wybory2015$sentyment_1)
#' szansa_neu(wybory2015$ogorek, wybory2015$sentyment_1)
#'
#' # grupujac po portalach
#' wybory2015 %>% group_by(portal) %>%
#' summarise(szansa_poz = szansa_poz(ogorek, wektor_sentyment = sentyment_1))
#' wybory2015 %>% group_by(portal) %>%
#' summarise(szansa_neg = szansa_neg(ogorek, wektor_sentyment = sentyment_1))
#' wybory2015 %>% group_by(portal) %>%
#' summarise(szansa_neu = szansa_neu(ogorek, wektor_sentyment = sentyment_1))
#' @author Marcin Rdzanowski, Adrianna Sudol
#' \code{\link{sentyment}}, \code{\link{wybory2015}}
#'

szansa_poz <- function(wektor_nazwisko, wektor_sentyment){
  p <- pstwo_poz(wektor_nazwisko, wektor_sentyment)/100
  szansa <- p/(1-p)
  return(szansa)
}

szansa_neg <- function(wektor_nazwisko, wektor_sentyment){
  p <- pstwo_neg(wektor_nazwisko, wektor_sentyment)/100
  szansa <- p/(1-p)
  return(szansa)
}

szansa_neu <- function(wektor_nazwisko, wektor_sentyment){
  p <- pstwo_neu(wektor_nazwisko, wektor_sentyment)/100
  szansa <- p/(1-p)
  return(szansa)
}
