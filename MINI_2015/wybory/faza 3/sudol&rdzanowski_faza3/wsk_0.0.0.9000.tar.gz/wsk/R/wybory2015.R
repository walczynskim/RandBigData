#' Informacje o widocznosci kandydatow na prezydenta w 2015 roku.
#'
#' Ramka danych zawiera informacje o blisko 110000 tekstow internetowych (artykulow, twittow  itp.) dotyczacych kandydatow na prezydenta Polski w wyborach w 2015 roku.
#'
#' @format Ramka danych ze 109294 wierszami i 15 zmiennymi:
#' \describe{
#'   \item{tekst}{tresc tekstu artykulu, twittu itp.}
#'   \item{portal}{nazwa portalu z jakiego pochodzi tekst}
#'   \item{data}{data pojawienia sie artykulu}
#'   \item{waga}{waznosc tekstu wyznaczana roznie dla roznych portali}
#'   \item{l_retweet}{liczba retwittniec danego twittu (dostepne tylko dla portalu 'tweeter_nasluch')}
#'   \item{l_polubien}{liczba polubien danego twittu (dostepne tylko dla portalu 'tweeter_nasluch')}
#'   \item{komorowski}{czy dany tekst jest o P. Komorowskim}
#'   \item{duda}{czy dany tekst jest o P. Dudzie}
#'   \item{jarubas}{czy dany tekst jest o P. Jarubasie}
#'   \item{ogorek}{czy dany tekst jest o P. Ogorek}
#'   \item{palikot}{czy dany tekst jest o P. Palikocie}
#'   \item{korwin}{czy dany tekst jest o P. Korwin-Mikke}
#'   \item{kukiz}{czy dany tekst jest o P. Kukizie}
#'   \item{sentyment_1}{wydzwiek tekstu mierzony roznica wystapien slow pozytywnych i negatywnych wg. slownika 1}
#'   \item{sentyment_2}{wydzwiek tekstu mierzony roznica wystapien slow pozytywnych i negatywnych wg. slownika 2}
#' }
#' @seealso \code{\link{pstwo_widocznosci}}, \code{\link{pstwo_poz}}, \code{\link{pstwo_neg}}, \code{\link{pstwo_neu}}, \code{\link{poz_do_neg}}, \code{\link{szansa_poz}}, \code{\link{szansa_neg}}, \code{\link{szansa_neu}}, \code{\link{twitt_poz_neg}}, \code{\link{slownik_1_poz}}, \code{\link{slownik_1_neg}}, \code{\link{slownik_2_poz}}, \code{\link{slownik_2_neg}}
"wybory2015"
