#' Policz roznice liczby 'retweetniec' ('polubien') twittow pozytywnych i negatywnych!
#'
#' Funkcja \code{twitt_poz_neg} wylicza roznice sredniej liczby 'retweetniec' ('polubien') tweetow pozytywnych i negatywnych.
#'
#' @aliases twitt_poz_neg
#' @param wektor_nazwisko 0-1 wektor numeryczny okreslajacy, czy dany tekst jest na temat danego kandydata.
#' @param wektor_sentyment Wektor numeryczny okreslajacy czy (lub w jakim stopniu) dany tekst jest pozytywny (liczby dodatnie), negatywny (liczby ujemne) lub neutralny (liczba 0).
#' @param liczba_twitt Wektor numeryczny okreslajacy liczba 'retwitniec' lub liczbe 'polubien' twittow.
#' @return Wektor numeryczny dlugosci 1 okreslajacy roznice wystapien sredniej liczby 'retwitniec' lub 'polubien' twittow o wydzwieku pozytywnym i negatywnym.
#' @examples
#' library("dplyr")
#' data(wybory2015)
#' twitt_poz_neg(wybory2015$duda[wybory2015$portal == "tweeter_nasluch"], wybory2015$sentyment_1[wybory2015$portal == "tweeter_nasluch"], wybory2015$l_retweet[wybory2015$portal == "tweeter_nasluch"])
#' @author Marcin Rdzanowski, Adrianna Sudol
#' @seealso \code{\link{sentyment}}, \code{\link{wybory2015}}
#'

twitt_poz_neg <- function(wektor_nazwisko, wektor_sentyment, liczba_twitt){
  plus <- ifelse(wektor_sentyment > 0, 1, 0)
  minus <- ifelse(wektor_sentyment < 0, 1, 0)
  wsk <- sum(wektor_nazwisko*plus*liczba_twitt)/sum(plus) - sum(wektor_nazwisko*minus*liczba_twitt)/sum(minus)
  return(wsk)
}
