#' Policz stosunek artykulow o wydzwieku pozytywnym do tych o wydzwieku negatywnym dla kandydata!
#'
#' Funkcja \code{poz_do_neg} wylicza stosunek artykulow o wydzwieku pozytywnym do artykulow o wydzwieku negatywnym dla danego kandydata.
#'
#' @aliases poz_do_neg
#' @param wektor_nazwisko 0-1 wektor numeryczny okreslajacy, czy dany tekst jest na temat danego kandydata.
#' @param wektor_sentyment Wektor numeryczny okreslajacy czy (lub w jakim stopniu) dany tekst jest pozytywny (liczby dodatnie), negatywny (liczby ujemne) lub neutralny (liczba 0).
#' @return Wektor numeryczny dlugosci 1. Liczba okreslajaca stosunek liczby wystapien tekstu o wydzwieku pozytywnym do liczby wystapien tekstu o wydzwieku negatywnym.
#' @examples
#' library("dplyr")
#' data(wybory2015)
#' # dla wszystkich portali
#' poz_do_neg(wybory2015$jarubas, wybory2015$sentyment_1)
#'
#' # grupujac po portalach
#' wybory2015 %>% group_by(portal) %>%
#' summarise(poz_do_neg = poz_do_neg(duda, wektor_sentyment = sentyment_1))
#' @author Marcin Rdzanowski, Adrianna Sudol
#' \code{\link{sentyment}}, \code{\link{wybory2015}}
#'

poz_do_neg <- function(wektor_nazwisko, wektor_sentyment){
  return(pstwo_poz(wektor_nazwisko, wektor_sentyment)/pstwo_neg(wektor_nazwisko, wektor_sentyment))
}
