#' Slownik nr. 1 slow pozytywnych.
#'
#' Wektor ponad 2000 slow w jezyku polskim, ktorych wydzwiek uznawany jest za pozytywny.
#'
#' @format Wektor napisow dlugosci 2006.
#' @details Podany zbior slow pochodzi ze strony podanej ponizej i zostal przetlumaczony na jezyk polski.
#' @source \url{https://github.com/pbiecek/RandBigData/blob/master/MINI_2015/materialy/webscrap/positive-words.txt}
#' @seealso \code{\link{slownik_1_neg}}, \code{\link{slownik_2_poz}}, \code{\link{slownik_2_neg}}, \code{\link{sentyment}}
"slownik_1_poz"
