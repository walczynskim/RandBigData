#' Policz p-stwo wystapienia pozytywnego (negatywnego, neutralnego) tekstu o kandydacie w mediach!
#'
#' Funkcje \code{pstwo_poz}, \code{pstwo_neg}, \code{pstwo_neu} wyliczaja prawdopodobienstwo zdarzenia, ze wydzwiek tekstu w mediach jest pozytywny, negatywny lub neutralny.
#'
#' @aliases pstwo_poz pstwo_neg pstwo_neu
#' @param wektor_nazwisko 0-1 wektor numeryczny okreslajacy, czy dany tekst jest na temat danego kandydata.
#' @param wektor_sentyment Wektor numeryczny okreslajacy czy (lub w jakim stopniu) dany tekst jest pozytywny (liczby dodatnie), negatywny (liczby ujemne) lub neutralny (liczba 0).
#' @return Wektor numeryczny dlugosci 1. Liczba z przedzialu [0,100] okreslajaca p-stwo (w procentach) wystapienia tekstu pozytywnego, negatywnego lub neutralnego na temat danego kandydata.
#' @examples
#' library("dplyr")
#' data(wybory2015)
#' # dla wszystkich portali
#' pstwo_poz(wybory2015$duda, wybory2015$sentyment_1)
#' pstwo_neg(wybory2015$duda, wybory2015$sentyment_1)
#' pstwo_neu(wybory2015$duda, wybory2015$sentyment_1)
#'
#' # grupujac po portalach
#' wybory2015 %>% group_by(portal) %>%
#' summarise(procent_obecnosci_poz = pstwo_poz(duda, wektor_sentyment = sentyment_1))
#' wybory2015 %>% group_by(portal) %>%
#' summarise(procent_obecnosci_neg = pstwo_neg(duda, wektor_sentyment = sentyment_1))
#' wybory2015 %>% group_by(portal) %>%
#' summarise(procent_obecnosci_neu = pstwo_neu(duda, wektor_sentyment = sentyment_1))
#' @author Marcin Rdzanowski, Adrianna Sudol
#' @seealso \code{\link{sentyment}}, \code{\link{wybory2015}}
#'

pstwo_poz <- function(wektor_nazwisko, wektor_sentyment){
  p_m <- ifelse(wektor_sentyment > 0, 1, 0)
  n <- sum(wektor_nazwisko)
  procent <- floor(sum(wektor_nazwisko*p_m*10000)/n)/100
  return(procent)
}

pstwo_neg <- function(wektor_nazwisko, wektor_sentyment){
  p_n <- ifelse(wektor_sentyment < 0, 1, 0)
  n <- sum(wektor_nazwisko)
  procent <- floor(sum(wektor_nazwisko*p_n)/n*10000)/100
  return(procent)
}

pstwo_neu <- function(wektor_nazwisko, wektor_sentyment){
  p_n <- ifelse(wektor_sentyment == 0, 1, 0)
  n <- sum(wektor_nazwisko)
  procent <- floor(sum(wektor_nazwisko*p_n)/n*10000)/100
  return(procent)
}
