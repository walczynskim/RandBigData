#' Slownik nr. 1 slow negatywnych.
#'
#' Wektor ponad 4700 slow w jezyku polskim, ktorych wydzwiek uznawany jest za negatywny.
#'
#' @format Wektor napisow dlugosci 4783.
#' @details Podany zbior slow pochodzi ze strony podanej ponizej i zostal przetlumaczony na jezyk polski.
#' @source \url{https://github.com/pbiecek/RandBigData/blob/master/MINI_2015/materialy/webscrap/negative-words.txt}
#' @seealso \code{\link{slownik_1_poz}}, \code{\link{slownik_2_poz}}, \code{\link{slownik_2_neg}}, \code{\link{sentyment}}
"slownik_1_neg"
