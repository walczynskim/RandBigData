#' Slownik nr. 2 slow negatywnych.
#'
#' Wektor 34 slow w jezyku polskim, ktorych wydzwiek uznawany jest za negatywny.
#'
#' @format Wektor napisow dlugosci 34.
#' @details Podany zbior slow zostal stworzony na podstawie informacji podanych na stronie, ktorej adres podano ponizej.
#' @source \url{http://home.agh.edu.pl/~horzyk/lectures/pn/ahdydpnmagiaslow.php}
#' @seealso \code{\link{slownik_2_poz}}, \code{\link{slownik_1_poz}}, \code{\link{slownik_1_neg}}, \code{\link{sentyment}}
"slownik_2_neg"
