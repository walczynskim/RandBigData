#' Policz p-stwo widocznosci kandydata w mediach!
#'
#' Funkcja \code{pstwo_widocznosci} wylicza prawdopodobienstwo zdarzenia, ze podany tekst jest na temat danego kandydata.
#'
#' @aliases pstwo_widocznosci
#' @param wektor_nazwisko 0-1 wektor numeryczny okreslajacy, czy dany tekst jest na temat danego kandydata.
#' @return Wektor numeryczny dlugosci 1. Liczba z przedzialu [0,100] okreslajaca p-stwo (w procentach) widocznosci kandydata.
#' @examples
#' library("dplyr")
#' data(wybory2015)
#' # dla wszystkich portali
#' pstwo_widocznosci(wybory2015$komorowski)
#'
#' # grupujac po portalach
#' wybory2015 %>% group_by(portal) %>%
#' summarise(procent_obecnosci = pstwo_widocznosci(komorowski))
#'
#' # grupujac po dacie (czyli w czasie)
#' wybory2015 %>% group_by(data) %>% summarise(procent_obecnosci = pstwo_widocznosci(komorowski))
#'
#' # grupujac po dacie i portalach
#' wybory2015 %>% group_by(data, portal) %>% summarise(procent_obecnosci = pstwo_widocznosci(komorowski))
#' @author Marcin Rdzanowski, Adrianna Sudol
#' @seealso \code{\link{wybory2015}}
#'

pstwo_widocznosci <- function(wektor_nazwisko){
  n <- length(wektor_nazwisko)
  procent <- floor(sum(wektor_nazwisko)/n*10000)/100
  return(procent)
}
