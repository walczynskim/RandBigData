#' Wyznacz sentyment dla danego tekstu!
#'
#' Funkcja \code{sentyment} wyznacza sentyment dla danego tekstu okreslajacy jego wydzwiek na podstawie slownika slow pozytywnych i negatywnych.
#'
#' @aliases sentyment
#' @param tekst Wektor napisow, ktorych wydzwiek chcemy okreslic.
#' @param poz Wektor napisow. Wektor zawierajacy slowa, głoski lub litery, ktorych wydzwiek uznajemy za pozytywny.
#' @param poz Wektor napisow. Wektor zawierajacy slowa, głoski lub litery, ktorych wydzwiek uznajemy za negatywny.
#' @return Wektor numeryczny dlugosci takiej samej jak wektor tekst. Dla kazdego elementu tego wektora okreslony jest jego sentyment rozumiany jako roznica miedzy liczba wyrazow ze slownika slow pozytywnych \code{poz} i negatywnych \code{neg}.
#' @details W celu otrzymania satysfakcjonujacego wyniku przed uzyciem funkcji \code{sentyment} nalezy ustalic reguly zapisu slow. Dla przykladu warto aby wszystkie slowa ze slownikow slow pozytywnych \code{poz} i negatywnych \code{neg} oraz slowa z wektora \code{tekst} zawieraly male litery.
#' @examples
#' data(wybory2015)
#' data(slownik_1_poz)
#' data(slownik_1_neg)
#' sentyment(tekst = wybory2015$tekst[1:100], poz = slownik_1_poz, neg = slownik_1_neg)
#' @author Marcin Rdzanowski, Adrianna Sudol
#' @seealso \code{\link{slownik_1_poz}}, \code{\link{slownik_1_neg}}, \code{\link{slownik_2_poz}}, \code{\link{slownik_2_neg}}
#' @import stringi

sentyment <- function(tekst, poz, neg){
  score <- numeric(length(tekst))
  for(i in 1:length(tekst)){
    plus <- sum(stri_count_fixed(tekst[i], poz))
    minus <- sum(stri_count_fixed(tekst[i], neg))
    score[i] <- plus - minus
  }
  return(score)
}
