#' zmiana liczby serii w czasie
#'
#' Funkcja \code{wykresLiczbySerii} rysuje wykres przedstawiajacy zmiane wartosci liczby serii wzgledem czasu.
#'
#' @usage
#' \code{wykresLiczbySerii(dane,zrodlo,co,coile,od_ktorego,do_ktorego,liczbaserii,
#' ktorzykandydaci=c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz")}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param coile wartosc liczbowa co jaki okres czasu liczymy wartosci miary.
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param liczbaserii wartosc liczbowa liczymy liczbe serii o dlugosci zadaniej przez ten argument.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresLiczbySerii} rysuje wykres, na osi x mamy czasy, na osi y wartosc liczby serii o zadanej dlugosci.
#' Dla kazdego czasu liczona jest liczba serii dla wbranych kandydatow, punkty sa laczone liniami (powstaja lamane).
#'
#' @return wykres zaleznosci miedzy liczba serii o zadanej dlugosci a czasem.
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' wykresLiczbySerii(d,"brak","tresc",7,as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"),2)
#'
wykresLiczbySerii<-function(dane,zrodlo,co,coile,od_ktorego,do_ktorego,liczbaserii,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                   "Wilk","Braun","Kukiz"))
{
   #ruchomy - wartosc, ktora przy kazdym obrocie petli skacze o coile
   ruchomy<-od_ktorego+1
   df<-data.frame()
   czas<-c()
   while(ruchomy<=do_ktorego)
   {
      #dla kazdej wartosci ruchomego liczymy miare
      temp<-iloscDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                              "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                              "$3-$2-$1"),stri_replace_all_regex(as.character(ruchomy) ,
                                                                                                 "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                  "$3-$2-$1"),maks=FALSE,dlserii=liczbaserii)
      #uzyskanie ruchomego jako napisu
      temp1<-as.character(ruchomy)


      #skok

      ruchomy<-ruchomy+coile
      df<-rbind(df,temp)
      czas<-c(czas,temp1)
   }
   kolory<-c("black","yellow","blue","red","purple","green","brown","orange","magenta","cyan")
   names(kolory)<-c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                    "Wilk","Braun","Kukiz")
   colnames(df)<-names(kolory)
   df<-cbind(czas,df)
   #zeby linie byly widoczne odchylmy je nieznacznie od siebie (zeby nie zachodzily)
   for(i in 2:11)
   {
      df[,i]<-df[,i]+0.005*i*(-1)^i
   }

   id<-1:nrow(df)
   df<-cbind(df,id)
   df<-df[,c("czas",ktorzykandydaci,"id")]
   #kolory wykresu
   kolory<-kolory[ktorzykandydaci]
   dfm <- melt(df, id.var = c("id","czas"))
   #Tworzenie tytulu
   skladowa_tytul1<-"Liczba serii o dlugosci"
   skladowa_tytul2<-as.character(liczbaserii)
   skladowa_tytul3<-"wzgledem czasu"
   tytul<-stri_paste(skladowa_tytul1,skladowa_tytul2,skladowa_tytul3,sep=" ")
   #wykres
   p<-ggplot(dfm, aes(czas,value,group= variable,colour = variable)) +geom_line()+scale_colour_manual(values=kolory)+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab("czas") + ylab("Liczba serii")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
