#' Wyznaczenie ile razy dziennie pojawial sie kandydat w artykulach
#'
#' Funkcja \code{ile_dziennie} przyjmuje dane z portali
#' i wyznacza macierz informujaca ile razy dany kandydat danego dnia sie pojawial w artykulach.
#'
#' @usage
#' \code{ile_dziennie(dane,co="tytul",po.zrodle=FALSE)}
#'
#' @param dane ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param co napis gdzie szukamy wystapien kandydatow(mozliwe wartosci "tytul","tagi","tresc").
#' @param po.zrodle parametr logiczny informujacy czy rozrozniamy liczbe wystapien danego kandydata
#' danego dnia uwzgledniajac podzial na zrodlo czy tez nie.
#' 
#' @details \code{ile_dziennie} wyznacza macierz liczby wystapien kandydatow dla kazdego dnia,
#' w ktorym pobierane byly dane. Wystapienia moga byc zliczane z tytulow, tresci, lub tagow artykulow.
#'
#' @return Zwraca ramke danych. Jesli po.zrodle=FALSE w kazdym wierszu mamy na poczatku dzien, a nastepnie
#' liczbe wystapien dla poszczegolnych kandydatow w tym danym dniu. Jesli po.zrodle=TRUE, wowczas na poczatku w kazdym wierszu
#' mamy dzien dalej zrodlo a nastepnie liczbe wystapien kandydatow dla danego dnia i danego zrodla.
#'
#' @examples
#' ile_dziennie(read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt")),co="tresc",po.zrodle=FALSE)
#' ile_dziennie(read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt")),co="tytul",po.zrodle=TRUE)
#'
ile_dziennie<-function(dane, co = "tytul", po.zrodle=FALSE){
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")
   names(kandydat) <- nazwiska
   #Mogly sie pobrac jakies NA trzeba je usunac
   if(length(attr(na.omit(dane[,co]),"na.action"))!=0)
   {
      dane<-dane[-attr(na.omit(dane[,co]),"na.action"),]
   }
   #Stworzmy macierz wystapien kandydatow w artykulach
   czy_nazwisko<-sapply(kandydat,function(x){
      stri_count_regex(dane[,co],x)
   })
   #Doklejamy zrodlo i date pobrania artykulu dla kazdego wektora wystapien (bedacych wierszami macierzy)
   d2<-cbind(dane[,2:3], czy_nazwisko)
   #Oddzielamy dzien od godziny
   d2<-separate(d2, data, c("dzien", "godzina"), " ")
   # niektore daty maja format rok-miesiac-dzien, sprowadzam wszystkie
   # daty do formatu dd-mm-rrrr:
   d2$dzien <- stri_replace_all_regex(d2$dzien,
                                      "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                      "$3-$2-$1")
   #Jesli uwzgledniamy podzial na zrodla to grupujemy po zrodlach i dniu
   if (po.zrodle)
   {
      d2<-d2 %>% group_by(dzien,zrodlo)
   }
   #Jesli nie to tylko po dniach
   else
   {
      d2<-d2 %>% group_by(dzien)
   }
   #sumujemy wystapienia dla kazdego kandydata dla kolejnych dni i przedstawiamy wynik jako macierz wyjsciowa
   d2 %>%
      summarise_each(funs(sum),-zrodlo,-dzien,-godzina)
}
