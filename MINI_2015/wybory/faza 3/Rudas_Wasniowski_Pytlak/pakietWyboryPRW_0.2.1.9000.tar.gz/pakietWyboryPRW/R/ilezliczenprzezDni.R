#' Wyznaczenie ilosci wsytapien kandydatow na przedziale czasu
#'
#' Funkcja \code{ilezliczenprzezDni} wyznacza liczbe wystapien dla kandydatow na okreslonym przedziale czasowym.
#'
#' @usage
#' \code{ilezliczenprzezDni(dane,podajzrodlo,co,datapocz, datakonc)}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param podajzrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow: dostepne wartosci "tytul","tagi","tresc".
#' @param datapocz data w postaci napisu dd-mm-YYYY od ktorej rozpatrujemy artykuly (wczesniejszych nie bierzemy pod uwage).
#' @param datakonc data data w postaci napisu dd-mm-YYYY do ktorej rozpatrujemy artykuly (pozniejszych nie bierzemy pod uwage).
#'
#' @details \code{ilezliczenprzezDni} liczy liczbe wystapien dla kandydata na okreslonym okresie czasu.
#'
#' @return wektor miar opisanych w szczegolach funkcji, kazdy element wektora dotyczy innego kandydata.
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' ilezliczenprzezDni(d,"gazeta.pl","tytul",datapierwszgopobrania(d,"gazeta.pl"),aktualnydzien())
#' ilezliczenprzezDni(d,"brak","tytul",datapierwszgopobrania(d,"brak"),aktualnydzien())
#'
ilezliczenprzezDni<-function(sciezka,podajzrodlo,co,datapocz, datakonc)
{
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   #Zamina na POSIX
   pocz<-strptime(datapocz,"%d-%m-%Y")
   konc<-strptime(datakonc,"%d-%m-%Y")
   #Ustalamy czy przeszukujemy po zrodle
   po.zrodle<-TRUE
   if(podajzrodlo=="brak")
   {
      po.zrodle<-FALSE
   }
   #ramka danych o czestotliwosci wystepowan ze wzgledu na dzien
   d<-ile_dziennie(sciezka,co,po.zrodle)
   if(po.zrodle)
   {
      d<-d[d$zrodlo==podajzrodlo,]
      odpowiedniekolumny<-2 #kolumny kandydatow zaczynaja sie od 3
   }
   else
   {
      odpowiedniekolumny<-1 #kolumny kandydatow zaczynaja sie od 2
   }
   zliczaktywnosc<-rep(0,length(kandydat))
   dni<-strptime(d$dzien,"%d-%m-%Y")
   #ktore dni sie mieszcza w przedziale
   d<-d[which(dni<=konc&dni>=pocz),]
   #sumujemy aktywnosc
   for(i in 1:length(kandydat))
   {
      zliczaktywnosc[i]<-sum(d[,odpowiedniekolumny+i])
   }
   names(zliczaktywnosc)<-nazwiska
   zliczaktywnosc

}
