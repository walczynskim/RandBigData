#' Wyliczenie sredniej liczby retweetow na tweety umieszczane na oficjalnych profilach kanydatow, w podziale na dni 
#' 
#' Funkcja \code{ofic_tweety_srednia_liczba_retweetow} pobiera oficjalne tweety kanydatow, zapisuje je w oddzielnych plikach tekstowych. Nastepnie dla kazdego kandydata wylicza srednia liczbe retweetow w podziale na dni, rowniez zapisujac je w oddzielnych plikach tekstowych. Nowe tweety przy powtornych pobieraniach sa nadpisywane do plikow.
#' 
#' @usage \code{ofic_tweety_srednia_liczba_retweetow(katalog, data, data_pob, liczba)}
#' 
#' @param katalog sciezka do katalogu, w ktorym przechowywane beda pliki tesktowe
#' @param data data, od ktorej pobieramy oficjalne tweety kandydatow
#' @param data_pob data ostatniego poboru tweetow
#' @param liczba maksymalna ilosc tweetow, jaka chcemy pobrac dla poszczegolnych kandydatow
#' 
#' @return lista nazwana
#' 
#' @examples 
#' katalog3 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\faza3\\oficjalne_tweety\\retweety_ofic"
#' data3 <- "2015-02-07"
#' data_pob3 <- "data_poboru.txt"
#' liczba3 <- 2000
#' ofic_srednia_liczba_retweetow(katalog3, data3, data_pob3, liczba3)
#' 



ofic_tweety_srednia_liczba_retweetow <- function(katalog, data, data_pob, liczba){
   
   consumerKey <- "mruTEgk5DpvU0XM8dk3aPRhVx"
   consumerSecret <- "B2NOHpA7uVrap95LOwTssStx8HfWUgSDbtTo0OJhQrXQEmi1oT"
   access_token <- "51761035-QqJMM7EYxwwV5QnGAelnEq6HVg6RQrUYOFMyw9pho"
   access_secret <- "FteRrg5TjcjyW37qMfLBeXaDsFeYQ7AUFgWFmHS1cJqO5"
   
   setup_twitter_oauth(consumerKey, consumerSecret, access_token, 
                       access_secret)
   
   setwd(katalog)
   
   listaTweetow <- list()
   
   kandydaci <- c("Andrzej_Duda", "Bronislaw_Komorowski", 
                  "Magdalena_Ogorek", "Adam_Jarubas", "Janusz_Palikot", 
                  "Janusz_Korwin-Mikke", "Pawel_Kukiz")
   
   oficjalneProfile <- c("AndrzejDuda2015", "Komorowski", "ogorekmagda", 
                         "JarubasAdam", "Palikot_Janusz", "JkmMikke", 
                         "PrezydentKukiz")
   
   #przypadek, gdy tweety byly juz wczesniej pobierane
   if(file.exists(stri_paste(katalog, "/", data_pob))){
      
      wczytajDate <- readLines(stri_paste(katalog, "/", data_pob))
      data_od <- as.POSIXct(wczytajDate)
      num_od <- unclass(data_od)
      
      for(i in seq_along(oficjalneProfile)){
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         
         #pobieramy tweety nowsze niz data ostatniego poboru tweetow
         df_tweety_od <- df_tweety[num_daty > num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         #kazda ramka danych zawiera tweety, oficjalna nazwe profilu kandydata 
         #na Twitterze oraz czas powstania tweeta
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         kandydat = df_tweety_od$screenName, 
                                         data = df_tweety_od$created)
         
         #kazda ramka danych zapisywana jest jako plik tekstowy, nowe dane sa
         #nadpisywane
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE, col.names = FALSE)
      }
      
      #zapisujemy dte naszego poboru w pliku tekstowym
      writeLines(as.character(Sys.time()), stri_paste(katalog, "/", data_pob))
      
   } else {
      
      #przypadek, gdy pierwszy raz pobieramy tweety
      for(i in seq_along(oficjalneProfile)){
         
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         num_od <- unclass(as.POSIXct(data))
         
         #pobieramy nie starsze niz data podana jako argument funkcji 
         df_tweety_od <- df_tweety[num_daty >= num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         retweety = df_tweety_od$retweetCount, 
                                         data = df_tweety_od$created)
         
         #ramka danych zapisywana jest jako plik tekstowy
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE)
         
      }
      
      writeLines(as.character(Sys.time()), stri_paste(katalog, "/", data_pob))
      
   }

   rt <- list()
   
   for(i in seq_along(kandydaci)){
      nazwisko <- read.table(stri_paste(katalog, "/", kandydaci[i], ".txt"), 
                             header = TRUE, sep = "", row.names = NULL)
      retweets <- nazwisko$tekst
      daty <- nazwisko$retweety
      
      #dla kazdego kandydata obliczamy srednia liczbe retweetow na dzien
      rozdziel <- split(retweets, daty)
      srednia <- sapply(rozdziel, mean)
      rt[[i]] <- sapply(srednia, round)
      
      #wyniki zapisujemy w pliku tekstowym
      write.table(rt[[i]], file = stri_paste("retweety", "-", kandydaci[i], 
                                                ".txt"))
   }
   
   #na koncu generujemy liste nazwana
   structure(rt, 
             names = c("Andrzej Duda", "Bronislaw Komorowski", 
                       "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", 
                       "Janusz Korwin-Mikke", "Pawel Kukiz"))   
}



