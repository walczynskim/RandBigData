#' Wyszukiwanie informacji z portalu gazeta.pl z zakladki wybory
#'
#' Funkcja \code{gazetapl_artykul_info} sciaga artykuly z portalu gazeta.pl z zakladki wybory.
#'
#' @usage
#' \code{gazetapl_artykul_info(link,id)}
#'
#' @param link link do strony danego artykulu z portalu gazeta.pl(struktura linku jak w przykladzie).
#' @param id liczba bedaca id  pobranego artykulu (aby pobrane dane byly uporzadkowane).
#' @details \code{gazetapl_artykul_info} przeszukuje strone danego artykulu z portalu gazeta.pl szukajac
#' przydatnych informacji o nim takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, liczba komentarzy.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to gazeta.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy.
#'
#' @examples
#' gazetapl_artykul_info("http://wiadomosci.gazeta.pl/wiadomosci/1,145306,17882477,Wybory_prezydenckie__Ostatnie_dni__by_otrzymac_zaswiadczenie.html",1)
#'

gazetapl_artykul_info<-function(link,id)
{
   adresartykulu<-html(link)
   adresartykulu_nodes<-html_nodes(adresartykulu,"#gazeta_article_date")
   adresartykulu_tekst<-html_text(adresartykulu_nodes)
   #Pobieramy date
   data<-unlist(stri_extract_all_regex(adresartykulu_tekst,"[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}"))
   data<-stri_replace_all_regex(data,"\\.","-")
   #Pobieramy godzine
   godzina<-unlist(stri_extract_all_regex(adresartykulu_tekst,"[0-9]{2}:[0-9]{2}"))
   #Data i godzina jako jeden wyraz
   czas<-paste(data,godzina)
   #Pobieramy tytul
   tytul_nodes<-html_nodes(adresartykulu,"h1")
   tytul<-html_text(tytul_nodes,encoding="UTF-8")
   #Wypsiujemy zrodlo
   zrodlo<-"gazeta.pl"
   #Pobieramy tresc
   tresc_nodes<-html_nodes(adresartykulu,"#artykul , #gazeta_article_lead")
   tresc<-html_text(tresc_nodes,encoding="UTF-8")
   tresc<-paste(tresc[1],tresc[2])
   #Pobieramy tagi
   tagi_nodes<-html_nodes(adresartykulu,"#gazeta_article_tags ul")
   tagi<-html_text(tagi_nodes,encoding="UTF-8")
   
   
   #Pobieramu liczbe komentarzy
   liczba_nodes<-html_nodes(adresartykulu,".head a")
   liczba<-html_text(liczba_nodes)
   if(length(liczba)==0)
   {
      liczba_nodes<-html_nodes(adresartykulu,".head")
      liczba<-html_text(liczba_nodes)
   }
   liczba_kom<-unlist(stri_extract_all_regex(liczba,"[0-9]{1,10}"))
   #zwroc ramke danych
   data.frame("id"=id,"zrodlo"=zrodlo,"data"=czas,"tytul"=tytul,"tresc"=tresc,
              "tagi"=tagi,"liczba komentarzy"=liczba_kom)
}