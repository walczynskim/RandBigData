#' Wyszukiwanie informacji z portalu onet.pl z zakladki wybory
#'
#' Funkcja \code{onet_artykul_info} sciaga artykuly z portalu onet.pl z zakladki wybory.
#'
#' @usage
#' \code{onet_artykul_info(link,id)}
#'
#' @param link napis bedacy linkiem do strony danego artykulu z portalu onet.pl(struktura linku jak w przykladzie)
#' @param id liczba bedaca id  pobranego artykulu (aby pobrane dane byly uporzadkowane).
#' @details \code{onet_artykul_info} przeszukuje strone danego artykulu z portalu onet.pl szukajac
#' przydatnych informacji o nim takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, liczba komentarzy.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to onet.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy.
#'
#' @examples
#' onet_artykul_info("http://wiadomosci.onet.pl/kraj/ostatni-sondaz-prezydencki-przed-cisza-wyborcza/6fsqj6",1)
#'
onet_artykul_info<-function(link,id){
   adresartykulu<-html(link)
   #Pobierz zrodlo
   zrodlo<-"wiadomosci.onet.pl"
   #Pobierz tytul
   tytul<-html_nodes(adresartykulu,"#mainTitle > h1")[[1]] %>% html_text(encoding="UTF-8")
   tytul<-stri_trim(tytul)
   #Pobierz tagi
   tagi<-html_nodes(adresartykulu,"#relatedTopics > span")[-1]%>%
      html_text(encoding="UTF-8")
   tagi<-stri_trim(tagi) %>% stri_paste(collapse = ",")%>% 
      stri_replace_all_regex(",\\.+","")
   
   
   #Pobierz czas
   czas<-html_nodes(adresartykulu,"#articleHeading > meta") %>% html_attr("content")
   czas<-stri_replace_all_regex(czas,"\\+[0-9]{4}","")
   
   #Pobierz tresc
   tresc1<-html_nodes(adresartykulu,"#lead > p") %>% html_text(encoding="UTF-8")
   tresc<-html_nodes(adresartykulu,"#detail > p") %>% html_text()
   if(length(tresc)==0)
   {
      tresci<-html_nodes(adresartykulu,"#detail > div.interview > p") %>% html_text()
      tresc<-c()
      for (i in 1:length(tresci))
      {
         tresc<-paste(tresc,tresci[i])
      }
      
      tresc<-paste(tresc1, tresc)
   }
   else
   {
      tresc<-stri_paste(tresc1,tresc,collapse = " ")
   }
   
   
   #Pobierz liczbe komentarzy
   liczba_kom<-html_nodes(adresartykulu,"#socialTop > div > div.box3_forum > div.forumCommentButton > div.dymek > div.dymek4")
   liczba_kom<-html_text(liczba_kom)
   #Zwroc ramke danych
   data.frame("id"=id,"zrodlo"=zrodlo,"data"=czas,"tytul"=tytul,"tresc"=tresc,
              "tagi"=tagi,"liczba komentarzy"=liczba_kom)
   
   
}