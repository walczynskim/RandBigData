#' Wyliczenie liczby tweetow umieszczanych na oficjalnych profilach kanydatow, w podziale na dni 
#' 
#' Funkcja \code{ofic_tweety_ilosc_na_dzien} pobiera oficjalne tweety kanydatow, zapisuje je w oddzielnych plikach tekstowych. Nastepnie dla kazdego kandydata wylicza liczbe tweetow w podziale na dni, rowniez zapisujac je w oddzielnych plikach tekstowych. Nowe tweety przy powtornych pobieraniach sa nadpisywane do plikow.
#' 
#' @usage \code{ofic_tweety_ilosc_na_dzien(katalog, data, data_pob, liczba)}
#' 
#' @param katalog sciezka do katalogu, w ktorym przechowywane beda pliki tesktowe
#' @param data data, od ktorej pobieramy oficjalne tweety kandydatow
#' @param data_pob data ostatniego poboru tweetow
#' @param liczba maksymalna ilosc tweetow, jaka chcemy pobrac dla poszczegolnych kandydatow
#' 
#' @return lista nazwana
#' 
#' @examples 
#' katalog2 <- "C:\\Dane\\Pawel_2\\PW\\R_Big_Data\\Wybory\\faza3\\oficjalne_tweety"
#' data2 <- "2015-02-07"
#' data_pob2 <- "data_poboru.txt"
#' liczba2 <- 2000
#' ofic_tweety_ilosc_na_dzien(katalog2, data2, data_pob2, liczba2)
#'   


ofic_tweety_ilosc_na_dzien <- function(katalog, data, data_pob, liczba){
   
   consumerKey <- "mruTEgk5DpvU0XM8dk3aPRhVx"
   consumerSecret <- "B2NOHpA7uVrap95LOwTssStx8HfWUgSDbtTo0OJhQrXQEmi1oT"
   access_token <- "51761035-QqJMM7EYxwwV5QnGAelnEq6HVg6RQrUYOFMyw9pho"
   access_secret <- "FteRrg5TjcjyW37qMfLBeXaDsFeYQ7AUFgWFmHS1cJqO5"
   
   setup_twitter_oauth(consumerKey, consumerSecret, access_token, 
                       access_secret)
   
   setwd(katalog)
   
   listaTweetow <- list()
   
   kandydaci <- c("Andrzej_Duda", "Bronislaw_Komorowski", 
                  "Magdalena_Ogorek", "Adam_Jarubas", "Janusz_Palikot", 
                  "Janusz_Korwin-Mikke", "Pawel_Kukiz")
   
   oficjalneProfile <- c("AndrzejDuda2015", "Komorowski", "ogorekmagda", 
                         "JarubasAdam", "Palikot_Janusz", "JkmMikke", 
                         "PrezydentKukiz")
   
   #przypadek, gdy pobieralismy juz wczesniej tweety
   if(file.exists(stri_paste(katalog, "\\", data_pob))){
      
      wczytajDate <- readLines(stri_paste(katalog, "\\", data_pob))
      data_od <- as.POSIXct(wczytajDate)
      num_od <- unclass(data_od)
      
      for(i in seq_along(oficjalneProfile)){
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         #pobieramy tweety nie starsze od daty ostatniego pobrania
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         
         df_tweety_od <- df_tweety[num_daty > num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         #kazda ramka danych zawiera tweety, oficjalna nazwe profilu kandydata 
         #na Twitterze oraz czas powstania tweeta
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         kandydat = df_tweety_od$screenName, 
                                         data = df_tweety_od$created)
         
         #kazda ramka danych zapisywana jest jako plik tekstowy, nowe dane sa
         #nadpisywane
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE, col.names = FALSE)
      }
      
      #zapisujemy date poboru tweetow
      writeLines(as.character(Sys.time()), stri_paste(katalog, "\\", data_pob))
      
   } else {
      
      #przypadek, gdy wczesniej nie byly pobierane zadne tweety
      for(i in seq_along(oficjalneProfile)){
         
         tweety <- userTimeline(oficjalneProfile[i], n = liczba, includeRts = TRUE)
         df_tweety <- twListToDF(tweety)
         
         #pobieramy tweety nie starsze od daty podanej jako argument funkcji
         daty <- df_tweety$created
         num_daty <- unclass(daty)
         num_od <- unclass(as.POSIXct(data))
         df_tweety_od <- df_tweety[num_daty >= num_od, ]
         
         df_tweety_od$text <- stri_replace_all_regex(df_tweety_od$text, 
                                                     "[[:punct:]]", "")
         
         listaTweetow[[i]] <- data.frame(tekst = df_tweety_od$text, 
                                         kandydat = df_tweety_od$screenName, 
                                         data = df_tweety_od$created)
         
         #ramka danych zapisywana jest jako plik tekstowy
         write.table(listaTweetow[[i]], 
                     file = stri_paste(kandydaci[i], ".txt"), append = TRUE, 
                     row.names = FALSE)
         
      }
      
      #zapisujemy date poboru tweetow jako plik tekstowy 
      writeLines(as.character(Sys.time()), stri_paste(katalog, "\\", data_pob))
      
   }

   ilosc <- list()
   
   #dla kazdego kandydata wyliczamy liczbe tweetow w podziale na dni
   for(i in seq_along(kandydaci)){
      nazwisko <- read.table(stri_paste(katalog, "\\", kandydaci[i], ".txt"), 
                             header = TRUE, sep = "", row.names = NULL)
      daty <- nazwisko$kandydat
      teksty <- nazwisko$row.names 
      rozdziel <- split(teksty, daty)
      ilosc[[i]] <- sapply(rozdziel, length)
      
      #wyniki zapisujemy w plikach tekstowych
      write.table(ilosc[[i]], 
                  file = stri_paste("ilosc-", kandydaci[i], ".txt"), 
                  append = TRUE, col.names = FALSE)
   }
   
   #generujemy dodatkowo liste nazwana
   structure(ilosc, 
             names = c("Andrzej Duda", "Bronislaw Komorowski", 
                       "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", 
                       "Janusz Korwin-Mikke", "Pawel Kukiz"))
}

