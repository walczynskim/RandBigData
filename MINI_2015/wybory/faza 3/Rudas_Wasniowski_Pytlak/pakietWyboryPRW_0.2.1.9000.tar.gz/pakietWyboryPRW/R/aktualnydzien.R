#' Wypisywanie biezacej daty
#'
#' Funkcja \code{aktualnydzien} zwraca aktualna date.
#'
#' @usage
#' \code{aktualnydzien()}
#'
#' @return Zwraca aktualna date jako napis w formacie dd-mm-rrrr.
#'
#' @examples
#' aktualnydzien()
#'
aktualnydzien<-function()
{
   #Przerabianie daty z formatu POSIX na stringa
   t<-unlist(stri_extract_all_regex(strftime(Sys.time()),
                                    "([0-9]{4})-([0-9]{2})-([0-9]{2})"))
   #Dbamy o to, zeby format byl dd-mm-rrrr
   stri_replace_all_regex(t,"([0-9]{4})-([0-9]{2})-([0-9]{2})",
                          "$3-$2-$1")
}