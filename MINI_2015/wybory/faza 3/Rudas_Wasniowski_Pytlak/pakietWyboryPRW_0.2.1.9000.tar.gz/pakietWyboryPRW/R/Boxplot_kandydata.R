#' wyliczenie wykresow boxplot dla danego kandydata dla roznych czasow
#'
#' Funkcja \code{Boxplot_kandydata} rysuje wykres boxplot przedstawiajacy czestotliwosci dla ustalonego kandydata.
#' Czestotliwosci sa zliczane co pewien czas.
#'
#' @usage
#' \code{Boxplot_kandydata(dane,zrodlo,co,kand,coile,od_ktorego,do_ktorego)}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param kand napis ktorego kandydata wybieramy.
#' @param coile wartosc liczbowa okreslajaca na ile dzielimy przedzial od pierwszego pobierania do dzisiejszej daty.
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#'
#' @details \code{Boxplot_kandydata} rysuje wykres boxplot, na osi x mamy czas, na y
#' wartosci czestotliwosci(patrz funkcja czestotliwosc) liczone od daty z parametru od_ktorego do daty z osi x.
#'
#' @return wykres zaleznosci miedzy czasami, a czestotliwosciami wystepowan.
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' Boxplot_kandydata(d,"brak","tytul",kand="Duda",20,as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
Boxplot_kandydata<-function(dane,zrodlo,co,kand,coile,od_ktorego,do_ktorego)
{
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   #tu zbieramy dane o czestotliwosciach
   df<-data.frame()
   przedzial<-as.numeric((do_ktorego-od_ktorego)/coile)
   temp2<-which(nazwiska==kand)
   for(i in 1:coile)
   {
      temp<-od_ktorego+przedzial*i
      temp1<-czestotliwosc(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                                    "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                    "$3-$2-$1"),stri_replace_all_regex(as.character(temp) ,
                                                                                                       "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                                       "$3-$2-$1"),czyczasy=TRUE)
      temp1<-temp1[[temp2]]
      df_temp<-data.frame(nazwisko=rep(temp,length(temp1)),wartosci=temp1)
      df<-rbind(df,df_temp)



   }
   df
   #wykres
   tyt<-"Boxploty wzgledem czasu dla"
   nazwisko<-c("Komorowskiego","Kowalskiego","Dudy","Palikota","Jarubasa","Ogorek","Korwina",
               "Wilka","Brauna","Kukiza")
   tytul<-stri_paste(tyt,nazwisko[temp2],sep=" ")
   p<-ggplot(df, aes(x=factor(nazwisko),y=wartosci)) +geom_boxplot()+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab("czas") + ylab("Czestosc(godziny)")+theme(axis.text.x = element_text(angle = 90, hjust = 1))

}
