#' Wyznaczenie czestotliwosci wystapien kandydatow
#'
#' Funkcja \code{czestotliwosc} wyznacza liste czasow (w godzinach) miedzy kolejnymi artykulami o kandydacie
#' ewentualnie liczy na nich miary i nadaje rangi.
#'
#' @usage
#' \code{czestotliwosc(dane,podajzrodlo,co,datapocz,datakonc,funkcja=mean,czyczasy)}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param podajzrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow: dostepne wartosci "tytul","tagi","tresc".
#' @param datapocz data w postaci napisu dd-mm-YYYY od ktorej rozpatrujemy artykuly (wczesniejszych nie bierzemy pod uwage).
#' @param datakonc data data w postaci napisu dd-mm-YYYY do ktorej rozpatrujemy artykuly (pozniejszych nie bierzemy pod uwage).
#' @param funkcja funkcja okreslajaca jaka miare dla wektora czestosci chcemy uzyc domyslnie mean.
#' @param czyczasy wartosc logiczna okreslajaca czy ma byc wyrzucana lista czestotliwosci, czy funkcja od wektora
#' czestotliwosci (np. mean lub median).
#'
#' @details \code{czestotliwosc} wyznacza rozne rzeczy zwiazane z czestotliwoscia. Jesli argument czyczasy ma wartosc
#' TRUE wowczas zwracana jest lista wektorow zawierajacych dane liczbowe okreslajace czas (w godzinach) miedzy pojawieniami sie kolejnych
#' artykulow w ktorych kandydat jest widoczny. Kazdy taki wektor dotyczy innego kandydata. Jesli argument czyczasy ma wartosc
#' FALSE wowczas na kazdym takim wektorze (czyli dla kazdego kandydata) liczona jest miara np. srednia i w zaleznsci od wartosci miary
#' jest przydzielana waga na zasadzie: 0 - zaden artykul sie nie pojawil,1 - wartosc miary powyzej 168h(tydzien),2 - wartosc miary ponizej 168h(tydzien),
#' 3 - wartosc miary ponizej 96h(cztery doby),4 - wartosc miary ponizej 48h(dwie doby),5 - wartosc miary ponizej 24h(doba)
#'
#' @return Jesli czyczasy=TRUE zwraca liste czasow (w godzinach) miedzy kolejnymi wystapieniami kandydata, jesli
#' FALSE otrzymujemy liste dwuelementowa w pierwszym elemencie mamy miare dla kazdego kandydata w drugim range
#' mu przyporzadkowana
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' czestotliwosc(d,"gazeta.pl","tytul",datapierwszgopobrania(d,"gazeta.pl"),aktualnydzien(),czyczasy=FALSE)
#' czestotliwosc(d,"gazeta.pl","tytul",datapierwszgopobrania(d,"gazeta.pl"),"07-04-2015",czyczasy=TRUE)
#' czestotliwosc(d,"brak","tytul",datapierwszgopobrania(d,"brak"),aktualnydzien(),czyczasy=FALSE)
#'




czestotliwosc<-function(dane,podajzrodlo,co,datapocz,datakonc,funkcja=mean,czyczasy)
{

   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   #Przerobienie na POSIX
   datapocz<-stri_paste(datapocz,"00:00",sep=" ")
   datakonc<-stri_paste(datakonc,"23:59",sep=" ")
   pocz<-strptime(datapocz,"%d-%m-%Y %H:%M")
   konc<-strptime(datakonc,"%d-%m-%Y %H:%M")



   #Chcemy rozpatrywac tylko z podanego zrodla, chyba ze mamy "brak"
   if(podajzrodlo!="brak")
   {
      danegazeta<-dane[dane$zrodlo==podajzrodlo,]
   }
   else
   {
      danegazeta<-dane
   }
   # Ponizsza lista bedzie przechowywac roznice czasow miedzy kolejnymi artykulami
   czasykandydatow<-list()
   #wektor wag
   waga<-rep(0,length(kandydat))
   #Czas aktualny
   #wektor ktory bedzie zliczal maksymalna roznice czasu (miedzy datakonc i data pocz)
   maxtime<-as.numeric(konc-pocz,units="hours")
   #licz dla kazdego kandydata wektor opisujacy roznice w godzinach miedzy kolejnymi artykulami
   for(i in 1:length(kandydat))
   {
      #czasy artykulow kandydatow
      artykulykandydatow<-danegazeta[stri_detect_regex(danegazeta[,co],kandydat[i]),]$data
      #zamiana na POSIXct i sortowanie czasow

      artykulykandydatow <- stri_replace_all_regex(artykulykandydatow ,
                                                   "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                   "$3-$2-$1")
      times<-sort(strptime(artykulykandydatow, "%d-%m-%Y %H:%M"))

      # chcemy miec tylko te ktore sie mieszcza w przedziale [datapocz,datakonc]
      times<-times[which(times>=pocz&times<=konc)]


      # (zabezpieczamy sie przed sytuacja dlugo nic,
      # dwa artykuly blisko siebie, dlugo nic temu samemu sluzy odejmowanie od czasu pierwszego
      # artykulu czasu pierwszego pobranego artykulu dla danego portalu)
      times1<-c(times,konc)
      times2<-c(pocz,times)
      #liczymy roznice
      czasykandydatow[[i]]<-as.numeric(times1-times2,units="hours")
   }
   if(czyczasy)
   {
      names(czasykandydatow)<-nazwiska
      czasykandydatow
   }
   else
   {
      #wylicz miare
      srednie<-sapply(czasykandydatow,funkcja)
      #przypisz nazwy
      names(srednie)<-nazwiska
      #Przyjmuje skale widocznosci od 0 do 5
      #0 - zaden artykul sie nie pojawil
      #1 - sredni czas powyzej 168h(tydzien)
      #2 - sredni czas ponizej 168h(tydzien)
      #3 - sredni czas ponizej 96h(cztery doby)
      #4 - sredni czas ponizej 48h(dwie doby)
      #5 - sredni czas ponizej 24h(doba)

      waga[which(srednie<24)]<-5
      waga[which(srednie>=24&srednie<48)]<-4
      waga[which(srednie>=48&srednie<96)]<-3
      waga[which(srednie>=96&srednie<168)]<-2
      waga[which(srednie>=168&srednie<maxtime)]<-1
      names(waga)<-nazwiska
      list(srednie,waga)
   }

}
