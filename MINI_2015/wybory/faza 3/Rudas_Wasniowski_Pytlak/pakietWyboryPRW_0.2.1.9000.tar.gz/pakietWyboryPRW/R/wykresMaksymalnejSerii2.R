#' wylicznie wykresow slupkowych przedstawiajacych maksymalna serie dla kazdego kandydata
#'
#' Funkcja \code{wykresMaksymalnejSerii2} rysuje wykres slupkowy przedstawiajacy maksymalna serie dla poszczegolnych kandydatow.
#' Maksymalne serie sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{wykresMaksymalnejSerii2(dane,zrodlo,co,od_ktorego,do_ktorego,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresMaksymalnejSerii2} rysuje wykres slupkowy, na osi x mamy poszczegolnych kandydatow, na y
#' wartosci maksymalnej serii dla kazdego z nich. Pod osia x jest informacja z jakiego przedzialu
#' czasu ropatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a maksymalna seria na danym przedziale czasu.
#'
#' @examples
#' d<-read.table(file.path(getwd(),"projekt_wybory_R_i_big_data","artykuly","artykuly.txt"))
#' wykresMaksymalnejSerii2(d,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
wykresMaksymalnejSerii2<-function(dane,zrodlo,co,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                                 "Wilk","Braun","Kukiz"))
{
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   df<-data.frame()
   #liczymy na przedziale czasumaksymalna serie dla kazdego kandydata
   temp<-iloscDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                        "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                        "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                           "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                           "$3-$2-$1"))





   #dolaczamy do ramki danych
   df<-rbind(df,temp)
   colnames(df)<-nazwiska

   #dolaczamy id
   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tych ktorych chcemy
   df<-df[,c(ktorzykandydaci,"id")]
   dfm <- melt(df, id.var = c("id"))
   #tworzenie tytulu wykresu
   tytul<-"Dlugosc serii maksymalnej dla kandydatow"

   #tworzenie napisu przy osi x
   skladowa_x1<-"od dnia"
   skladowa_x2<-"do dnia"
   xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
   #wykres
   p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab(xlab1) + ylab("Maksymalna dlugosc serii")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
