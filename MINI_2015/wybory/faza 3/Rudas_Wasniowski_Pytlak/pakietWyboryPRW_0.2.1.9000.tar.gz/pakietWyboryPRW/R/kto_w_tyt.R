#' Czy kandydat wystepuje w tytule
#' 
#' Funkcja \code{kto_w_tyt} zwracaja ramke danych z informaczja czy dany
#'  kandydat wystepuje w tytule
#' 
#' @param dane dane o artyku�ach z portali
#' 
#' @return ramka danych
#' 
#' @examples 
#' ## Not run:
#' pora_dnia(dane)
#' ## End(**Not run**)
#' 
#' @import dplyr
#' @import stringi
#' 


kto_w_tyt <- function(dane){
   # dane<-read.table(sciezka,stringsAsFactors=FALSE,h=TRUE)
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og�rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski", "Duda", "Palikot", "Jarubas", "Ogorek", 
                 "Korwin-Mikke","Wilk","Braun","Kukiz")
   names(kandydat) <- nazwiska
   
   
   czy_nazwisko<-lapply(kandydat,function(x){
      stri_count_regex(dane$tytul,x)
   })
   cbind(dane, czy_nazwisko)
}