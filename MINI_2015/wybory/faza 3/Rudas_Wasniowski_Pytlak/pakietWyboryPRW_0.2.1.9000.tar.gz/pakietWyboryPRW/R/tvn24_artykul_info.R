#' Wyszukiwanie informacji z portalu tvn24.pl z zakladki wybory
#'
#' Funkcja \code{tvn24_artykul_info} sciaga artykuly z portalu tvn24.pl z zakladki wybory.
#'
#' @usage
#' \code{tvn24_artykul_info(link,id)}
#'
#' @param link napis beadacy linkiem do strony danego artykulu z portalu tvn24.pl(struktura linku jak w przykladzie).
#' @param id liczba bedaca id  pobranego artykulu (aby pobrane dane byly uporzadkowane).
#' @details \code{tvn24_artykul_info} przeszukuje strone danego artykulu z portalu tvn24.pl szukajac
#' przydatnych informacji o nim takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, liczba komentarzy.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to tvn24.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy.
#'
#' @examples
#' tvn24_artykul_info("http://www.tvn24.pl/wiadomosci-z-kraju,3/wybieramy-prezydenta-jak-oddac-wazny-glos,540880.html",1)
#'
tvn24_artykul_info<-function(link,id){
   adresartykulu<-html(link)
   #Pobierz zrodlo
   zrodlo<-"tvn24.pl"
   #Pobierz tytul
   tytul<-html_nodes(adresartykulu,"article > h1 > span") %>% 
      html_text(encoding="UTF-8")
   if(length(tytul)==0)
   {
      tytul<-html_nodes(adresartykulu,"div.mainContainer > h1") %>% 
      html_text(encoding="UTF-8")
   }
   tytul<-stri_trim(tytul)
   #Pobierz tagi
   tagi<-html_nodes(adresartykulu,"div.relatedTopic > ul > li > a")%>%html_text(encoding="UTF-8")
   if(length(tagi)>0)
   {
      tagi<-stri_trim(tagi) %>% stri_paste(collapse = ",")
   }
   else 
      tagi<-""
   #Pobierz czas
   czas<-html_nodes(adresartykulu,"div.articleDateContainer.borderGreyBottom > time") %>%
      html_attr("datetime")
   # Czasem czasy nie sa w formacie cyfrowym tylko maja nazwe miesiaca podana slownie
   # Trzeba wtedy podmieniac na liczbe.
   if(stri_detect_regex(czas,"stycznia"))
   {
      czas<-podmien_date(czas,"stycznia","01")
      
   }
   if(stri_detect_regex(czas,"lutego"))
   {
      czas<-podmien_date(czas,"lutego","02")
      
   }
   if(stri_detect_regex(czas,"marca"))
   {
      czas<-podmien_date(czas,"marca","03")
      
   }
   if(stri_detect_regex(czas,"kwietnia"))
   {
      czas<-podmien_date(czas,"kwietnia","04")
      
   }
   if(stri_detect_regex(czas,"maja"))
   {
      czas<-podmien_date(czas,"maja","05")
      
   }
   if(stri_detect_regex(czas,"czerwca"))
   {
      czas<-podmien_date(czas,"czerwca","06")
      
   }
   if(stri_detect_regex(czas,"lipca"))
   {
      czas<-podmien_date(czas,"lipca","07")
      
   }
   if(stri_detect_regex(czas,"sierpnia"))
   {
      czas<-podmien_date(czas,"sierpnia","08")
      
   }
   if(stri_detect_regex(czas,"września"))
   {
      czas<-podmien_date(czas,"września","09")
      
   }
   if(stri_detect_regex(czas,"października"))
   {
      czas<-podmien_date(czas,"października","10")
      
   }
   if(stri_detect_regex(czas,"listopada"))
   {
      czas<-podmien_date(czas,"listopada","11")
      
   }
   if(stri_detect_regex(czas,"grudnia"))
   {
      czas<-podmien_date(czas,"grudnia","12")
      
   }
   #Pobierz tresc
   tresc1<-html_nodes(adresartykulu," article > h2.size18.mt10.mb15") %>% html_text(encoding="UTF-8")%>%stri_trim()
   tresc2<-html_nodes(adresartykulu,"div > div.articleDetailHolder > article > p") %>% html_text()
   tresc2<-tresc2[-length(tresc2)]%>%stri_trim()%>%stri_replace_all_regex("(if(\\n|.)+\\}|\\n|\\r|\\t)"," ")
   if(length(tresc1)==0)
   {
      tresc<-tresc2
   }
   else
   {
      if(length(tresc2)==0)
      {
         tresc<-tresc1
      }
      else
      {
         tresc<-stri_paste(tresc1,tresc2,collapse = " ")
      }
   }
   
   #Pobierz liczbe komentarzy
   liczba_kom<-html_nodes(adresartykulu,"#forum > div.headerBgGrey.mb15 > h1 > span")
   liczba_kom<-html_text(liczba_kom)%>%stri_extract_all_regex("[0-9]+")%>%unlist()
   if(length(liczba_kom)==0)
      liczba_kom<-"0"
   #Zwroc ramke danych
   data.frame("id"=id,"zrodlo"=zrodlo,"data"=czas,"tytul"=tytul,"tresc"=tresc,
              "tagi"=tagi,"liczba komentarzy"=liczba_kom)
   
}

#Funkcja pomocnicza przetwarzajaca nazwy miesiacow na liczby
podmien_date<-function(data,miesiac,nrmiesiaca)
{
   data<-stri_replace_all_regex(data,miesiac,nrmiesiaca)
   data<-stri_replace_all_regex(data," ","-")
   stri_replace_all_regex(data,"([0-9]{2})-([0-9]{2})-([0-9]{4})","$3-$2-$1") 
}