#' Wykres liczby artykulow w ggvisie.
#'
#'
#' Funkcja \code{kandydaci_dla_strony} dla wybranej strony przedzialu czas oraz zbioru danych
#' uzyskanego z ciagu poprzednich funckji z tego pakietu oraz wybranych kandydatow rysuje wykres
#' ilosci artykulow  jwj dotyczacych.
#'
#'
#' @param kstrina jedna ze stron na prezydenta dla ktorej chcemy rysowac wykres
#' @param czasOd czas (w formacie character) od ktorego chcemy miec przedstawione dane na wykresie
#' @param czasDoc zas (w formacie character) do ktorego chcemy miec przedstawione dane na wykresie
#' @param dataTemp zbior danych
#' @param c1-c10 to ktore strony maja sieznalesc na wykresie np c2=1 znajduje sie na wykresie
#' c2=0 nie
#'
#' @examples
#' kandydaci_dla_strony('TvPInfo','2015-04-01','2015-05-01', 'example.csv', 1,1,1,0,0,0,0,0,0)
#'
#' @import ggvis
#' @import dplyr
#'
#' @author Emilia Momotko, Martyna śpiewak, Pawel Grabowski

kandydaci_dla_strony <- function(strona, czasOd, czasDo, dataTemp,c1=1,c2=1,c3=1,
                               c4=1,c5=1,c6=1,c7=1,c8=1,c9=1,c10=1) {

  add_title <- function(vis, ..., x_lab = 'Czas')
  {
    add_axis(vis, "y", title=strona) %>%
      add_axis("x", title = x_lab, ticks = 0,
               properties = axis_props(
                 axis = list(stroke = "white"),
                 labels = list(fontSize = 0)
               ), ...)
  }

  stopifnot(is.character(strona), length(strona) == 1, is.data.frame(dataTemp))
  names22 <- names(dataTemp)[1:10]
  dataTemp[is.na(dataTemp)] <- 0
  dataTemp <- dataTemp[c('date','surname',strona)]
  #filtering data
  dataTemp1 <- dataTemp %>% filter(surname=='komorowski')  %>% select(-surname)
  names(dataTemp1)[2] <- 'surnameKomorowski'
  dataTemp2 <- dataTemp %>% filter(surname=='duda') %>% select(-surname)
  names(dataTemp2)[2] <- 'surnameDuda'
  dataTemp3 <- dataTemp %>% filter(surname=='ogorek') %>% select(-surname)
  names(dataTemp3)[2] <- 'surnameOgorek'
  dataTemp4 <- dataTemp %>% filter(surname=='korwin') %>% select(-surname)
  names(dataTemp4)[2] <- 'surnameKorwin'
  dataTemp5 <- dataTemp %>% filter(surname=='kukiz')  %>% select(-surname)
  names(dataTemp5)[2] <- 'surnameKukiz'
  dataTemp6 <- dataTemp %>% filter(surname=='jarubas')  %>% select(-surname)
  names(dataTemp6)[2] <- 'surnameJarubas'
  dataTemp7 <- dataTemp %>% filter(surname=='palikot') %>% select(-surname)
  names(dataTemp7)[2] <- 'surnamePalikot'
  dataTemp8 <- dataTemp %>% filter(surname=='wilk') %>% select(-surname)
  names(dataTemp8)[2] <- 'surnameWilk'
  dataTemp9 <- dataTemp %>% filter(surname=='braun')  %>% select(-surname)
  names(dataTemp9)[2] <- 'surnameBraun'
  dataTemp10 <- dataTemp %>% filter(surname=='tanajno')  %>% select(-surname)
  names(dataTemp10)[2] <- 'surnameTanajno'
  dataFinal <- merge(dataTemp1,dataTemp2, all=TRUE) %>% merge(dataTemp3, all=TRUE)  %>% merge(dataTemp4, all=TRUE)  %>%
    merge(dataTemp5, all=TRUE)  %>% merge(dataTemp6, all=TRUE)  %>% merge(dataTemp7, all=TRUE)  %>% merge(dataTemp8, all=TRUE)  %>%
    merge(dataTemp9, all=TRUE)  %>% merge(dataTemp10, all=TRUE)


  #dataTemp <- dataTemp[c('date','surname',strona)]
  odTemp <- which(dataTemp$date == czasOd)[1]
  doTemp <- which(dataTemp$date == czasDo)[length(which(dataTemp$date == czasDo))]
  dataTemp <- dataTemp[odTemp:doTemp,]
  #plotting for every site
  xlabTemp <- paste0("Czas od ", czasOd, " do ", czasDo)

  whichCandidates <- c('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7','p8','p9','p10')
  whichCandidates <- whichCandidates[as.logical(c(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10))]
  if(c1==1) {
    p1 <- dataFinal %>% ggvis(~date,~surnameKomorowski) %>% layer_lines(stroke=factor("Komorowski")) %>% add_title(x_lab=xlabTemp)} else p1=0
  if(c2==1) {
    p2 <- dataFinal  %>% ggvis(~date,~surnameDuda) %>% layer_lines(stroke=factor("Duda")) %>% add_title(x_lab=xlabTemp)} else p2=0
  if(c3==1) {
    p3 <- dataFinal  %>% ggvis(~date,~surnameOgorek) %>% layer_lines(stroke=factor("Ogorek")) %>% add_title(x_lab=xlabTemp) } else p3=0
  if(c4==1) {
    p4 <- dataFinal  %>% ggvis(~date,~surnameKorwin) %>% layer_lines(stroke=factor("Korwin")) %>% add_title(x_lab=xlabTemp)}else p4=0
  if(c5 ==1) {
    p5 <- dataFinal  %>% ggvis(~date,~surnameKukiz) %>% layer_lines(stroke=factor("Kukiz")) %>% add_title(x_lab=xlabTemp)}else p5=0
  if(c6 ==1) {
    p6 <- dataFinal  %>% ggvis(~date,~surnameJarubas) %>% layer_lines(stroke=factor("Jarubas")) %>% add_title(x_lab=xlabTemp)}else p6=0
  if(c7 ==1) {
    p7 <- dataFinal  %>% ggvis(~date,~surnamePalikot) %>% layer_lines(stroke=factor("Palikot")) %>% add_title(x_lab=xlabTemp)}else p7=0
  if(c8 ==1) {
    p8 <- dataFinal  %>% ggvis(~date,~surnameWilk) %>% layer_lines(stroke=factor("Wilk")) %>% add_title(x_lab=xlabTemp)}else p8=0
  if(c9 ==1) {
    p9 <- dataFinal  %>% ggvis(~date,~surnameBraun) %>% layer_lines(stroke=factor("Braun")) %>% add_title(x_lab=xlabTemp)}else p9=0
  if(c10 ==1){
    p10 <- dataFinal  %>% ggvis(~date,~surnameTanajno) %>% layer_lines(stroke=factor("Tanajno")) %>% add_title(x_lab=xlabTemp)}else p10=0
  vis_list <- lapply(whichCandidates, FUN = function(x) eval(parse(text=x)))
  out <- do.call(Map, c(list(`c`), vis_list ))
  attributes(out) <- attributes(vis_list[[1]])
  out
}
