#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_wyborcza_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.wyborcza.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_wyborcza_pl()
#'
#'
#'#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr


parsuj_wyborcza_pl <- function(){
  data <- as.character(Sys.Date())
  url <- "http://wyborcza.pl/0,0.html?piano_d=1"
  df <- data.frame()
  parsed_page <- html(url)
  slownik <- slownik()

  main_articles <- html_nodes(parsed_page, "#LinkArea\\:MagMagSwi1 ")
  if(length(main_articles)>0){
    main_titles <- sapply(main_articles, xmlGetAttr, "title") %>%
      unlist(main_titles[!sapply(., is.null)]) %>%
      stri_replace_all_regex(., ';', "") %>%
      stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
    url_main_titles <- sapply(main_articles, xmlGetAttr, "href") %>%
      unlist(url_main_titles[!sapply(., is.null)])
    ktore <- sapply(main_titles, function(x) sprawdz_czy_wybory(slownik,x))
    if(sum(ktore) > 0) {
      df <- rbind(df, data.frame(date=data, portal=url, title=main_titles[ktore],
                                 position=4,link=url_main_titles[ktore]))
    }
  }

  main2_articles <- html_nodes(parsed_page, ".article #LinkArea\\:kraj")
  main2_titles <- xmlToDataFrame(main2_articles)
  main2_titles <- as.vector(main2_titles$text) %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," ")) %>%
    '['(.!="")
  url_main2_titles <- sapply(main2_articles, html_attr, "href") %>%
    unique(.)
  ktore <- sapply(main2_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url, title=main2_titles[ktore],
                               position=3,link=url_main2_titles[ktore]))
  }

  right_articles <- html_nodes(parsed_page, ".article #LinkArea\\:najnowsze")
  right_titles  <- xmlToDataFrame(right_articles)
  right_titles <- as.vector(right_titles$text) %>%
    right_titles[sapply(.,function(x) x!="\n")] %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  url_right_titles <- sapply(right_articles, html_attr, "href") %>%
    unique(.)
  ktore <- sapply(right_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url, title=right_titles[ktore],
                             position=2,link=url_right_titles[ktore]))
  }

  other_articles <- html_nodes(parsed_page, "#bottom_wrap .content a")
  other_titles <- sapply(other_articles,html_attr, "title") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  url_other_titles <- sapply(other_articles, html_attr, "href")
  ktore <- sapply(other_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url, title=other_titles[ktore],
                             position=3,link=url_other_titles[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}
