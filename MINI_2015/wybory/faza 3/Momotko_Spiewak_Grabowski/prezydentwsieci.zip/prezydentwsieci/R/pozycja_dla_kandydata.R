#' Wykres liczby artykulow o okreslonej pozycji w ggvisie.
#'
#'
#' Funkcja \code{pozycja_dla_kandydata} dla wybranego kandydata i przedzialu czas oraz zbioru danych
#' uzyskanego z ciagu poprzednich funckji z tego pakietu oraz wybranych pozycji artykulow rysuje wykres.
#'
#'
#' @param kandydat jeden z kandydatow na prezydenta dla ktorego chcemy rysowac wykres
#' @param czasOd czas (w formacie character) od ktorego chcemy miec przedstawione dane na wykresie
#' @param czasDoc zas (w formacie character) do ktorego chcemy miec przedstawione dane na wykresie
#' @param dataTemp zbior danych
#' @param p1-p10 to ktore artykuly o okreslonej pozyjci maja sieznalesc na wykresie np p2=1 znajduje sie na wykresie
#' cp=0 nie
#'
#' @examples
#' pozycja_dla_kandydata('komorowski','2015-04-01','2015-05-01', 'example.csv', 1,1,1,0,0,0,0,0,0)
#'
#' @import ggvis
#' @import dplyr
#'
#' @author Emilia Momotko, Martyna śpiewak, Pawel Grabowski


pozycja_dla_kandydata <- function(kandydat, czasOd, czasDo, dataTemp,p1=1,p2=1,p3=1,p4=1) {

  add_title <- function(vis, ..., x_lab = 'Czas')
  {
    add_axis(vis, "y", title="Liczba postow") %>%
      add_axis("x", title = x_lab, ticks = 0,
               properties = axis_props(
                 axis = list(stroke = "white"),
                 labels = list(fontSize = 0)
               ), ...)
  }

  stopifnot(is.character(kandydat), length(kandydat) == 1, is.data.frame(dataTemp))
  dataTemp[is.na(dataTemp)] <- 0
  #filtering data
  dataTemp <- dataTemp %>%
    filter(., Nazwisko == kandydat)
  dataTemp1 <- dataTemp %>% filter(position==1) %>% group_by(date) %>% summarise(liczbaPostow11= n())
  dataTemp2 <- dataTemp %>% filter(position==2) %>% group_by(date) %>% summarise(liczbaPostow22= n())
  dataTemp3 <- dataTemp %>% filter(position==3) %>% group_by(date) %>% summarise(liczbaPostow33= n())
  dataTemp4 <- dataTemp %>% filter(position==4) %>% group_by(date) %>% summarise(liczbaPostow44= n())
  dataTempFinal <- merge(dataTemp1,dataTemp2, all=TRUE) %>%merge(dataTemp3, all=TRUE) %>% merge(dataTemp4, all=TRUE)
  dataTempFinal[is.na(dataTempFinal)] <- 0
  odTemp <- which(dataTempFinal$date == czasOd)[1]
  if(is.na(which(dataTempFinal$date == czasOd)[1])) {daty <-as.character(c(as.Date(czasOd)+1,as.Date(czasOd)-1,
                                                                           as.Date(czasOd)+2,as.Date(czasOd)-2,as.Date(czasOd)+3,as.Date(czasOd)-3))
  xx <- sapply(daty, FUN=function(x){which(dataTempFinal$date==x)[1]})
  odTemp <- xx[!is.na(xx)][1]}
  doTemp <- which(dataTempFinal$date == czasDo)[length(which(dataTempFinal$date == czasDo))]
  if(is.na(which(dataTempFinal$date == czasOd)[1])) {daty <-as.character(c(as.Date(czasDo)+1,as.Date(czasDo)-1,
                                                                           as.Date(czasDo)+2,as.Date(czasDo)-2,as.Date(czasDo)+3,as.Date(czasOd)-3))
  xx <- sapply(daty, FUN=function(x){which(dataTempFinal$date==x)[1]})
  doTemp <- xx[!is.na(xx)][1]}
  dataTemp <- dataTempFinal[odTemp:doTemp,]
  #plotting for every site
  xlabTemp <- paste0("Czas od ", czasOd, " do ", czasDo)

  whichPosition <- c('plot1', 'plot2', 'plot3', 'plot4')
  whichPosition <- whichPosition[as.logical(c(p1,p2,p3,p4))]
  if(p1==1) {
    plot1 <-dataTempFinal  %>%
      ggvis(~date,~liczbaPostow11) %>% layer_lines(stroke=factor("pozycja1")) %>% add_title(x_lab=xlabTemp)} else plot1=0
  if(p2==1) {
    plot2 <-  dataTempFinal  %>%
      ggvis(~date,~liczbaPostow22) %>% layer_lines(stroke=factor("pozycja2")) %>% add_title(x_lab=xlabTemp)} else plot2=0
  if(p3==1) {
    plot3 <-   dataTempFinal  %>%
      ggvis(~date,~liczbaPostow33) %>% layer_lines(stroke=factor("pozycja3")) %>% add_title(x_lab=xlabTemp) } else plot3=0
  if(p4==1) {
    plot4 <-   dataTempFinal  %>%
      ggvis(~date,~liczbaPostow44) %>% layer_lines(stroke=factor("pozycja4")) %>% add_title(x_lab=xlabTemp)} else plot4=0
  vis_list <- lapply(whichPosition, FUN = function(x) eval(parse(text=x)))
  out <- do.call(Map, c(list(`c`), vis_list ))
  attributes(out) <- attributes(vis_list[[1]])
  out
}
