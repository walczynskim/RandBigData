#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_tvn24_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.tvn24.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_tvn24_pl()
#'
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr



parsuj_tvn24_pl <- function(){
  url <- "http://www.tvn24.pl/"
  doc <- html(url)
  df <- data.frame()
  data <- as.character(Sys.Date())
  slownik <- slownik()

  glowna_text <- stri_trim_both(stri_replace_all_regex(html_text(html_nodes(doc,".mainContainer :nth-child(1) :nth-child(1) h1 a")),"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))[1:2]
  glowna <- html_node(doc, "#urgentStandard h1 a")
  glowna_link <- html_attr(glowna,"href") %>%
    unname(sapply(.,function(y){
    if(stri_detect_fixed(y,"http")==FALSE){
      return(stri_flatten(c("http://www.tvn24.pl",y)))
    } else return(y)
  }))
  ktore <- sapply(glowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                               title=glowna_text[ktore], position=4,link=glowna_link[ktore]))
  }

  podglowna <- getNodeSet(doc, "//div[@class='mainLeftColumn']//a")
  podglowna_text <- sapply(podglowna,xml_text,"title")
  niepotrzebne <- stri_detect_regex(podglowna_text,"(zobacz wi?cej)|(czytaj dalej)|(^[0-9][0-9]?$)|(?i)(Odtw?rz)")
  podglowna_text <- podglowna_text[!niepotrzebne]
  podglowna_link <- sapply(podglowna,xmlGetAttr,"href")
    '['(!niepotrzebne)
  niepotrzebne2 <- which(podglowna_text=="")
  podglowna_text <- stri_trim_both(stri_replace_all_regex(podglowna_text[-niepotrzebne2],"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  podglowna2_text <- podglowna_text[1:8]
  podglowna_link <- podglowna_link[-niepotrzebne2]
  podglowna2_link <- podglowna_link[1:8] %>%
    unname(sapply(.,function(y){
    if(stri_detect_fixed(y,"http")==FALSE){
      return(stri_flatten(c("http://www.tvn24.pl",y)))
    } else return(y)
  }))
  ktore <- sapply(podglowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                               title=podglowna_text[ktore], position=3,link=podglowna_link[ktore]))
  }


  bok <- getNodeSet(doc, "//ul[@id='newestNewsList']//a")
  bok_text <- stri_trim_both(stri_replace_all_regex(sapply(bok,xml_text,"title"),"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  bok_link <- sapply(bok,xmlGetAttr,"href") %>%
    unname(sapply(.,function(y){
    if(stri_detect_fixed(y,"http")==FALSE){
      return(stri_flatten(c("http://www.tvn24.pl",y)))
    } else return(y)
  }))
  ktore <- sapply(bok_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                               title=bok_text[ktore], position=2,link=bok_link[ktore]))
  }

  bok <- getNodeSet(doc, "//ul[@id='importantNewsList']//a")
  bok_text <- stri_trim_both(stri_replace_all_regex(sapply(bok,xml_text,"title"),"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  bok_link <- sapply(bok,xmlGetAttr,"href") %>%
    unname(sapply(.,function(y){
    if(stri_detect_fixed(y,"http") == FALSE) {
      return(stri_flatten(c("http://www.tvn24.pl",y)))
    } else return(y)
  }))
  ktore <- sapply(bok_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                               title=bok_text[ktore], position=2,link=bok_link[ktore]))
  }
  dol <- podglowna
  dol_text <- podglowna_text[-(1:8)]
  dol_link <- podglowna_link[-(1:8)] %>%
   unname(sapply(., function(y){
    if(stri_detect_fixed(y,"http")==FALSE){
      return(stri_flatten(c("http://www.tvn24.pl",y)))
    } else return(y)
  }))
  ktore <- sapply(dol_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                               title=dol_text[ktore], position=1,link=dol_link[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}
