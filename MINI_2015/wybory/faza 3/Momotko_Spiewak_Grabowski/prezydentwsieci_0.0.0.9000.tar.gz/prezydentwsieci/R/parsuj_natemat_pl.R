#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_natemat_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.natemat.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_natemat_pl()
#'
#'
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr

parsuj_natemat_pl <- function() {
  url <- "http://natemat.pl/"
  doc <- html(url)
  df <- data.frame()
  data <- as.character(Sys.Date())
  slownik <- slownik()

  glowna <- getNodeSet(doc, "//div[@id='hp-body']//a")
  glowna_text <- stri_trim_both(stri_replace_all_regex(xml_text(glowna,"alt"),
                                                       "(\\n)|(\\t)|(\\r)|(\")|(;)"," "))[2]
  glowna_link <- sapply(glowna,xmlGetAttr,"href")[2]
  ktore <- sapply(glowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                                         title=glowna_text[ktore],
                                         position=4,link=glowna_link[ktore]))
  }


  podglowna <- glowna
  podglowna_text <- stri_trim_both(stri_replace_all_regex(xml_text(
    podglowna,"alt"),"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  niepotrzebne <- which(podglowna_text=="")
  podglowna_text <- podglowna_text[-niepotrzebne]
  niepotrzebne2 <- stri_detect_regex(podglowna_text,"Wiecej zdjec \\([0-9]")
  podglowna_text <- podglowna_text[!niepotrzebne2] %>%
    '['(2:7)
  podglowna_link <- sapply(podglowna,xmlGetAttr,"href") %>%
   '['(-niepotrzebne) %>%
   '['(-niepotrzebne2) %>%
   '['(2:7)
  ktore <- sapply(podglowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                                       title=podglowna_text[ktore],
                                       position=3,link=podglowna_link[ktore]))
  }


  bok <- podglowna
  bok_text <- stri_trim_both(stri_replace_all_regex(xml_text(
    bok,"alt"),"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  niepotrzebne <- which(bok_text=="")
  bok_text <- bok_text[-niepotrzebne]
  niepotrzebne2 <- stri_detect_regex(bok_text,"Wiecej zdjec \\([0-9]")
  bok_text <- bok_text[!niepotrzebne2]
    '['(9:16)
  bok_link <- sapply(bok,xmlGetAttr,"href") %>%
    '['(-niepotrzebne) %>%
    '['(-niepotrzebne2) %>%
    '['(9:16)
  ktore <- sapply(bok_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                                       title=bok_text[ktore], position=2,link=bok_link[ktore]))
  }

  dol <- podglowna
  dol_text <- stri_trim_both(stri_replace_all_regex(xml_text(dol,"alt"),
                                                    "(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  niepotrzebne <- which(dol_text==""|is.na(dol_text))
  dol_text <- dol_text[-niepotrzebne]
  niepotrzebne2 <- stri_detect_regex(dol_text,"Wiecej zdjec \\([0-9]") %>%
  dol_text <- dol_text[!niepotrzebne2]
    '['(-(1:16))
  dol_link <- sapply(dol,xmlGetAttr,"href") %>%
    '['(-niepotrzebne) %>%
    '['(-niepotrzebne2) %>%
    '['(-(1:16))
  ktore <- sapply(dol_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                                       title=dol_text[ktore],
                                       position=1,link=dol_link[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}
