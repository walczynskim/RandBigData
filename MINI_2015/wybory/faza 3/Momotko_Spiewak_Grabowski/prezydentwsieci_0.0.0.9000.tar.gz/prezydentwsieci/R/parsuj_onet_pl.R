#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_onet_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.onet.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_onet_pl()
#'
#'
#'
#'#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr

parsuj_onet_pl <- function(){
  df <- data.frame()
  data <- as.character(Sys.Date())
  url_onet <- "http://www.onet.pl/"
  doc <- html(url_onet)
  slownik <- slownik()

  glowna_text <- html_text(html_nodes(doc,".titleContener .title")) %>%
    stri_replace_all_regex(.,"(\\n)|(\\r)|(\\t)|(;)"," ")
  glowna <- getNodeSet(doc, "//div[@id='bestOfOnet']//a")
  glowna_link <- xmlGetAttr(glowna[[1]],"href")
  ktore <- sapply(glowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url_onet,
                                 title=glowna_text[ktore], position=4, link=glowna_link[ktore]))
  }

  podglowna_text <- html_text(html_nodes(doc,".bottomItem .title")) %>%
    stri_replace_all_regex(.,"(\\n)|(\\r)|(\\t)|(;)"," ")
  podglowna <- getNodeSet(doc, "//div[@class='bestOfOnetSliderFrameInnerStatic']//a")
  podglowna_link <- sapply(podglowna, xmlGetAttr, "href")
  ktore <- sapply(podglowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url_onet,
                                   title=podglowna_text[ktore], position=3,link=podglowna_link[ktore]))
  }

  bok_text <- html_text(html_nodes(doc,"#boxNews .title"))  %>%
    stri_replace_all_regex(.,"(\\n)|(\\r)|(\\t)|(;)"," ")
  bok <- getNodeSet(doc, "//div[@class='boxContent']//a") %>%
    '['(1:length(bok_text))
  bok_link <- sapply(bok, xmlGetAttr, "href")

  ktore <- sapply(bok_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url_onet,
                                 title=bok_text[ktore], position=2,
                                 link=bok_link[ktore]))
  }

  dol_text <- html_text(html_nodes(doc,"#boxLocalNews .title , #boxEconomy .title")) %>%
    stri_replace_all_regex(.,"(\\n)|(\\r)|(\\t)|(;)"," ")
  linki1 <- sapply(getNodeSet(doc, "//section[@data-section='economy']/div[@class='boxContent']//a"),xmlGetAttr,"href")
  linki2 <- sapply(getNodeSet(doc, "//section[@data-section='localnews']/div[@class='boxContent']//a"),xmlGetAttr,"href")
  linki3 <- sapply(getNodeSet(doc, "//section[@data-section='localnews2']/div[@class='boxContent']//a"),xmlGetAttr,"href")
  dol_link <- c(linki1,linki2,linki3)
  ktore <- sapply(dol_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url_onet,
                                 title=dol_text[ktore], position=1,link=dol_link[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}

