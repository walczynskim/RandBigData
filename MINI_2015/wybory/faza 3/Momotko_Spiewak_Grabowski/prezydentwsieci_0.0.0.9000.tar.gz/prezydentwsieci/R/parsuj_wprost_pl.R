#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_wprost_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.wprost.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_wprost_pl()
#'
#'
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr

parsuj_wprost_pl <- function(){
  df <- data.frame()
  data <- as.character(Sys.Date())
  url <- "http://www.wprost.pl/"
  doc <- html(url)
  slownik <- slownik()

  glowna <- getNodeSet(doc, "//h2[@class='art-title']//a")
  urls_glowna <- sapply(glowna, xmlGetAttr, "href")
  tytuly_glowna <- sapply(glowna, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- which(sapply(tytuly_glowna, function(x) sprawdz_czy_wybory(slowa_klucz, x)))
  urls_glowna <- urls_glowna[spr]
  tytuly_glowna <- tytuly_glowna[spr]
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                             title=tytuly_glowna, position=4, link=urls_glowna))
  }

  podglowna <- getNodeSet(doc, "//h3[@class='art-title']//a")
  urls_podglowna <- sapply(podglowna, xmlGetAttr, "href")
  tytuly_podglowna <- sapply(podglowna, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- which(sapply(tytuly_podglowna, function(x) sprawdz_czy_wybory(slowa_klucz, x)))
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                             title=tytuly_podglowna[spr], position=3, link= urls_podglowna[spr]))
  }

  prawy <- getNodeSet(doc, '//ul[@class="newest-list-items"]//a')
  urls_prawy <- sapply(prawy, xmlGetAttr, "href") %>%
    paste0("http://www.wprost.pl", .)
  tytuly_prawy <- sapply(prawy, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- as.vector(which(sapply(tytuly_prawy, function(x) sprawdz_czy_wybory(slowa_klucz, x))))
  urls_prawy <- urls_prawy[spr]
  tytuly_prawy <- tytuly_prawy[spr]
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                             title=tytuly_prawy, position=2, link=urls_prawy))
  }

  url1<-"http://www.wprost.pl/tylko-u-nas/"
  doc1<-html(url1)
  inne <- getNodeSet(doc1,
                     '//span[@class="standard-box-title standard-box-offset-300 standard-box-title-large"]//a')
  urls_inne <- sapply(inne, xmlGetAttr, "href")
     paste0("http://www.wprost.pl", .)
  tytuly_inne <- sapply(inne, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- as.vector(which(sapply(tytuly_inne, function(x) sprawdz_czy_wybory(slowa_klucz, x))))
  urls_inne <- urls_inne[spr]
  tytuly_inne <- tytuly_inne[spr]
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                             title=tytuly_inne, position=1, link=urls_inne))
  }

  inne1 <- getNodeSet(doc1, '//span[@class="standard-box-title standard-box-offset-175 "]//a')
  urls_inne1 <- sapply(inne1, xmlGetAttr, "href") %>%
    paste0("http://www.wprost.pl", .)
  tytuly_inne1 <- sapply(inne1, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "")
  tytuly_inne <- stri_trim_both(stri_replace_all_regex(tytuly_inne,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- as.vector(which(sapply(tytuly_inne1, function(x) sprawdz_czy_wybory(slowa_klucz, x))))
  urls_inne1 <- urls_inne1[spr]
  tytuly_inne1 <- tytuly_inne1[spr]
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                             title=tytuly_inne1, position=1, link=urls_inne1))
  }

 zapisz_do_pliku(df, data)
  return(invisible(NULL))
}
