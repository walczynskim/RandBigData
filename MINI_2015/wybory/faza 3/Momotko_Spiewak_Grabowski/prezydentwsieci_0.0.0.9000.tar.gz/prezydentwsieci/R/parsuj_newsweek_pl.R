#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_newsweek_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.newsweek.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_newsweek_pl()
#'
#'
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr


parsuj_newsweek_pl <- function(){
  url <- "http://www.newsweek.pl/"
  doc <- html(url)
  df <- data.frame()
  data <- as.character(Sys.Date())
  slownik <- slownik()

  glowna_text <- stri_trim_both(stri_replace_all_regex(html_text(html_nodes(doc,"h2"))[1:3],"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  glowna <- getNodeSet(doc, "//div[@class='Article-List-Whole hyphenate special_3items block spacing10 ']//a")
  glowna_link <- sapply(glowna,xmlGetAttr,"href")
  ktore <- sapply(glowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <-rbind(df, data.frame(date=data, portal=url,
                              title=dol_text[ktore], position=4, link=dol_link[ktore]))
  }

  podglowna_text <- stri_trim_both(stri_replace_all_regex(html_text(html_nodes(doc,"h2"))[4:8],"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  podglowna <- getNodeSet(doc, "//div[@class='Article-List-Whole hyphenate block spacing10 ']//a")
  podglowna_link <- sapply(podglowna,xmlGetAttr,"href") %>%
    '['(2:6)
  ktore <- sapply(podglowna_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <-rbind(df, data.frame(date=data, portal=url,
                              title=dol_text[ktore], position=3, link=dol_link[ktore]))
  }

  bok_text <- stri_trim_both(stri_replace_all_regex(html_text(html_nodes(doc,"h2"))[14:18],"(\\n)|(\\t)|(\\r)|(\")|(;)"," "))
  bok <- getNodeSet(doc, "//div[@id='articleList27']//a")
  bok_link <- sapply(bok,xmlGetAttr,"href")[3:7]
  ktore <- sapply(bok_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <-rbind(df, data.frame(date=data, portal=url,
                              title=dol_text[ktore], position=2, link=dol_link[ktore]))
  }

  dol <- getNodeSet(doc, "//div[@class='Article-List-Whole hyphenate block spacing10 ']//a")
  dol_link <- sapply(dol,xmlGetAttr,"href")[16:29][-c(7,12)]
  dol_text <- sapply(dol,xml_text,"title")[16:29] %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")|(;)"," ")) %>%
    unname(sapply(., function(y) stri_flatten(unlist(stri_extract_all_words(y)),collapse=",")))[-c(7,12)]
  ktore <- sapply(dol_text, function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <-rbind(df, data.frame(date=data, portal=url,
                                 title=dol_text[ktore], position=1, link=dol_link[ktore]))
  }

  dol2 <- getNodeSet(doc, "//div[@id='articleList1']//a")
  dol2_link <- sapply(dol2,xmlGetAttr,"href")[-10]
  dol2_text <- sapply(dol2,xml_text,"title") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")|(;)"," ")) %>%
    unname(sapply(.,function(y) stri_flatten(unlist(stri_extract_all_words(y)),collapse=",")))[-10]
  ktore <- sapply(dol_text,function(y) sprawdz_czy_wybory(slownik,y))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url,
                                 title=dol2_text[ktore], position=1,link=dol2_link[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}



slownik <- function() {
  slownik <- c("bronisław", "bronisława", "bronisławowi", "bronisława",
                 "bronisławem", "bronisławie", "bronisławie", "bronislaw",
                 "bronislawa", "bronislawowi","bronislawem","bronkobus",
                 "komorowski",
                 "komorowskiego", "komorowskiemu", "komorowskiego",
                 "komorowskim", "komorowskim", "komorowski", "bronkobus",
                 "bronkobusa","komorowskich","komorowscy",
                 "andrzej", "andrzeja", "andrzejowi", "andrzeja", "andrzejem",
                 "andrzeju",
                 "duda","dudy","dudę","dude","dudą","dudzie",
                 "janusz", "janusza", "januszowi", "januszem", "januszu",
                 "korwin-mikke", "korwin", "mikke", "jkm",
                 "korwin-mikkego","korwina",
                 "wybory","wyborach" ,"prezydent","prezydenta", "prezydenckie",
                 "kampania","kampanią","kampanii","sondaż","pkw","ogórek","ogorek", "kukiz",
                 "jarubas","jarubasa","palikot","palikota","anna grodzka","anny grodzkiej",
                 "annę grodzką","annie grodzkiej","marian kowalski","mariana kowalskiego",
                 "wanda nowicka","wandy nowickiej","kukiz","kukiza","palikot","palikota",
                 "#Braun","Grzegorz Braun","Braun","Brauna",
                 "#AndrzejDuda","Andrzej Duda","Dudę","Dudą","Dudzie",
                 "#Grodzka","Anna Grodzka","Grodzka","Grodzkiej","Grodzką",
                 "#Jankowski","Zdzisław Jankowski","Jankowski",
                 "#Jarubas","Adam Jarubas","Jarubas","jarubas", "jarubasa","palikot", "palikota",
                 "#Jędrzejewski","Józef Jędrzejewski","Jędrzejewski","Jedrzejewskiego","Jędrzejewskiemu",
                 "#KorabKarpowicz","Włodzimierz Korab-Karpowicz","Korab-Karpowicz",
                 "#Komorowski","Bronisław Komorowski","Komorowski","Komorowskiego","Komorowskiemu",
                 "#Korwin","#KornwinMikke","Janusz Korwin-Mikke", "#JKM","JKM","KORWIN","#KORWIN",
                 "Marian Kowalski","Ruch Narodowy",
                 "#Kukiz","Paweł Kukiz","Kukiz","Kukiza","wilk", "wilka",
                 "Dariusz Łaska","Łaska",
                 "Nowicka","Wanda Nowicka","braun", "brauna",
                 "kowalski", "kowalskiego", "kowalskiemu", "kowalskim",
                 "#Ogórek","Magda Ogórek","Ogorek",
                 "#Palikot", "Palikot", "Janusz Palikot",
                 "Tanajno", "tanajno",
                 "Jacek Wilk","Wilk",
                 "prezydent", "prezydenta",
                 "wybory","wybory prezydenckie",
                 "kandydat","kandydata","kandydaci")
  slownik <- stri_enc_toutf8(slownik)
}

sprawdz_czy_wybory <- function(slownik, tekst){
  tekst <- stri_trans_tolower(tekst)
  tmp <- unlist(stri_extract_all_words(tekst))
  res <- any(tmp%in%slownik) | any(tmp%in%stri_trans_tolower(slownik) )
  return(res)
}

zapisz_do_pliku <- function(df, data) {
  if(dim(df)[1] > 0) {
    fname <- paste(getwd(),"/",data,".csv", sep="")
    if (!file.exists(fname)){
      f <- file(fname, open="a")
      writeLines(stri_paste('\"date\"', '\"portal\"', '\"title\"', '\"position\"',
                            '\"link\"', sep = ";"), f)
    } else f <- file(fname, open="a")
    for(i in seq_along(df[,1])){
      writeLines(stri_paste(df[i,1], df[i,2], df[i,3],
                            df[i,4], df[i,5], sep=";"), f)
    }
    close(f)
  }
}



