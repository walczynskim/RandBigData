#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_wp_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.wp.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#' @examples
#' parsuj_wp_pl()
#'
#'
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr

parsuj_wp_pl <- function(){
  df <- data.frame()
  data <- as.character(Sys.Date())
  url_wp <- "http://www.wp.pl"
  doc <- html(url_wp)
  slownik <- slownik()

  glowna <- getNodeSet(doc, "//div[@id='Container']//a")
  urls_glowna <- sapply(glowna, xmlGetAttr, "href")
  tytuly_glowna <- sapply(glowna, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- sapply(tytuly_glowna, function(x) sprawdz_czy_wybory(slowa_klucz, x))
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url_wp,
                                   title=tytuly_glowna[spr], position=4, link= urls_glowna[spr]))
  }

  podglowna <- getNodeSet(doc, "//div[@class='sArt ']//a")
  urls_podglowna <- sapply(podglowna, xmlGetAttr, "href")
  tytuly_podglowna <- sapply(podglowna, xmlValue, "href") %>%
    stri_replace_all_regex(tytuly_podglowna, ';', "") %>%
    stri_trim_both(stri_replace_all_regex(tytuly_podglowna,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- sapply(tytuly_podglowna, function(x) sprawdz_czy_wybory(slowa_klucz, x))
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url_wp,
                                   title=tytuly_podglowna[spr], position=3, link= urls_podglowna[spr]))
  }

  prawy <- getNodeSet(doc, '//div[@class="txtArts"]//a')
  urls_prawy <- sapply(prawy, xmlGetAttr, "href")
  tytuly_prawy <- sapply(prawy, xmlValue, "href") %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  spr <- sapply(tytuly_prawy, function(x) sprawdz_czy_wybory(slowa_klucz, x))
  urls_prawy <- urls_prawy[spr]
  tytuly_prawy <- tytuly_prawy[spr]
  if(length(spr) != 0) {
    df <- rbind(df, data.frame(date=data, portal=url_wp,
                                   title=tytuly_prawy, position=2, link=urls_prawy))
  }


  url_wp_wp <- "http://wiadomosci.wp.pl/kat,140394,title,Wybory-prezydenckie-w-2015-r,raport.html"
  doc_wp <- html(url_wp_wp)
  wybory <- html_nodes(doc_wp, ".stampZrodloData , .kontener h2 a")
  urls_wybory <- na.omit(html_attr(wybory, "href"))
  tmp <- html_text(wybory) %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  tytuly_wybory <- tmp[seq(1, length(tmp), by=2)]
  data_wybory <- tmp[seq(2, length(tmp), by=2)]
  ok <- which(data_wybory==data)
  if(length(ok) != 0) {
    df <- rbind(df, data.frame(date=data_wybory[ok], portal=url_wp,
                                   title=tytuly_wybory[ok], position=1, link=urls_wybory[ok]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))

}
