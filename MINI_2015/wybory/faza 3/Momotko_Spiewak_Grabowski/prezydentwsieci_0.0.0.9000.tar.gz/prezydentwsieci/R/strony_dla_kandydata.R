#' Wykres  liczby artykulow w ggvisie.
#'
#'
#' Funkcja \code{strony_dla_kandydata} dla wybranego kandydata i przedzialu czas oraz zbioru danych
#' uzyskanego z ciagu poprzednich funckji z tego pakietu oraz wybranych stron rysuje wykres
#' ilosci artykulow  jego dotyczacych.
#'
#'
#' @param kandydat jeden z kandydatow na prezydenta dla ktorego chcemy rysowac wykres
#' @param czasOd czas (w formacie character) od ktorego chcemy miec przedstawione dane na wykresie
#' @param czasDoc zas (w formacie character) do ktorego chcemy miec przedstawione dane na wykresie
#' @param dataTemp zbior danych
#' @param c1-c10 to ktore strony maja sieznalesc na wykresie np c2=1 znajduje sie na wykresie
#' c2=0 nie
#'
#' @examples
#' strony_dla_kandydata('komorowski','2015-04-01','2015-05-01', 'example.csv', 1,1,1,0,0,0,0,0,0)
#'
#' @import ggvis
#' @import dplyr
#'
#' @author Emilia Momotko, Martyna śpiewak, Pawel Grabowski


strony_dla_kandydata <- function(kandydat, czasOd, czasDo, dataTemp,c1=1,c2=1,c3=1,
                                 c4=1,c5=1,c6=1,c7=1,c8=1,c9=1,c10=1) {
  add_title <- function(vis, ..., x_lab = 'Czas')
  {
    add_axis(vis, "y", title=kandydat) %>%
      add_axis("x", title = x_lab, ticks = 0,
               properties = axis_props(
                 axis = list(stroke = "white"),
                 labels = list(fontSize = 0)
               ), ...)
  }

  stopifnot(is.character(kandydat), length(kandydat) == 1, is.data.frame(dataTemp))
  names22 <- names(dataTemp)[1:10]
  dataTemp[is.na(dataTemp)] <- 0
  #filtering data
  dataTemp <- dataTemp %>%
    filter(., surname == kandydat)
  odTemp <- which(dataTemp$date == czasOd)
  doTemp <- which(dataTemp$date == czasDo)
  dataTemp <- dataTemp[odTemp:doTemp,]
  #plotting for every site
  xlabTemp <- paste0("Czas od ", czasOd, " do ", czasDo)

  whichSites <- c('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7','p8','p9','p10')
  whichSites <- whichSites[as.logical(c(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10))]
  if(c1==1) {
    p1 <- dataTemp %>% ggvis(~date,~TvPInfo) %>% layer_lines(stroke=factor("TvPInfo")) %>% add_title(x_lab=xlabTemp)} else p1=0
  if(c2==1) {
      p2 <- dataTemp %>% ggvis(~date,~WpPl) %>% layer_lines(stroke=factor("WpPl")) %>% add_title(x_lab=xlabTemp)} else p2=0
  if(c3==1) {
    p3 <- dataTemp %>% ggvis(~date,~WprostPl) %>% layer_lines(stroke=factor("WprostPl")) %>% add_title(x_lab=xlabTemp) } else p3=0
  if(c4==1) {
    p4 <- dataTemp %>% ggvis(~date,~OnetPl) %>% layer_lines(stroke=factor("OnetPl")) %>% add_title(x_lab=xlabTemp)}else p4=0
  if(c5 ==1) {
    p5 <- dataTemp %>% ggvis(~date,~NewsweekPl) %>% layer_lines(stroke=factor("NewsweekPl")) %>% add_title(x_lab=xlabTemp)}else p5=0
  if(c6 ==1) {
    p6 <- dataTemp %>% ggvis(~date,~Tvn24Pl) %>% layer_lines(stroke=factor("Tvn24Pl")) %>% add_title(x_lab=xlabTemp)}else p6=0
  if(c7 ==1) {
    p7 <- dataTemp %>% ggvis(~date,~NatematPl) %>% layer_lines(stroke=factor("NatematPl")) %>% add_title(x_lab=xlabTemp)}else p7=0
  if(c8 ==1) {
    p8 <- dataTemp %>% ggvis(~date,~GazetaPl) %>% layer_lines(stroke=factor("GazetaPl")) %>% add_title(x_lab=xlabTemp)}else p8=0
  if(c9 ==1) {
    p9 <- dataTemp %>% ggvis(~date,~DziennikPl) %>% layer_lines(stroke=factor("DziennikPl")) %>% add_title(x_lab=xlabTemp)}else p9=0
  if(c10 ==1){
    p10 <- dataTemp %>% ggvis(~date,~WyborczaPl) %>% layer_lines(stroke=factor("WyborczaPl")) %>% add_title(x_lab=xlabTemp)}else p10=0
  vis_list <- lapply(whichSites, FUN = function(x) eval(parse(text=x)))
  out <- do.call(Map, c(list(`c`), vis_list ))
  attributes(out) <- attributes(vis_list[[1]])
  out
}
