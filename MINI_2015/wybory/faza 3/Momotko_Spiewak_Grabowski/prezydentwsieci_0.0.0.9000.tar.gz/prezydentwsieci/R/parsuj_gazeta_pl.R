#' Pobieranie informacji o artykulach dotyczacych kandydatow na prezydenta z glownych polskich portali informacyjnych.
#'
#' Funkcja \code{parsuj_gazeta_pl()} pobiera do pliku .csv informacje o tych artykulach ze strony www.gazea.pl, ktore dotycza
#' wyborow prezydenckich. Potencjalne artykula sa wybierana za pomaca funckji sprawdz_czy_wybory() i wybranego slownika.
#'
#' @details
#' Plik .csv ma w nazwie date dnia, w ktorym zostala uzyta funckcja i jest zapisywany w katalogu roboczym.
#' Pierwsza linia w pliku jest naglowek, ktory zawiera nazwy atrubutow, kolejno: data, portal, tytul, pozycja, link.
#' Atrybuty:
#' data - data wykonania funckji;
#' portal - portal, z ktorego pobrano informacje o artykule;
#' tytul - tytul artykulu;
#' pozycja - przyjmuje wartosci od 1 do 4, oznacza 'waznosc' artykulu na stronie, gdzie 4
#' znaczy najbardziej wazny (np artykul glowny) a 1 najmniej wazny (np artykuly na dole strony).
#' link - link do artykulu.
#'
#' Atrybuty sa oddzielone srednikiem.
#'
#' @return Zwraca plik .csv z nazwa daty wykonania lub dokleja informacje jezeli plik juz instnieje.
#'
#' @author Pawel Grabowski, Emilia Momotko, Martyna Spiewak
#'
#'
#' @examples
#' parsuj_gazeta_pl()
#'
#' @import rvest
#' @import stringi
#' @import XML
#' @import dplyr





parsuj_gazeta_pl <- function(){
  data <- as.character(Sys.Date())
  url <- "http://www.gazeta.pl"
  df <- data.frame()
  parsed_page <- htmlParse(url)
  slownik <- slownik()

  main_articles <- getNodeSet(parsed_page, "//div[@class='col-md-8 col-sm-8 col-xs-12 mt_pict']//a")
  if(length(main_articles)>0){
    main_titles <- sapply(main_articles, xmlValue, "href") %>%
      '['(1) %>%
      stri_replace_all_regex(., ';', "") %>%
      stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
    url_main_titles <- sapply(main_articles, xmlGetAttr, "href") %>%
      '['(1)

    ktore <- sapply(main_titles, function(x) sprawdz_czy_wybory(slownik,x))

    if(sum(ktore) > 0) {
      df <- rbind(df, data.frame(date=data, portal=url, title=main_titles[ktore],
                                 position=4,link=url_main_titles[ktore]))
    }
  }

  main2_articles <- getNodeSet(parsed_page, "//div[@class='row mod_photo_box mod_section type_foreheads']//a")
  main2_titles <- sapply(main2_articles,html_attr, "title") %>%
    unique(.) %>%
    stri_replace_all_regex(main2_titles, ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))

  url_main2_titles <- sapply(main2_articles, html_attr, "href") %>%
    unique(.) %>%
    unlist(sapply(., function(x){
    if(stri_extract_first_regex(x,".{4}")!="http"){
      paste("http://",x, sep="") } else { x }
    }))
  names(url_main2_titles) <- NULL
  ktore <- sapply(main2_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url, title=main2_titles[ktore],
                             position=3,link=url_main2_titles[ktore]))
  }

  right_articles <- html_nodes(parsed_page, ".box_news .news_box_pict a")
  right_titles <- sapply(right_articles,html_attr,"title") %>%
    unique(.) %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  url_right_titles <- sapply(right_articles, html_attr, "href") %>%
    unique(.) %>%
    unlist(sapply(., function(x){ if(stri_extract_first_regex(x,".{4}")!="http") {
      paste("http://",x, sep="")} else {x}
      }))
  names(url_right_titles) <- NULL
  ktore <- sapply(right_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0) {
    df <- rbind(df, data.frame(date=data, portal=url, title=right_titles[ktore],
                               position=2,link=url_right_titles[ktore]))
  }

  other_articles <- html_nodes(parsed_page, ".box_news .news_box_links a")
  other_titles <- sapply(other_articles,html_attr,"title") %>%
    unique(.) %>%
    stri_replace_all_regex(., ';', "") %>%
    stri_trim_both(stri_replace_all_regex(.,"(\\n)|(\\t)|(\\r)|(\")"," "))
  url_other_titles <- sapply(other_articles, html_attr, "href") %>%
    unique(.) %>%
    unlist(sapply(., function(x){ if(stri_extract_first_regex(x,".{4}")!="http") {
      paste("http://",x, sep="")} else {x}
      }))
  names(url_main2_titles) <- NULL
  ktore <- sapply(other_titles, function(x) sprawdz_czy_wybory(slownik,x))
  if(sum(ktore) > 0){
    df <- rbind(df, data.frame(date=data, portal=url, title=other_titles[ktore],
                             position=1,link=url_other_titles[ktore]))
  }

  zapisz_do_pliku(df, data)
  return(invisible(NULL))
}
