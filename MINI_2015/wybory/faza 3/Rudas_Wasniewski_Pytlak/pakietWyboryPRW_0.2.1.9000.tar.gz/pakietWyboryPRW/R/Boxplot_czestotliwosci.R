#' wyliczenie wykresow boxplot czestotliwosci dla kazdego kandydata
#'
#' Funkcja \code{Boxplot_czestotliwosci} rysuje wykres boxplot przedstawiajacy czestotliwosci dla poszczegolnych kandydatow.
#' Czestotliwosci sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{Boxplot_czestotliwosci(dane,zrodlo,co,od_ktorego,do_ktorego,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{Boxplot_czestotliwosci} rysuje wykres boxplot, na osi x mamy poszczegolnych kandydatow, na y
#' wartosci czestotliwosci(patrz funkcja czestotliwosc)  dla kazdego z nich. Pod osia x jest informacja z jakiego przedzialu
#' czasu ropatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a czestotliwosciami wystepowan.
#'
#' @examples
#' Boxplot_czestotliwosci(dane_artykuly,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'

Boxplot_czestotliwosci<-function(dane,zrodlo,co,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                 "Wilk","Braun","Kukiz"))
{

   nazwiska<-c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                    "Wilk","Braun","Kukiz")

   #tu zbieramy wektory czestotliwosci
   df<-data.frame()

   temp<-czestotliwosc(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                                "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                                   "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                                   "$3-$2-$1"),czyczasy=TRUE)

   #Tworz ramke danych z wektorami czestotliwosci, do kazdej wartosci czestotliwosci dopisujemy nazwisko kandydata
   for(i in 1:10)
   {
      temp1<-temp[[i]]
      df_temp<-data.frame(nazwisko=rep(nazwiska[i],length(temp1)),wartosci=temp1)
      df<-rbind(df,df_temp)
   }
   #Wybieramy kandydatow ktorzy nas interesuja
   ktore<-c()
   for(i in 1:length(ktorzykandydaci))
   {
      temporary<-which(df$nazwisko==ktorzykandydaci[i])
      ktore<-c(ktore,temporary)
   }
   df<-df[ktore,]
   czas_pocz<-as.character(od_ktorego)
   czas_konc<-as.character(do_ktorego)

   skladowa_x1<-"od dnia"
   skladowa_x2<-"do dnia"
   xlab1<-stri_paste(skladowa_x1,czas_pocz,skladowa_x2,czas_konc, sep=" ")
   p<-ggplot(df, aes(x=nazwisko,y=wartosci)) +geom_boxplot()+
      ggtitle("Boxploty czestosci do danego dnia") +
      theme(plot.title = element_text(size = 16))
   p+xlab(xlab1) + ylab("Czestosc(godziny)")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
