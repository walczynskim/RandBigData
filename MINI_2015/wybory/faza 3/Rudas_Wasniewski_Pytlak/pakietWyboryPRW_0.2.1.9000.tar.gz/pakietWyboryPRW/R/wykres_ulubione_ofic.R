
wykres_ulubione_ofic <- function(kandydaci, data_od, data_do){

   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   
   ramki <- list(ulubione_Andrzej_Duda, ulubione_Bronislaw_Komorowski, 
                 ulubione_Magdalena_Ogorek, ulubione_Adam_Jarubas, 
                 ulubione_Janusz_Palikot, ulubione_Janusz_Korwin_Mikke, 
                 ulubione_Pawel_Kukiz)
   
   ulubione_na_dzien <- list()
   
   i <- 1
   
   for(e in ktorzy){
      
      n <- nrow(ramki[[e]])
      
      ulubione_tweety <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], n), 
                                    data = as.Date(ramki[[e]]$row.names), 
                                    ilosc = ramki[[e]]$x)
      
      daty <- ulubione_tweety$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      ulubione_tweety_od_do <- ulubione_tweety[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], m), 
                                    data = brakujace_dni, ilosc = rep(0, m))
         
         ulubione_na_dzien[[i]] <- rbind(ulubione_tweety_od_do, brak_tweetow)
         
      } else {
         
         ulubione_na_dzien[[i]] <- ulubione_tweety_od_do
      }
      
      i <- i + 1
   }
   
   duza_ramka <- do.call("rbind", ulubione_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = ilosc, col = kandydat)) + geom_line() + 
      ggtitle("Srednia liczba polubien tweetow na dzien") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("srednia liczba polubien") + scale_colour_manual(values = wybrane_kolory)
}

