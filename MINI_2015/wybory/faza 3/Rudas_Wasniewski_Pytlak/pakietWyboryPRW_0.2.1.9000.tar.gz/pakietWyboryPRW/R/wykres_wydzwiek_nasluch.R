
wykres_wydzwiek_nasluch <- function(kandydaci, data_od, data_do){

   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   
   ramki <- list(nasluch_wydzwiek_Andrzej_Duda, nasluch_wydzwiek_Bronislaw_Komorowski, 
                 nasluch_wydzwiek_Magdalena_Ogorek, nasluch_wydzwiek_Adam_Jarubas, 
                 nasluch_wydzwiek_Janusz_Palikot, nasluch_wydzwiek_Janusz_Korwin_Mikke, 
                 nasluch_wydzwiek_Pawel_Kukiz)
   
   wydzwiek_na_dzien <- list()
   
   i <- 1
   
   for(e in ktorzy){
      
      n <- nrow(ramki[[e]])
      
      wydzwiek_tweety <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], n), 
                                    data = as.Date(ramki[[e]]$row.names), 
                                    wydzwiek = ramki[[e]]$x)
      
      daty <- wydzwiek_tweety$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      wydzwiek_tweety_od_do <- wydzwiek_tweety[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], m), 
                                    data = brakujace_dni, wydzwiek = rep(0, m))
         
         wydzwiek_na_dzien[[i]] <- rbind(wydzwiek_tweety_od_do, brak_tweetow)
         
      } else {
         
         wydzwiek_na_dzien[[i]] <- wydzwiek_tweety_od_do
      }
      
      i <- i + 1
   }
   
   duza_ramka <- do.call("rbind", wydzwiek_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = wydzwiek, col = kandydat)) + geom_line() + 
      ggtitle("Tweety z nasluchu - sredni wydzwiek na dzien (w skali od -2 do 2)") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("srednia wartosc wydzwieku") + scale_colour_manual(values = wybrane_kolory)
}


