#' wylicznie wykresow slupkowych przedstawiajacych liczbe wystapien dla kandydata
#'
#' Funkcja \code{wykresilezliczenprzezDni2} rysuje wykres slupkowy przedstawiajacy liczbe wystapien
#' dla poszczegolnych kandydatow. Miary sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{wykresilezliczenprzezDni2(dane,zrodlo,co,od_ktorego,do_ktorego,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie
#'
#' @details \code{wykresilezliczenprzezDni2} rysuje wykres slupkowy, na osi x mamy poszczegolnych kandydatow, na y
#' liczbe wystapien dla kazdego z nich. Pod osia x jest informacja z jakiego przedzialu
#' czasu rozpatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a liczba wystapien na danym przedziale czasu.
#'
#' @examples
#' wykresilezliczenprzezDni2(dane_artykuly,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
wykresilezliczenprzezDni2<-function(dane,zrodlo,co,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                     "Wilk","Braun","Kukiz"))
{
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")


   df<-data.frame()
   #liczymy na przedziale czasu liczbe wystapien kandydatow na danym przedziale czasu
   temp<-ilezliczenprzezDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                        "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                        "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                           "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                           "$3-$2-$1"))





   #dolaczamy do ramki danych
   df<-rbind(df,temp)
   colnames(df)<-nazwiska


   #dolaczamy id
   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tych ktorych chcemy
   df<-df[,c(ktorzykandydaci,"id")]
   dfm <- melt(df, id.var = c("id"))
   #tworzenie tytulu wykresu
   tytul<-"Liczba wystapien dla kandydatow"

   #tworzenie napisu przy osi x
   skladowa_x1<-"od dnia"
   skladowa_x2<-"do dnia"
   xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
   #wykres
   p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab(xlab1) + ylab("Liczba wystapien")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
