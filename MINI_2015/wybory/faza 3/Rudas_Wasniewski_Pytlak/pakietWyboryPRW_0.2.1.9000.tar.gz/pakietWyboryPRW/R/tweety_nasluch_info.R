#' Wyszukiwanie podstawowych informacji o nasluchiwanych tweetach dotyczacych kandydatow na Prezydenta RP
#' 
#' Funkcja \code{tweety_nasluch_info} nasluchuje tweety dotyczace osob ubiegajacych sie o urzad Prezydenta RP w 2015 roku, zapisuje je do pliku w formacie .JSON, a nastepnie tworzy ramke danych z podstawowymi informacjami na temat pobranych tweetow.
#' 
#' @usage \code{tweety_nasluch_info(czas, katalog, nazwa)}
#' 
#' @param czas okres (liczony w sekundach), przez jaki dokonujemy nasluchu tweetow
#' @param katalog nazwa katalogu, w ktorym przechowywany bedzie plik (w formacie JSON) z tweetami
#' @param nazwa nazwa pliku, w ktorym beda przechowywane tweety z nasluchu
#' 
#' @return ramka danych
#' 
#' @examples tweety_nasluch_info(30*60, "C:/Dane/Pawel_2/PW/R_Big_Data/Wybory/tweety", "21-03-2015")  
#'   


tweety_nasluch_info <- function(czas, katalog, nazwa){
   
   # aby miec mozliwosc korzystania z aplikacji do pobierania tweetow, musimy
   # uzyskac na to zezwolenie
   requestURL <- "https://api.twitter.com/oauth/request_token"
   accessURL <- "https://api.twitter.com/oauth/access_token"
   authURL <- "https://api.twitter.com/oauth/authorize"
   consumerKey <- "mruTEgk5DpvU0XM8dk3aPRhVx"
   consumerSecret <- "B2NOHpA7uVrap95LOwTssStx8HfWUgSDbtTo0OJhQrXQEmi1oT"
   oauthKey <- "51761035-QqJMM7EYxwwV5QnGAelnEq6HVg6RQrUYOFMyw9pho"
   oauthSecret <- "FteRrg5TjcjyW37qMfLBeXaDsFeYQ7AUFgWFmHS1cJqO5"
   
   paczka <- OAuthFactory$new(consumerKey = consumerKey, 
                              consumerSecret = consumerSecret, 
                              oauthKey = oauthKey, 
                              oauthSecret = oauthSecret, 
                              requestURL = requestURL, 
                              accessURL = accessURL, authURL = authURL)   
   
   paczka$handshake(cainfo = system.file("CurlSSL", "cacert.pem", 
                                         package = "RCurl"))
   
   # ustawiamy katalog biezacy 
   setwd(katalog)
   
   # pobieramy interesujace nas wiadomosci, ktore beda przechowywane w pliku w
   # formacie .json; nasluchujemy jedynie tweety napisane w jezyku polskim, 
   # jednakze nie precyzujemy ich lokalizacji
   filtruj <- filterStream(
      file = stri_paste(nazwa, ".json"), 
      track = c("Andrzej Duda", "AndrzejDuda", "AndrzejDuda2015", 
                "Bronisław Komorowski", "prezydentpl", "PBK", 
                "Prezydent Komorowski", "Magdalena Ogórek", "Magda Ogórek", 
                "ogorekmagda", "Adam Jarubas", "JarubasAdam", 
                "Janusz Palikot", "Palikot Janusz", "Palikot2015", 
                "Janusz Korwin-Mikke", "JkmMikke", "Duda", "Komorowski", 
                "Ogórek", "Ogorek", "Jarubas", "Palikot", "Korwin-Mikke", 
                "Korwin Mikke", "Dudy", "Dudzie", "Dudę", "Dude", "Dudą", 
                "Komorowskiego", "Komorowskiemu", "Komorowskiego", 
                "Komorowskim", "Jarubasa", "Jarubasowi", "Jarubasem", 
                "Jarubasie", "Palikota", "Palikotowi", "Palikotem", 
                "Palikocie", "wyboryprezydenckie", "prezydentKomorowski", 
                "Bronislaw Komorowski", "Korwin", "Korwina", "Korwinowi", 
                "Korwinem", "Korwinie", "Korwina-Mikke", "Korwinowi-Mikke", 
                "Korwinem-Mikke", "Korwinie-Mikke", "Paweł Kukiz", 
                "PrezydentKukiz", "Kukiz", "Kukiza", "Kukizowi", "Kukizem", 
                "Kukizie"), 
      language = "pl", 
      timeout = czas, oauth = paczka)
   
   # przeksztalcamy plik w formacie .json na ramke danych
   parsuj <- parseTweets(stri_paste(katalog, "/", nazwa, ".json"), 
                         simplify = FALSE, verbose = TRUE)
   
   # niektore sposrod pobranych tweetow nie dotyczylo kandydatow na prezydenta, 
   # a np. pilkarzy; w tym celu postanowiono zlokalizowac podejrzane tweety, 
   # poprzez wpisanie pewnych slow kluczowych zwiazanych z polska liga pilki
   # noznej
   wykryjInne <- lapply(parsuj$text, function(x) 
      stri_detect_regex(x, 
                        c("Ondrej Duda", "Ondreja Dudy", "Ondrejowi Dudzie", 
                          "Ondreja Dudę", "Ondreja Dude", "Ondrejem Dudą", 
                          "Ondrejem Duda", "Ondreju Dudzie", 
                          "Marcin Komorowski", "Marcina Komorowskiego", 
                          "Marcinowi Komorowskiemu", "Marcinem Komorowskim", 
                          "Marcinie Komorowskim", "LegiaWarszawa", "Legia", 
                          "Legii", "Legię", "Legie", "Legią", 
                          "Legia Warszawa", "mecz", "meczu", "meczowi", 
                          "meczem", "KoltonRoman", "piłka", "pilka", 
                          "piłki", "pilki", "piłce", "pilce", "piłkę", 
                          "pilke", "piłką", "Ekstraklasa", "Ekstraklasy", 
                          "Ekstraklasie", "Ekstraklasę", "Ekstraklase", 
                          "Ekstraklasą", "bramka", "bramki", "bramce", 
                          "bramkę", "bramką", "gol", "gola", "golem", 
                          "golu", "Żyro", "Zyro", "uzupełnienia", 
                          "napastnik", "napastnika", "napastnikowi", 
                          "napastnikiem", "napastniku", "Dossa Junior", 
                          "Kuciak", "Kuciaka", "Kuciakowi", "Kuciakiem", 
                          "Kuciaku", "Jałocha", "Jalocha", "Jałochy", 
                          "Jalochy", "Jałosze", "Jalosze", "Jałochę", 
                          "Jaloche", "Jałochą", "Jalocha", "Lewczuk", 
                          "Lewczuka", "Lewczukowi", "Lewczukiem", 
                          "Lewczuku", "Wieteska", "Wieteski", "Wietesce", 
                          "Wieteskę", "Wieteske", "Wieteską", "Astiz", 
                          "Astiza", "Astizowi", "Astizem", "Astizie", 
                          "Brzyski", "Brzyskiego", "Brzyskiemu", "Brzyskim", 
                          "Broź", "Brozia", "Broziowi", "Broziem", "Broziu", 
                          "Marques", "Marquesa", "Marquesowi", "Marquesem", 
                          "Marquesie", "Szwoch", "Szwocha", "Szwochowi", 
                          "Szwochem", "Szwochu", "Vrdoljak", "Vrdoljaka", 
                          "Vrdoljakowi", "Vrdoljakiem", "Vrdoljaku", 
                          "Pinto", "Bartczak", "Bartczaka", "Bartczakowi", 
                          "Bartczakiem", "Bartczaku", "Saganowski", 
                          "Saganowskiego", "Saganowskiemu", "Saganowskim", 
                          "Ryczkowski", "Ryczkowskiego", "Ryczkowskiemu", 
                          "Ryczkowskim", "Orlando Sa", "Henning Berg", 
                          "Jodłowiec", "Jodlowiec", "Jodłowca", "Jodlowca", 
                          "Jodłowcu", "Jodlowcu", "Jodłowcowi", 
                          "Jodlowcowi", "Jodłowcem", "Jodlowcem")))
   
   # ustalamy indeksy tych tweetow, ktore z duzym prawdopobienstwem dotycza
   # wyborow prezydenckich
   prawidlowe <- unlist(lapply(wykryjInne, function(y) all(y == FALSE)))
   tweetyWybory <- parsuj$text[prawidlowe == TRUE]
   ktore <- which(parsuj$text %in% tweetyWybory)
   
   # zmieniamy format daty na bardziej przyjazny
   moje_locale <- Sys.setlocale("LC_TIME")
   Sys.setlocale("LC_TIME", "English")
   zmiana_daty <- strptime(parsuj$created_at, "%a %b %d %H:%M:%S %z %Y")
   Sys.setlocale("LC_TIME", moje_locale)
   
   # tworzymy ramke danych zawierajaca tresci tweetow, jak rowniez podstawowe
   # informacje na temat autora, czasu powstania wiadomosci, lokalizacji oraz 
   # liczby uzytkownikow obserwujacych danego autora
   data.frame(tekst = tweetyWybory, 
              autor = parsuj$screen_name[ktore], 
              data = zmiana_daty[ktore], 
              lokalizacja = parsuj$location[ktore], 
              obserwujacy = parsuj$followers_count[ktore], 
              stringsAsFactors = FALSE)
}

