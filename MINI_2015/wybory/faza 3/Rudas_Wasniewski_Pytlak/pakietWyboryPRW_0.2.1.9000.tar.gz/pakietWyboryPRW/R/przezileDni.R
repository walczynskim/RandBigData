#' Wyznaczenie procentowego udzialu ilosci dni wystapien przez ogolna liczbe dni
#'
#' Funkcja \code{przezileDni} wyznacza  procentowy udzial ilosci dni wystapien przez ogolna liczbe dni
#'
#' @usage
#' \code{przezileDni(dane,podajzrodlo,co,datapocz, datakonc)}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkca dodajdane).
#' @param podajzrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow: dostepne wartosci "tytul","tagi","tresc".
#' @param datapocz data w postaci napisu dd-mm-YYYY od ktorej rozpatrujemy artykuly (wczesniejszych nie bierzemy pod uwage).
#' @param datakonc data data w postaci napisu dd-mm-YYYY do ktorej rozpatrujemy artykuly (pozniejszych nie bierzemy pod uwage).
#'
#' @details \code{przezileDni} liczy liczbe dni z danego okresu i liczbe dni z tego samego okresu
#' w ktorych kandydat sie pojawial nastepnie dzieli ta druga wartosc przez pierwsza.
#'
#' @return wektor miar opisanych w szcegolach funkcji, kazdy element wektora dotyczy innego kandydata.
#' @examples
#' przezileDni(dane_artykuly,"gazeta.pl","tytul",datapierwszgopobrania(dane_artykuly,"gazeta.pl"),aktualnydzien())
#' przezileDni(dane_artykuly,"brak","tytul",datapierwszgopobrania(dane_artykuly,"brak"),aktualnydzien())
#'
przezileDni<-function(dane,podajzrodlo,co,datapocz, datakonc)
{
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og?rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   #Zamina na POSIX
   pocz<-strptime(datapocz,"%d-%m-%Y")
   konc<-strptime(datakonc,"%d-%m-%Y")
   #Ile dni od datapocz do datakonc
   liczbadni<-ceiling(as.numeric(konc-pocz,units="days"))+1
   #Ustalamy czy przeszukujemy po zrodle
   po.zrodle<-TRUE
   if(podajzrodlo=="brak")
   {
      po.zrodle<-FALSE
   }
   #ramka danych o czestotliwosci wystepowan ze wzgledu na dzien
   d<-ile_dziennie(dane,co,po.zrodle)
   if(podajzrodlo!="brak")
   {
      d<-d[d$zrodlo==podajzrodlo,]
      odpowiedniekolumny<-2 #kolumny kandydatow zaczynaja sie od 3
   }
   else
   {
      odpowiedniekolumny<-1 #kolumny kandydatow zaczynaja sie od 2
   }
   #wektor miary
   miara<-rep(0,length(kandydat))
   #dla kazdego kandydata zliczaj dni w ktorych jest w artykule i te ktore <=datakonc i >=datapocz
   for(i in 1:length(kandydat))
   {
      dni<-strptime(d[which(d[,(odpowiedniekolumny+i)]>0),]$dzien,"%d-%m-%Y")
      miara[i]<-length(which(dni<=konc&dni>=pocz))/liczbadni
   }
   names(miara)<-nazwiska
   miara
}
