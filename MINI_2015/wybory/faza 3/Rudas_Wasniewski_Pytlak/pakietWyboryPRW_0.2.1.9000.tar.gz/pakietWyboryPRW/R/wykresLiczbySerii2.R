#' wyliczenie wykresow slupkowych przedstawiajacych liczbe serii dla kazdego kandydata
#'
#' Funkcja \code{wykresLiczbySerii2} rysuje wykres slupkowy przedstawiajacy liczbe serii dla poszczegolnych kandydatow.
#' Liczby serii sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{wykresLiczbySerii2(dane,zrodlo,co,od_ktorego,do_ktorego,liczbaserii,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param liczbaserii wartosc liczbowa okreslajaca jakich dlugosci serii poszukujemy.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresLiczbySerii2} rysuje wykres slupkowy, na osi x mamy poszczegolnych kandydatow, na y
#' wartosci liczby serii o zadanej dlugosci dla kazdego z nich. Pod osia x jest informacja z jakiego przedzialu
#' czasu ropatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a wartoscia liczby serii na danym przedziale czasu.
#'
#' @examples
#' wykresLiczbySerii2(dane_artykuly,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"),3)
#'
wykresLiczbySerii2<-function(dane,zrodlo,co,od_ktorego,do_ktorego,liczbaserii,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                         "Wilk","Braun","Kukiz"))
{

   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   df<-data.frame()
   #liczymy na przedziale czasu liczbe serii dla kazdego kandydata
   temp<-iloscDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                           "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                           "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                              "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                              "$3-$2-$1"),maks=FALSE,dlserii=liczbaserii)





   #dolaczamy do ramki danych
   df<-rbind(df,temp)
   colnames(df)<-nazwiska

   #dolaczamy id
   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tych ktorych chcemy
   df<-df[,c(ktorzykandydaci,"id")]
   dfm <- melt(df,id.vars = "id")
   #tworzenie tytulu wykresu
   skladowa_tytul1<-"Liczba serii o dlugosci"
   skladowa_tytul2<-as.character(liczbaserii)
   skladowa_tytul3<-"wzgledem czasu"
   tytul<-stri_paste(skladowa_tytul1,skladowa_tytul2,skladowa_tytul3,sep=" ")
   #tworzenie napisu przy osi x
   skladowa_x1<-"od dnia"
   skladowa_x2<-"do dnia"
   xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
   #wykres
   p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab(xlab1) + ylab("Liczba serii")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}

