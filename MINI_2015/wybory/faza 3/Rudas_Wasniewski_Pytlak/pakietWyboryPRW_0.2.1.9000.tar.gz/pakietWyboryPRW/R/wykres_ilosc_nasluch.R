#' Rysowanie wykresu obrazujacego liczbe tweetow z nasluchu na temat poszczegolnych kandydatow, w podziale na dni 
#' 
#' Funkcja \code{wykres_ilosc_nasluch} wczytuje pliki z obliczonymi wskaznikami dla poszczegolnych kandydatow, a nastepnie rysuje wykres dla wybranych kandydatow i wybranego przedzialu czasu.
#' 
#' @usage \code{wykres_ilosc_nasluch(kandydaci, data_od, data_do)}
#' 
#' @param kandydaci wektor imion i nazwisk wybranych kandydatow
#' @param data_od dzien, od ktorego chcemy wyswietlac wyliczone wskazniki 
#' @param data do dzien, do ktorego chcemy wyswietlac wyliczone wskazniki
#' 
#' @return wykres obrazujacy zaleznosc liczby tweetow od dnia
#' 
#' @examples 
#' kandydaci1 <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", "Pawel Kukiz")
#' data_od1 <- as.Date("2015-03-21")
#' data_do1 <- as.Date("2015-05-13")
#' wykres_ilosc_nasluch(kandydaci1, data_od1, data_do1)
#' 



wykres_ilosc_nasluch <- function(kandydaci, data_od, data_do){

   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   
   ramki <- list(nasluch_ilosc_Andrzej_Duda, nasluch_ilosc_Bronislaw_Komorowski, 
                 nasluch_ilosc_Magdalena_Ogorek, nasluch_ilosc_Adam_Jarubas, 
                 nasluch_ilosc_Janusz_Palikot, nasluch_ilosc_Janusz_Korwin_Mikke, 
                 nasluch_ilosc_Pawel_Kukiz)
   
   ilosc_na_dzien <- list()
   
   i <- 1
   
   for(e in ktorzy){
      
      n <- nrow(ramki[[e]])
      
      liczba_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], n), 
                                   data = as.Date(ramki[[e]]$row.names), 
                                   ilosc = ramki[[e]]$x)
      
      daty <- liczba_tweetow$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      liczba_tweetow_od_do <- liczba_tweetow[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], m), 
                                    data = brakujace_dni, ilosc = rep(0, m))
         
         ilosc_na_dzien[[i]] <- rbind(liczba_tweetow_od_do, brak_tweetow)
      
      } else {
         
         ilosc_na_dzien[[i]] <- liczba_tweetow_od_do
      }
   
      i <- i + 1
   }

   duza_ramka <- do.call("rbind", ilosc_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = ilosc, col = kandydat)) + geom_line() + 
      ggtitle("Tweety o danym kandydacie - liczba na dzien") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("liczba tweetow") + scale_colour_manual(values = wybrane_kolory)
}


