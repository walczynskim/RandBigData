#' wylicznie wykresow slupkowych przedstawiajacych rangi dla kandydata
#'
#' Funkcja \code{wykresRangi} rysuje wykres slupkowy przedstawiajacy rangi
#' dla poszczegolnych kandydatow. Rangi sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{wykresRangi(dane,zrodlo,co,od_ktorego,do_ktorego,funkcja,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param funkcja napis jaka funkcje traktujemy jako miare na czestotliwosciach (srednia czy mediana, patrz funckja czestotliwosc).
#' @param ktorzykandydaci napis okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresRangi} rysuje wykres slupkowy, na osi x mamy poszczegolnych kandydatow, na y
#' rangi dla kazdego z nich (patrz funkcja czestotliwosc). Pod osia x jest informacja z jakiego przedzialu
#' czasu ropatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a ranga.
#'
#' @examples
#' wykresRangi(dane_artykuly,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"),funkcja="mean")
#'
wykresRangi<-function(dane,zrodlo,co,od_ktorego,do_ktorego,funkcja,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                            "Wilk","Braun","Kukiz"))
{
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")

   df<-data.frame()
   #liczymy rangi wynikajace z miary na czestotliwosciach
   if(funkcja=="mean")
   {
      temp<-czestotliwosc(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                                "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                                   "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                                   "$3-$2-$1"),funkcja=mean,czyczasy=FALSE)[[2]]
   }


   else if(funkcja=="median")
   {
      temp<-czestotliwosc(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                                "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                                   "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                                   "$3-$2-$1"),funkcja=median,czyczasy=FALSE)[[2]]

   }



   #dolaczamy do ramki danych
   df<-rbind(df,temp)
   colnames(df)<-nazwiska

   #dolaczamy id
   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tych ktorych chcemy
   df<-df[,c(ktorzykandydaci,"id")]
   dfm <- melt(df, id.var = c("id"))
   if(funkcja=="mean")
   {
      #tworzenie tytulu wykresu
      tytul<-"Rangi kandydatow na mocy sredniej"

      #tworzenie napisu przy osi x
      skladowa_x1<-"od dnia"
      skladowa_x2<-"do dnia"
      xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
      #wykres
      p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
         ggtitle(tytul) +
         theme(plot.title = element_text(size = 16))
      p+xlab(xlab1) + ylab("Ranga")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
   }
   else if(funkcja=="median")
   {
      #tworzenie tytulu wykresu
      tytul<-"Rangi kandydatow na mocy mediany"

      #tworzenie napisu przy osi x
      skladowa_x1<-"od dnia"
      skladowa_x2<-"do dnia"
      xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
      #wykres
      p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
         ggtitle(tytul) +
         theme(plot.title = element_text(size = 16))
      p+xlab(xlab1) + ylab("Ranga")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
   }
}
