#' Pobieranie informacji z artykulow z portalu tvn24.pl ktorych daty sa pozniejsze od zadanej
#'
#' Funkcja \code{wiadomosciztvn24} sciaga artykuly z portalu tvn24.pl z zakladki wybory o dacie pozniejszej od zadanej.
#'
#' @usage
#' \code{wiadomosciztvn24(czas)}
#'
#' @param czas czas od ktorego zaczynamy pobieranie (wpisywany jako czas POSIX).
#' @details \code{wiadomosciztvn24} przeszukuje strony artykulow z portalu tvn24.pl, z zakladki wybory, o dacie powstania pozniejszej od zadanej w argumencie.
#' Szuka przydatnych informacji o nich takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, komentarze.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to tvn24.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy z artykulow o dacie pozniejszej od zadanej w argumencie.
#'
#' @examples
#' wiadomosciztvn24(strptime("01-05-2015 10:00","%d-%m-%Y %H:%M"))
#'
wiadomosciztvn24<-function(czas)
{
   #link z zakladki wyborow
   link<-"http://www.tvn24.pl/wybory-prezydenckie-2015,117,m"
   adres<-html(link)
   adresy_artykulow1<-html_nodes(adres,"div.textRight > h1 > a")%>%html_attr("href")
   adresy_artykulow2<-html_nodes(adres,"div.textLeft > h1 > a")%>%html_attr("href")
   adresy_artykulow3<-html_nodes(adres,"article.singleArtMain > div > h1 > a")%>%html_attr("href")
   adresy_artykulow<-stri_paste("http://www.tvn24.pl",
                                c(adresy_artykulow1,adresy_artykulow2,adresy_artykulow3))
   #adresy artykulow
   adresy_artykulow<-unique(adresy_artykulow)
   dl<-length(adresy_artykulow)
   #w ta ramke bedziemy zapisywac dane
   informacje<-data.frame()
   for(i in 1:dl)
   {
      #ramka tymczasowa
      temp<-data.frame()
      try(temp<-tvn24_artykul_info(adresy_artykulow[i],i),silent=TRUE)
      if(length(temp)!=0)
      {
         #Jesli sie udalo to:
         temp1<-NULL
         #Sprobuj pobrac date
         try(temp1<-strptime(temp$data,"%Y-%m-%d %H:%M"),silent=TRUE)
         #Jesli sie udalo to:
         if(length(temp1)!=0)
         {
            #Jesli data pozniejsza od zadanej to:
            if(unclass(czas-temp1)<=0)
            {
               #Dopisuj do ramki
               informacje<-rbind(informacje,temp)
            } 
         }
         
         
         
      }
      
   }
   #Zwroc ramke
   informacje
}