#` 
#' Wykres liczby wystapien kandydata w zaleznosci od pory dnia
#'
#' Funkcja \code{wykres_pora_dnia} rysuje liczbe wystapien nazwiska kandydata 
#' w tytule lub w tresci z podzia?em na por? dnia
#' 
#' @param dane dane o artyku?ach z portali
#' @param co gdzie nazwsiko kandydata ma by? wyszukiwane (tytul, tresc)
#' @param zrodlo1 napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly 
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl",
#' "brak"
#' @param od_ktorego data, od ktorej bierzemy artykuly
#' @param do_ktorego data, do ktorej bierzemy artykuly
#' @param ktorzykandydaci ktorych kandydatow chcemy widziec na wykresie
#' 
#' @examples 
#' ## Not run:
#' wykres_pora_dnia(dane,"tytul","tytul")
#' wykres_pora_dnia(dane,"tresc",zrodlo1="gazeta.pl", 
#'                ktorzykandydaci=c("Komorowski","Kowalski", "Duda"))
#' ## End(**Not run**)
#' 
#' @import dplyr
#' @import stringi
#' @import ggplot2
#' @import tidyr
#' @import scales

wykres_pora_dnia <- function(dane,co="tytul",
                             od_ktorego=as.Date("01-03-2015", "%d-%m-%Y"),
                             do_ktorego=as.Date("12-05-2015", "%d-%m-%Y"),
                             zrodlo1="brak",
                             ktorzykandydaci=c("Komorowski","Kowalski",
                                               "Duda", "Palikot", "Jarubas",
                                               "Ogorek", "Korwin-Mikke","Wilk",
                                               "Braun","Kukiz")) {
   
   daty<-stri_replace_all_regex(dane$data, "([0-9]{4})-([0-9]{2})-([0-9]{2})", "$3-$2-$1")
   daty<-as.Date(daty,"%d-%m-%Y")
   dane<-dane[daty >= od_ktorego & daty<=do_ktorego ,]
   # przefiltrowanie danych
   if (!(zrodlo1=="brak")){
      dane<-filter(dane, zrodlo==zrodlo1)
   }
   #obliczenie wsaznika
   w<-pora_dnia(dane,co, FALSE)
   w<-w[, c("pora", ktorzykandydaci)]
   w<-gather(w, kandydat, wartosc,-pora) 

   
   # parametry do wykresu
   kolory<-c("black","yellow","blue","red","purple","green","brown","orange",
             "magenta","cyan")
   names(kolory)<-c("Komorowski","Kowalski", "Duda", "Palikot", 
                    "Jarubas", "Ogorek", "Korwin-Mikke","Wilk","Braun","Kukiz")
   kolory<-kolory[names(kolory) %in% ktorzykandydaci]
   if (co == "tytul"){
      tytul_wyk<-"Nazwiska w tytule, a pora dnia"
   } else {
      tytul_wyk<-"Nazwiska w tresci, a pora dnia"
   }
   if (zrodlo1 != "brak"){
      tytul_wyk<-paste0(tytul_wyk," dla ", zrodlo1)
   }
   xlab1<-stri_paste("od dnia", strftime(od_ktorego), "do dnia", 
                     strftime(do_ktorego), sep=" ")
   
   p<-ggplot(w, aes(as.factor(pora),wartosc, fill=kandydat)) +
      geom_bar( stat="identity",position="dodge")+
      scale_fill_manual(values=kolory)+
      xlab(xlab1)+
      ylab("liczba wystapien")+
      ggtitle(tytul_wyk)

   p
}


