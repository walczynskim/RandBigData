
wykres_ilosc_ofic <- function(kandydaci, data_od, data_do){
   
   dni <- seq(data_od, data_do, by="days")
   
   imiona_nazwiska <- c("Andrzej Duda", "Bronislaw Komorowski", "Magdalena Ogorek", 
                        "Adam Jarubas", "Janusz Palikot", "Janusz Korwin-Mikke", 
                        "Pawel Kukiz")
   
   nazwiska <- c("Duda", "Komorowski", "Ogorek", "Jarubas", "Palikot", 
                 "Korwin-Mikke", "Kukiz")
   
   zbiorcze <- data.frame(kandydat = imiona_nazwiska, 
                          nazwisko = nazwiska, 
                          stringsAsFactors = FALSE)
   
   ktorzy <- which(zbiorcze$kandydat %in% kandydaci)
   
   ramki <- list(ilosc_Andrzej_Duda, ilosc_Bronislaw_Komorowski, 
                 ilosc_Magdalena_Ogorek, ilosc_Adam_Jarubas, 
                 ilosc_Janusz_Palikot, ilosc_Janusz_Korwin_Mikke, 
                 ilosc_Pawel_Kukiz)
   
   ilosc_na_dzien <- list()
   
   i <- 1
   
   for(e in ktorzy){
      
      n <- nrow(ramki[[e]])
      
      liczba_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], n), 
                                   data = as.Date(ramki[[e]]$V1), 
                                   ilosc = ramki[[e]]$V2)
      
      daty <- liczba_tweetow$data
      num_daty <- unclass(daty)
      
      num_od <- unclass(data_od)
      num_do <- unclass(data_do)
      
      liczba_tweetow_od_do <- liczba_tweetow[num_daty >= num_od & num_daty <= num_do, ]
      
      if(any(!(dni %in% daty))){
         
         brakujace_dni <- dni[dni %in% daty == FALSE]
         
         m <- length(brakujace_dni)
         
         brak_tweetow <- data.frame(kandydat = rep(zbiorcze$nazwisko[e], m), 
                                    data = brakujace_dni, ilosc = rep(0, m))
         
         ilosc_na_dzien[[i]] <- rbind(liczba_tweetow_od_do, brak_tweetow)
         
      } else {
         
         ilosc_na_dzien[[i]] <- liczba_tweetow_od_do
      }
      
      i <- i + 1
   }
   
   duza_ramka <- do.call("rbind", ilosc_na_dzien)
   
   kolory <- c("blue", "black", "green", "purple", "red", "brown", "cyan")
   
   wybrane_kolory <- kolory[ktorzy]
   
   ggplot(duza_ramka, aes(x = data, y = ilosc, col = kandydat)) + geom_line() + 
      ggtitle("Liczba oficjalnych tweetow na dzien") + 
      xlab(stri_paste("od ", strftime(data_od), " do ", strftime(data_do))) + 
      ylab("liczba tweetow") + scale_colour_manual(values = wybrane_kolory)
}


