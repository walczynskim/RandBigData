#` Liczbe wystapienia nazwiska kandydat?w na dzien.
#'
#' Funkcja \code{pora_dnia} zwracaja liczbe wystapien nazwiska w tytule lub tresci
#` z podzialem na pore dnia. 
#' 
#' @param dane dane o artykulach z portali
#' @param co gdzie nazwisko kandydata ma by? wyszukiwane (tytul, tagi, tresc)
#' @param po.zrodle czy liczba wysytapien nazwiska kandydata ma byc
#'  liczona z podzia?em na portale
#' 
#' @examples 
#' ## Not run:
#' pora_dnia(dane_artykuly)
#' pora_dnia(dane_artykuly, po.zrodle=FALSE)
#' pora_dnia(dane_artykuly, co="tresc", po.zrodle=FALSE)
#' pora_dnia(dane_artykuly, co="tresc")
#' ## End(**Not run**)
#' 
#' @import dplyr
#' @import stringi
#' 

pora_dnia <- function(dane, co="tytul", po.zrodle=TRUE){
   
   kandydat <- c(
      "Komorowski\\p{L}*",
      "Marian(\\p{L})* Kowalsk(\\p{L})*",
      "(Dud(\\p{L})*)",
      "Paliko(\\p{L})*",
      "Jarubas(\\p{L})*",
      "Og?rek|Ogórek",
      "Korwin(\\p{L})*",
      "Wilk(\\p{L})*",
      "Braun(\\p{L})*",
      "Kukiz(\\p{L})*"
   )
   nazwiska <- c("Komorowski","Kowalski", "Duda", "Palikot", "Jarubas", "Ogorek", 
                 "Korwin-Mikke","Wilk","Braun","Kukiz")
   names(kandydat) <- nazwiska
   
   # czy wystepuje nazwisko kandydata;
   czy_nazwisko <- sapply(kandydat, function(x){
      stri_count_regex(dane[, co],x)
   })
   dane <- cbind(dane, czy_nazwisko)
   dane <- separate(dane, data, c("dzien", "godzina"), " ")
   
   dane$dzien <- stri_replace_all_regex(dane$dzien,
                                        "([0-9]{4})-([0-9]{2})-([0-9]{2})", 
                                        "$3-$2-$1")
   
   godzina <- stri_extract_first_regex(dane$godzina, "[0-9]{2}") %>% as.numeric()
   
   pora<-character(nrow(dane))
   pora[godzina %in% 0:5] <- "w nocy"
   pora[godzina %in% 06:11] <- "rano"
   pora[godzina %in% 12:17] <- "w ciagu dnia"
   pora[godzina %in% 18:23] <- "wieczorem"
   
   dane$pora<-pora
   if (po.zrodle){
      d <- dane[, c(2:3,9:19)] %>% group_by(zrodlo,pora)
   } else {
      d <- dane[, c(2:3,9:19)] %>% group_by(pora)
   } 
   d %>%
      summarise_each(funs(sum), -zrodlo, -dzien, -pora)
}




