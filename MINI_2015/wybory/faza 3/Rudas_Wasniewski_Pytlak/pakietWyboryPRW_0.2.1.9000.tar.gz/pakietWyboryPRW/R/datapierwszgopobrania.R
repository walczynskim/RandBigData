#' Wypisanie daty pierwszego pobrania
#'
#' Funkcja \code{datapierwszgopobrania} wypisuje date pierwszego pobranego artykulu.
#'
#' @usage
#' \code{datapierwszgopobrania(dane,podajzrodlo)}
#'
#' @param dane ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param podajzrodlo napis informujacy ze szukamy daty pierwszego pobranego artykulu z danego zrodla.
#' Dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @details \code{datapierwszgopobrania} znajduje date pierwszego pobranego artykulu, dla danego zrodla badz ogolnie.
#'
#' @return Zwraca date w postaci napisu w formie dd-mm-YYYY.
#'
#' @examples
#' datapierwszgopobrania(dane_artykuly,"wiadomosci.onet.pl")
#' datapierwszgopobrania(dane_artykuly,"brak")
#'

datapierwszgopobrania<-function(dane,podajzrodlo)
{

   #jesli szukamy po zrodle to rozpatrujemy tylko artykuly z danego zrodla
   if(podajzrodlo!="brak")
   {
      dane<-dane[dane$zrodlo==podajzrodlo,]
   }
   daty<-dane$data
   #Chce, aby daty mialy postac dd-mm-YYYY.
   daty <- stri_replace_all_regex(daty,
                                  "([0-9]{4})-([0-9]{2})-([0-9]{2})", 
                                  "$3-$2-$1")
   #Porzadkujmy od najwczesniejszej do najpozniejszej
   times<-sort(strptime(daty,"%d-%m-%Y"))
   #znajdujemy date pierwszego wywolania
   pierwszewywolanie<-times[1]
   #przerabiamy na napis
   strftime(pierwszewywolanie,"%d-%m-%Y")
}