#' wylicznie wykresow slupkowych przedstawiajacych wartosc liczby dni z wystapieniami/ogolna liczba dni dla kandydata
#'
#' Funkcja \code{wykresprzezileDni2} rysuje wykres slupkowy przedstawiajacy wartosc liczby dni z wystapieniami/ogolna liczba dni.
#' Dla poszczegolnych kandydatow miary sa zliczane na zadanym przedziale czasu.
#'
#' @usage
#' \code{wykresprzezileDni2(dane,zrodlo,co,od_ktorego,do_ktorego,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresprzezileDni2} rysuje wykres slupkowy, na osi x mamy poszczegolnych kandydatow, na y
#' wartosci liczby dni z wystapieniami/ogolna liczba dni dla kazdego z nich. Pod osia x jest informacja z jakiego przedzialu
#' czasu ropatrujemy artykuly.
#'
#' @return wykres zaleznosci miedzy kandydatem, a wartoscia liczby dni z wystapieniami/ogolna liczba dni na danym przedziale czasu.
#'
#' @examples
#' wykresprzezileDni2(dane_artykuly,"gazeta.pl","tresc",as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
wykresprzezileDni2<-function(dane,zrodlo,co,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                                          "Wilk","Braun","Kukiz"))
{
   nazwiska <- c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                 "Wilk","Braun","Kukiz")


   df<-data.frame()
   #liczymy na przedziale czasu miare ileprzezDni dla kandydatow
   temp<-przezileDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                        "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                        "$3-$2-$1"),stri_replace_all_regex(as.character(do_ktorego) ,
                                                                                           "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                           "$3-$2-$1"))





   #dolaczamy do ramki danych
   df<-rbind(df,temp)
   colnames(df)<-nazwiska
   #dolaczamy id
   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tych ktorych chcemy
   df<-df[,c(ktorzykandydaci,"id")]
   dfm <- melt(df, id.var = c("id"))
   #tworzenie tytulu wykresu
   tytul<-"Liczba dni z wystapieniami/liczba dni ogolnie dla kandydatow"

   #tworzenie napisu przy osi x
   skladowa_x1<-"od dnia"
   skladowa_x2<-"do dnia"
   xlab1<-stri_paste(skladowa_x1,strftime(od_ktorego,"%d-%m-%Y"),skladowa_x2,strftime(do_ktorego,"%d-%m-%Y"), sep=" ")
   #wykres
   p<-ggplot(dfm, aes(x=variable,y=value)) +geom_bar(stat="identity")+
      ggtitle(tytul) +
      theme(plot.title = element_text(size = 16))
   p+xlab(xlab1) + ylab("wystapiena/ogolna")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
