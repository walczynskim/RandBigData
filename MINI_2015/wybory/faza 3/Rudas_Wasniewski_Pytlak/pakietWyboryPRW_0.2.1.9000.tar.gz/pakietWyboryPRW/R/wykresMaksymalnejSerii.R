#' zmiana wartosci maksymalnej serii w czasie
#'
#' Funkcja \code{wykresMaksymalnejSerii} rysuje wykres przedstawiajacy zmiane wartosci maksymalnej serii wzgledem czasu.
#'
#' @usage
#' \code{wykresMaksymalnejSerii(dane,zrodlo,co,coile,od_ktorego,do_ktorego,
#' ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke","Wilk","Braun","Kukiz"))}
#'
#' @param dane  ramka danych z danymi w formie takiej jak w pliku artykuly.txt (patrz funkcja dodajdane).
#' @param zrodlo napis okreslajacy z jakiego zrodla bierzemy pod uwage artykuly,
#' dostepne wartosci:"gazeta.pl","tvn24.pl","wiadomosci.wp.pl","wiadomosci.onet.pl","brak".
#' @param co  napis okreslajacy gdzie szukamy wystapien kandydatow, dostepne wartosci: "tytul","tagi","tresc".
#' @param coile wartosc liczbowa co jaki okres czasu liczymy wartosci miary.
#' @param od_ktorego data w formacie POSIX od ktorej zaczynamy rysowanie wykresu.
#' @param do_ktorego data w formacie POSIX na ktorej konczymy rysowanie wykresu.
#' @param ktorzykandydaci wektor napisow okreslajacy ktorych kandydatow chcemy widziec na wykresie.
#'
#' @details \code{wykresMaksymalnejSerii} rysuje wykres, na osi x mamy czasy, na osi y wartosc maksymalnej serii.
#' Dla kazdego czasu liczona jest wartosc maksymalnej serii dla wbranych kandydatow, punkty sa laczone liniami (powstaja lamane).
#'
#' @return wykres zaleznosci miedzy wartoscia maksymalnej serii a czasem.
#'
#' @examples
#' wykresMaksymalnejSerii(dane_artykuly,"brak","tytul",7,as.Date("04-04-2015","%d-%m-%Y"),as.Date("05-05-2015","%d-%m-%Y"))
#'
wykresMaksymalnejSerii<-function(dane,zrodlo,co,coile,od_ktorego,do_ktorego,ktorzykandydaci= c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                                                                         "Wilk","Braun","Kukiz"))
{

   #ruchomy zmienna ktora nam bedzie mowic co ile dni uzyskujmey wartosci miary
   ruchomy<-od_ktorego
   #Tu przechowujemy wartosci miar
   df<-data.frame()
   #A tu czasy koncowe (zmieniaja sie w kazdym obrocie petli o coile az do osiagniecia dzisiejszego czasu)
   czas<-c()

   while(ruchomy<=do_ktorego)
   {
      #maksymalne serie do czasu ruchomy
      temp<-iloscDni(dane,zrodlo,co,stri_replace_all_regex(as.character(od_ktorego) ,
                                                              "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                              "$3-$2-$1"),stri_replace_all_regex(as.character(ruchomy) ,
                                                                                                 "([0-9]{4})-([0-9]{2})-([0-9]{2})",
                                                                                                 "$3-$2-$1"))
      #uzyskanie ruchomego jako napisu
      temp1<-as.character(ruchomy)


      #skok
      ruchomy<-ruchomy+coile
      df<-rbind(df,temp)
      czas<-c(czas,temp1)
   }
   kolory<-c("black","yellow","blue","red","purple","green","brown","orange","magenta","cyan")
   names(kolory)<-c("Komorowski","Kowalski","Duda","Palikot","Jarubas","Ogorek","Korwin-Mikke",
                    "Wilk","Braun","Kukiz")
   colnames(df)<-names(kolory)
   df<-cbind(czas,df)
   #zeby linie byly widoczne odchylmy je nieznacznie od siebie (zeby nie zachodzily)
   for(i in 2:11)
   {
      df[,i]<-df[,i]+0.005*i*(-1)^i
   }

   id<-1:nrow(df)
   df<-cbind(df,id)
   #wybieramy tylko tych ktorzy nas interesuja
   df<-df[,c("czas",ktorzykandydaci,"id")]
   #kolory wykresow

   kolory<-kolory[ktorzykandydaci]
   dfm <- melt(df, id.var = c("id","czas"))
   #wykres
   p<-ggplot(dfm, aes(czas,value,group= variable,colour = variable)) +geom_line()+scale_colour_manual(values=kolory)+
      ggtitle("Maksymalna dlugosc serii wzgledem czasu") +
      theme(plot.title = element_text(size = 16))
   p+xlab("czas") + ylab("Dlugosc serii")+theme(axis.text.x = element_text(angle = 90, hjust = 1))
}
