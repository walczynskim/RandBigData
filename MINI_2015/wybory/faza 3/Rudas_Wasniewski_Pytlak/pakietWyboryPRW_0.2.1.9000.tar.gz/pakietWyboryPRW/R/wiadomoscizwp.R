#' Pobieranie informacji z artykulow z portalu wp.pl ktorych daty sa pozniejsze od zadanej
#'
#' Funkcja \code{wiadomoscizwp} sciaga artykuly z portalu wp.pl z zakladki wybory o dacie pozniejszej od zadanej.
#'
#' @usage
#' \code{wiadomoscizwp(czas)}
#'
#' @param czas czas od ktorego zaczynamy pobieranie (wpisywany jako czas POSIX).
#' @details \code{wiadomoscizwp} przeszukuje strony artykulow z portalu wp.pl, z zakladki wybory, o dacie powstania pozniejszej od zadanej w argumencie.
#' Szuka przydatnych informacji o nich takich jak np. tresc, zrodlo, tytul, tagi, czas powstania artykulu, komentarze.
#'
#' @return Zwraca ramke danych zlozona z id, zrodla ( w tym wypadku to wp.pl), czasu powstania, 
#' tytulu, tresci,tagow, liczby komentarzy z artykulow o dacie pozniejszej od zadanej w argumencie.
#'
#' @examples
#' wiadomoscizwp(strptime("01-05-2015 10:00","%d-%m-%Y %H:%M"))
#'
wiadomoscizwp<-function(czas)
{
   #link z zakladki wyborow
   link<-"http://wiadomosci.wp.pl/kat,140394,title,Wybory-prezydenckie-w-2015-r,raport.html"
   adres<-html(link)
   adres_nodes<-html_nodes(adres,".kontener h2 a")
   adresy_artykulow<-stri_paste("http://wiadomosci.wp.pl",html_attr(adres_nodes,"href"))
   #adresy artykulow
   adresy_artykulow<-unique(adresy_artykulow)
   dl<-length(adresy_artykulow)
   #Znajdujemy daty i godziny artykulow
   daty<-html_nodes(adres,".stampZrodloData")%>%html_text()
   godziny<-html_nodes(adres,".stampZrodloCzas .stampZrodloGodzina")%>%html_text()
   godziny<-stri_extract_all_regex(godziny,"[0-9]{2}:[0-9]{2}")%>%unlist()
   #Z ich zlaczenia otrzymujemy czasy
   czasy_art<-stri_paste(daty,godziny,sep=" " )
   #w ta ramke bedziemy zapisywac dane
   informacje<-data.frame()
   for(i in 1:dl)
   {
      temp1<-NULL
      #Sprobuj przerobic na date
      try(temp1<-strptime(czasy_art[i],"%Y-%m-%d %H:%M"))
      #Jesli sie udalo to:
      if(length(temp1)!=0)
      {
         temp<-data.frame()
         #Sprobuj pobrac info z artykulu
         try(temp<-wp_artykul_info(adresy_artykulow[i],i),silent=TRUE)
         #Jesli sie udalo to:
         if(length(temp)!=0)
         {
            #Jesli data pozniejsza od zadanej to:
            if(unclass(czas-temp1)<=0)
            {
               #Dopisuj do ramki
               informacje<-rbind(informacje,temp)
            }  
            
         } 
      }
      
      
   }
   #Zwroc ramke
   informacje
}