library("dygraphs")
library("RSQLite")
library("tidyr")
library("stringi")
library("xts")
library(wyborySmudaWyszynska)

nazwiskaKandydatow <- slownik_fb_kandydaci
#Grupy wskaźników
GrupaFacebookLikes <- c("IloscPolubienFB", "SzybkoscPolubienFB" )
GrupaFacebookPosty <- c("SredniaLikePostFB", "SredniaKomentarzPostFB",
                        "SredniaSharePostFB")
GrupaGoogleNews <- c("IloscGoogle", "SredniGoogle")
GrupaPortaleInternetoweTytuly <- c("TytulyInteria", "TytulyOnet", "TytulyWP")
GrupaPortaleInternetoweWydzwiek <- c("ArtykulyInteria", "ArtykulyOnet", "ArtykulyWP")
ListaGrup <- list(GrupaFacebookLikes, GrupaFacebookPosty,
                     GrupaGoogleNews, GrupaPortaleInternetoweTytuly,
                     GrupaPortaleInternetoweWydzwiek)

shinyServer(function(input,output){
 
      #Tworze opcje z kandydatami
      output$kandydaciWiele<-renderUI({
        text <- paste('"', nazwiskaKandydatow, '"', sep="")
        text <- paste(text, seq_along(text), sep="=", collapse=", ")
        text <- paste0('list(', text, ')')
        lista <- eval(parse(text=text))
        selectInput("kandydaci", label=h3(strong("Kandydaci")), 
                         choices=lista, selected=1, multiple=TRUE)

      })
      
      output$kandydaciJeden<-renderUI({
        text <- paste('"', nazwiskaKandydatow, '"', sep="")
        text <- paste(text, text, sep="=", collapse=", ")
        text <- paste0('list(', text, ')')
        lista <- eval(parse(text=text))
        selectInput("kandydaci1", label=h3(strong("Kandydaci")), 
                    choices=lista, selected=lista[[1]])
        
      })
      
      output$opisWskaznika <- renderText({
     if(input$wskazniki=="IloscTweetow"){return("Opisuje ilość tweetów, 
          w których znaleziono nazwisko danego kandydata.")}
     if(input$wskazniki=="WydzwiekTweetow"){return("Opisuje wydźwięk tweetów, 
          w których znaleziono nazwisko danego kandydata. Gdy nie znaleźliśmy 
          żadnych tweetów dotyczących danego kandydata przyjmujemy wskaźnik
          równy 0. Sposób analizy jest szczegółowo opisany w załączonym do 
          biblioteki pdf.")}
     if(input$wskazniki=="IloscPolubienFB"){return("Określa ilość like'ów
          oficjalnego fanpage’a kandydata. W przypadku dłuższych okresów
          czasowych wybiera maksimum z odczytanych w tym okresie wartości.")}
     if(input$wskazniki=="SzybkoscPolubienFB"){return("Określa średnią prędkość 
          wzrostu polubień oficjalnego fanpage’a  kandydata.")}
     if(input$wskazniki=="IloscPostowFB"){return("Określa ilość postów opublikowanych 
          na oficjalnym fanpage’u kandydata.")}
     if(input$wskazniki=="SredniaLikePostFB"){return("Średnia ilość like'ów 
          otrzymanych na jednego posta opublikowanego na oficjalnym fanpage’u
          kandydata.")}
     if(input$wskazniki=="SredniaKomentarzPostFB"){return("Średnia ilość 
          komentarzy otrzymanych na jednego posta opublikowanego na oficjalnym 
          fanpage’u  kandydata.")}
     if(input$wskazniki=="SredniaSharePostFB"){return("Średnia ilość udostępnień 
          na jednego posta opublikowanego na oficjalnym fanpage’u
          kandydata.")}
     if(input$wskazniki=="IloscGoogle"){return("Ilość wystąpień nazwiska 
          kandydata na stronach z artykułami wyświetlanymi w danym czasie
          przez GoogleNews.")}
     if(input$wskazniki=="SredniGoogle"){return("Średnia ilość wystąpień 
          (dzielona przez wystąpienia nazwisk wszystkich kandydatów) nazwiska 
          kandydata na stronach z artykułami wyświetlanymi w danym czasie prze
          GoogleNews.")}
     if(input$wskazniki=="TytulyInteria"){return("Ważona suma ilości wystąpień 
          nazwiska danego kandydata w tytułach artykułów na portalu
          informacyjnym Interia. Ilość wystąpień w danym tytule jest 
          mnożona przez wagę widoczności.  Sposób nadawania wag jest szczegółowo 
          opisany w załączonym do biblioteki pdf.")}
     if(input$wskazniki=="TytulyOnet"){return("Ważona suma ilości wystąpień 
          nazwiska danego kandydata w tytułach artykułów na portalu
          informacyjnym Onet. Ilość wystąpień w danym tytule jest 
          mnożona przez wagę widoczności.  Sposób nadawania wag jest szczegółowo 
          opisany w załączonym do biblioteki pdf.")} 
     if(input$wskazniki=="TytulyWP"){return("Ważona suma ilości wystąpień 
          nazwiska danego kandydata w tytułach artykułów na portalu
          informacyjnym WP. Ilość wystąpień w danym tytule jest 
          mnożona przez wagę widoczności.  Sposób nadawania wag jest szczegółowo 
          opisany w załączonym do biblioteki pdf.")}
     if(input$wskazniki=="TytulyPortale"){return("Suma ważonych sum ilości 
          wystąpień nazwiska danego kandydata w tytułach artykułów na
          portalach informacyjnych: ( TytulyInteria + TytulyOnet + TytulyWP ).")} 
     if(input$wskazniki=="ArtykulyInteria"){return("Opisuje wydźwięk artykułów 
          zebranych z portalu informacyjnego Interia,
          w których znaleziono nazwisko danego kandydata. Sposób analizy jest 
          szczegółowo opisany w załączonym do biblioteki pdf.")}
     if(input$wskazniki=="ArtykulyOnet"){return("Opisuje wydźwięk artykułów 
          zebranych z portalu informacyjnego Onet,
          w których znaleziono nazwisko danego kandydata. Sposób analizy jest 
          szczegółowo opisany w załączonym do biblioteki pdf.")}
     if(input$wskazniki=="ArtykulyWP"){return("Opisuje wydźwięk artykułów 
          zebranych z portalu informacyjnego WP,
          w których znaleziono nazwisko danego kandydata. Sposób analizy jest 
          szczegółowo opisany w załączonym do biblioteki pdf.")}
     if(input$wskazniki=="ArtykulyPortale"){return("Suma wydźwięku dla artykułów
          ze wszystkich trzech portali: (ArtykulyOnet + ArtykulyWP + ArtykulyPortale).")} 
   })
      
   
      #tworze wykres
      output$dygraph1 <- renderDygraph({
        if(input$Wybor1=="Kandydaci"){
         #Polaczenie z baza i wydobycie danych
         polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")
         polecenie <- paste0("SELECT Wzorzec, ImieINazwisko, ", input$wskazniki, 
                             " FROM Dzien t JOIN Kandydaci k ON 
                             t.IDKandydata=k.IDKandydata")
         data <- dbGetQuery(polaczenie, polecenie)
         dbDisconnect(polaczenie)
         #Zmiana formy danych i wybranie odpowiednich kandydatow
         data <- eval(parse(text=paste0("spread(data,ImieINazwisko,", 
                                        input$wskazniki, ")")))
         wybrani <- nazwiskaKandydatow[as.numeric(input$kandydaci)]
         daty <- as.Date(data[ ,1])
         
         data <- data[ ,wybrani]

          return(dygraph(xts(data, order.by=daty), 
                             main="") %>% 
                   dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
                   dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
                   dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
                           dyRangeSelector() ) } else {
                             
        #Polaczenie z baza i wydobycie danych
        Grupa <- ListaGrup[[as.double(input$typWskaznikow)]]
        polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")

        polecenie <- paste0("SELECT Wzorzec, ", paste(Grupa, collapse=", "), " FROM Dzien t JOIN Kandydaci k ON 
                                                 t.IDKandydata=k.IDKandydata WHERE k.ImieINazwisko='", input$kandydaci1,"'")

                             data <- dbGetQuery(polaczenie, polecenie)
                             dbDisconnect(polaczenie)

                             daty <- as.Date(data[ ,1])
                             data <- data[ ,-1]

                             return(dygraph(xts(data, order.by=daty), 
                                            main="") %>% 
                                      dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
                                      dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
                                      dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
                                      dyRangeSelector() )      
        }
      })
   
      output$dygraph2 <- renderDygraph({
        if(input$Wybor1=="Kandydaci"){
    #Polaczenie z baza i wydobycie danych
    polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")
    polecenie <- paste0("SELECT Wzorzec, ImieINazwisko, ", input$wskazniki, 
                        " FROM Tydzien t JOIN Kandydaci k ON 
                        t.IDKandydata=k.IDKandydata")
    data <- dbGetQuery(polaczenie, polecenie)
    dbDisconnect(polaczenie)
    #Zmiana formy danych i wybranie odpowiednich kandydatow
    data <- eval(parse(text=paste0("spread(data,ImieINazwisko,", 
                                   input$wskazniki, ")")))
    wybrani <- nazwiskaKandydatow[as.numeric(input$kandydaci)]
    daty <- as.Date(paste0(data[ ,1], "-01"), "%Y-%W-%w")
    
    data <- data[ ,wybrani]

    return(dygraph(xts(data, order.by=daty), 
                   main="") %>% 
             dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
             dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
             dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
             dyRangeSelector() )} else {
               #Polaczenie z baza i wydobycie danych
               Grupa <- ListaGrup[[as.double(input$typWskaznikow)]]
               polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")
               
               polecenie <- paste0("SELECT Wzorzec, ", paste(Grupa, collapse=", "), " FROM Tydzien t JOIN Kandydaci k ON 
                                                 t.IDKandydata=k.IDKandydata WHERE k.ImieINazwisko='", input$kandydaci1,"'")
               
               data <- dbGetQuery(polaczenie, polecenie)
               dbDisconnect(polaczenie)
               
               daty <- as.Date(paste0(data[ ,1], "-01"), "%Y-%W-%w")
               data <- data[ ,-1]
               
               return(dygraph(xts(data, order.by=daty), 
                              main="") %>% 
                        dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
                        dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
                        dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
                        dyRangeSelector() )           
             
    }
  })
  
      output$dygraph3 <- renderDygraph({
        if(input$Wybor1=="Kandydaci"){
    #Polaczenie z baza i wydobycie danych
    polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")
    polecenie <- paste0("SELECT Wzorzec, ImieINazwisko, ", input$wskazniki, 
                        " FROM Miesiac t JOIN Kandydaci k ON 
                        t.IDKandydata=k.IDKandydata")
    data <- dbGetQuery(polaczenie, polecenie)
    dbDisconnect(polaczenie)
    #Zmiana formy danych i wybranie odpowiednich kandydatow
    data <- eval(parse(text=paste0("spread(data,ImieINazwisko,", 
                                   input$wskazniki, ")")))
    wybrani <- nazwiskaKandydatow[as.numeric(input$kandydaci)]
    daty <- as.yearmon(data[ ,1])
    
    data <- data[ ,wybrani]
    head(data)
    return(dygraph(xts(data, order.by=daty), 
                   main="") %>% 
             dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
             dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
             dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
             dyRangeSelector() )} else {
               #Polaczenie z baza i wydobycie danych
               Grupa <- ListaGrup[[as.double(input$typWskaznikow)]]
               polaczenie <- dbConnect(SQLite(), "baza_wybory.sql")
               
               polecenie <- paste0("SELECT Wzorzec, ", paste(Grupa, collapse=", "), " FROM Miesiac t JOIN Kandydaci k ON 
                                                 t.IDKandydata=k.IDKandydata WHERE k.ImieINazwisko='", input$kandydaci1,"'")
               
               data <- dbGetQuery(polaczenie, polecenie)
               dbDisconnect(polaczenie)
               
               daty <- as.yearmon(data[ ,1])
               data <- data[ ,-1]
               
               return(dygraph(xts(data, order.by=daty), 
                              main="") %>% 
                        dyOptions(axisLineColor="#000000", axisLabelColor="#3D3D99") %>%
                        dyShading(from=min(daty), to=max(daty), color="#FAFAFA") %>%
                        dyLegend(width = 220, labelsSeparateLines=TRUE) %>% 
                        dyRangeSelector() ) 
               
      
             }
  })
      
   })