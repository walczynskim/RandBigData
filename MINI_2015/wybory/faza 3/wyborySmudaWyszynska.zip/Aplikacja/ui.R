library(dygraphs)

shinyUI(fluidPage( theme="flatly.css",
                   img(src="tytul.png", width=1000),
                   headerPanel(title="", windowTitle="Wybory prezydenckie 2015"),

   sidebarLayout(
     sidebarPanel(width=4,
                  
                  tabsetPanel(
                    tabPanel("Kandydaci",
        uiOutput("kandydaciWiele"),
        selectInput("wskazniki", label=h3(strong("Wskaźnik")),
                    choices=list("Ilość Tweetów"="IloscTweetow",
                                 "Wydźwięk Tweetów" ="WydzwiekTweetow",
                                 "Ilość polubień na FB" ="IloscPolubienFB",
                                 "Szybkość Polubień na FB"="SzybkoscPolubienFB",
                                 "Ilość postów na FB"="IloscPostowFB",
                                 "Średnia ilość like na FB"="SredniaLikePostFB",
                                 "Średni liczba komentarzy FB"="SredniaKomentarzPostFB",
                                 "Średnia liczba udostępnień na FB"="SredniaSharePostFB",
                                 "Ilość wystąpień nazwiska na portalu GoogleNews"="IloscGoogle",
                                 "Średnia liczba wystąpień nazwiska na portalu GoogleNews"="SredniGoogle",
                                 "Ilość wystąpień nazwiska w tytułach na portalu Interia"="TytulyInteria",
                                 "Ilość wystąpień nazwiska w tytułach na portalu Onet"="TytulyOnet",
                                 "Ilość wystąpień nazwiska w tytułach na portalu WP"="TytulyWP",
                                 "Ilość wystąpień nazwiska w tytułach artukułów"="TytulyPortale",
                                 "Widoczność w artykułach w serwisie Interia"="ArtykulyInteria",
                                 "Widoczność w artykułach w serwisie Onet"="ArtykulyOnet",
                                 "Widoczność w artykułach w serwisie WP"="ArtykulyWP",
                                 "Widoczność w artykułach w serwisach internetowych"="ArtykulyPortale"),
                    selected="IloscTweetow"),
        helpText(textOutput("opisWskaznika"))
         ),
        tabPanel("Wskaźniki",
                 uiOutput("kandydaciJeden"),
                 radioButtons("typWskaznikow", h3(strong("Grupa wskaźników")),
                                                  choices=list( 
                                                               "Facebook (likes)"=1,
                                                               "Facebook (posty)"=2,
                                                               "GoogleNews"=3,
                                                               "Portale internetowe - tytuły"=4,
                                                               "Portale internetowe - wydźwięk"=5),
                                                               selected=1)
         ), id="Wybor1"
        )),


      mainPanel(
        tabsetPanel(
          tabPanel(strong("Instrukcja", style="color:#3D3D99"),
                   br(),

                   h3(strong("Witaj w aplikacji Wybory!"), style="color:#3D3D99"),
                   p("Masz przed sobą aplikację służącą do prezentacji wyników
                      projektu 'Wybory'. Projekt polegał na zbadaniu widoczności
                      poszczególnych kandydatów na prezydenta w internecie.
                      Sama aplikacja prezentuje zagregowane dane zebrane w
                      okresie 14.03.2015 - 10.05.2015. Po lewej stronie znajduje
                      się menu, w którym możesz wybrać, który wskaźnik i dla
                      których kandydatów chcesz obejrzeć na wykresie. Wszystkie
                      wskaźniki posiadają opis, który wyświetli się pod
                      okienkiem wyboru. Powyżej w zakładkach możesz wybrać dla
                      jakiego okresu chesz obejrzeć wyniki.
                      Jeśli chcesz dowiedzieć się więcej, sam(a) chcesz zebrać
                      podobne dane, bądź
                      przeliczyć wskaźniki zapraszamy do skorzystania z biblioteki
                      wyborySmudaWysznska i przeczytania dokumentacji projektu.
                     Wszystko to znajdziesz ", a("tutaj.", 
                                href="https://github.com/Wyszynskak/Projekty"),
                     style="color:#3D3D99"), 

                   p("Piotr Smuda & Karolina Wyszyńska", style="color:#3D3D99")

          ),
          tabPanel(strong("Dzień", style="color:#3D3D99"), br(),
                   h4(strong("Widoczność kandydatów w internecie"),
                      style="color:#3D3D99", align="center"),
                   dygraphOutput("dygraph1")),
          tabPanel(strong("Tydzień", style="color:#3D3D99"), br(),
                   h4(strong("Widoczność kandydatów w internecie"),
                      style="color:#3D3D99", align="center"),
                   dygraphOutput("dygraph2")),
          tabPanel(strong("Miesiąc", style="color:#3D3D99"), br(),
                   h4(strong("Widoczność kandydatów w internecie"),
                      style="color:#3D3D99", align="center"),
                   dygraphOutput("dygraph3")),
          id="czas", selected=strong("Instrukcja", style="color:#3D3D99")),
        br()
         )
      )
   ))
