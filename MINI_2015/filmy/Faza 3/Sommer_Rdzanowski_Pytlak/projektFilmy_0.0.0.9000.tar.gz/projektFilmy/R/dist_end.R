#' Wyznacz macierz pseudo-odleglosci dla wybranych filmow.
#'
#' Funkcja \code{dist_end} zwraca macierz pseudo-odleglosci pomiedzy filmami powstala na bazie pewnych charakterystyk filmow.
#'
#' @aliases dist_end
#' @param dane Ramka danych o zmiennych takich samych jak ramka \code{\link{filmy}}.
#' @param wybrane Wektor numeryczny zawierajacy liczby naturalne pomiedzy 1 a \code{nrow(dane)}. Wyznacza numery obserwacji, dla ktorych liczona bedzie macierz pseudo-odleglosci. Domyslnie \code{wybrane = 1}.
#' @param wagi Wektor numeryczny liczb nieujemnych dlugosci 5.
#' @return Macierz o wymiarach \code{length(x)} na \code{length(wybrane)} zawierajaca liczby z przedzialu \code{[0,1]}. Element \code{(i,j)} macierzy otrzymanej przy pomocy funkcji \code{dist_end} okresla pseudo-odleglosc pomiedzy \code{i}-ta i \code{j}-ta obserwacja wyliczona na podstawie roznych charakterystyk filmow zawartych w ramce danych \code{dane}.
#' @examples
#' data(filmy)
#' dist <- dist_end(dane = filmy[1:200,], wybrane = 1:2, wagi = c(1, 3, 2, 2, 8))
#' @seealso \code{\link{dist_log}}, \code{\link{dist_lin}}, \code{\link{dist_procent}}, \code{\link{dist_exp}}
#'

dist_end <- function(dane, wybrane = 1, wagi = c(czas = 1, ocena = 1, widocznosc = 1, geo = 1, naj = 1)){
  t1 <- dist_log(x = dane$rok_produkcji, wybrane = wybrane, a = 7)
  t2 <- dist_lin(x = dane$filmweb_minuty_trwania_filmu, wybrane = wybrane, ogr = 150)

  t3 <- dist_exp(x = dane$filmweb_ktory_w_world_rankingu, wybrane = wybrane, a = 4)
  t4 <- dist_exp(x = dane$filmweb_ocena_filmu, wybrane = wybrane, a = 4)
  t5 <- dist_exp(x = dane$imdb_ocena, wybrane = wybrane, a = 4)

  t6 <- dist_lin(x = dane$filmweb_ile_osob_chce_zobaczyc, wybrane = wybrane)
  t7 <- dist_lin(x = dane$filmweb_liczba_komentarzy, wybrane = wybrane)
  t8 <- dist_lin(x = dane$filmweb_liczba_oddanych_glosow, wybrane = wybrane)
  t9 <- dist_lin(x = dane$imdb_liczba_glosow, wybrane = wybrane)
  t10 <- dist_lin(x = dane$imdb_liczba_recenzji_uzyt, wybrane = wybrane)

  t11 <- dist_procent(x = dane$imdb_jezyk, wybrane = wybrane)
  t12 <- dist_procent(x = dane$imdb_kraj_produkcji, wybrane = wybrane)
  t13 <- dist_procent(x = dane$imdb_rezyseria, wybrane = wybrane)

  t14 <- dist_procent(x = dane$imdb_gatunek, wybrane = wybrane)
  t15 <- dist_procent(x = dane$imdb_dla_kogo, wybrane = wybrane)
  t16 <- dist_procent(x = dane$imdb_slowa_kluczowe, wybrane = wybrane)

  t <- wagi[1]*(t1+t2)+wagi[2]*(t3+t4+t5)+wagi[3]*(t6+t7+t8+t9+t10)+wagi[4]*(t11+t12+t13)+wagi[5]*(t14+t15+t16)
  srednia <- t/(sum(c(2, 3, 5, 3, 3)*wagi))
#   colnames(srednia) <- dane$tytul_uproszczony[wybrane]
#   rownames(srednia) <- dane$tytul_uproszczony
  colnames(srednia) <- dane$tytul_filmweb[wybrane]
  rownames(srednia) <- dane$tytul_filmweb
  return(srednia)
}
