#' Wyznacz macierz pseudo-odleglosci dla wybranych obserwacji.
#'
#' Funkcja \code{dist_procent} zwraca macierz pseudo-odleglosci pomiedzy obserwacjami oparta o funkcje liniowa.
#'
#' @aliases dist_procent
#' @param x Wektor napisow.
#' @param wybrane Wektor numeryczny zawierajacy liczby naturalne pomiedzy 1 a \code{length(x)}. Wyznacza numery obserwacji, dla ktorych liczona bedzie macierz pseudo-odleglosci. Domyslnie \code{wybrane = 1}.
#' @param imputacja Wektor logiczny dlugosci jeden okreslajacy, czy nalezy dokonac imputacji wartosci brakujacych w macierzy pseudo-odleglosci.
#' @return Macierz o wymiarach \code{length(x)} na \code{length(wybrane)} zawierajaca liczby z przedzialu \code{[0,1]}. Element \code{(i,j)} macierzy otrzymanej przy pomocy funkcji \code{dist_procent} okresla pseudo-odleglosc pomiedzy \code{i}-ta i \code{j}-ta obserwacja.
#' @examples
#' dist_procent(c(1:19,1), imputacja = FALSE)
#' @seealso \code{\link{dist_exp}}, \code{\link{dist_log}}, \code{\link{dist_lin}}
#' @import stringi

dist_procent <- function(x, wybrane = 1, imputacja = TRUE){
  w1 <- is.na(x)
  w2 <- is.na(x[wybrane])
  if(all(w1) || all(w2)){
    if(imputacja){
      macierz <- matrix(rep(0.5, length(x)*length(wybrane)), ncol = length(wybrane))
      if(length(wybrane) == 1){
        macierz[wybrane,] <- 0
      }
      else{
        diag(macierz[wybrane,]) <- 0
      }
      return(macierz)
    }
    else{
      macierz <- matrix(rep(NA, length(x)*length(wybrane)), ncol = length(wybrane))
      if(length(wybrane) == 1){
        macierz[wybrane,] <- 0
      }
      else{
        diag(macierz[wybrane,]) <- 0
      }
      return(macierz)
    }
  }
  n <- length(x)
  macierz <- matrix(rep(0, length(wybrane)*n), nrow = n, ncol = length(wybrane))
  xx <- stri_extract_all_words(x)
  for(i in 1:n){
    for(j in 1:length(wybrane)){
      if(is.na(xx[[i]]) || is.na(xx[[j]])){
        macierz[i,j] <- NA
      }
      else{
        macierz[i,j] <- 1-length(intersect(xx[[i]], xx[[wybrane[j]]]))/length(union(xx[[i]], xx[[wybrane[j]]]))
      }
    }
  }
  if(imputacja){
    srednia <- mean(macierz, na.rm = T)
    macierz[is.na(macierz)] <- srednia
    if(length(wybrane) == 1){
      macierz[wybrane,] <- 0
    }
    else{
      diag(macierz[wybrane,]) <- 0
    }
    return(macierz)
  }
  else{
    if(length(wybrane) == 1){
      macierz[wybrane,] <- 0
    }
    else{
      diag(macierz[wybrane,]) <- 0
    }
    return(macierz)
  }
}
