#' Wyznacz filmy podobne do wybranych.
#'
#' Funkcja \code{podobne_filmy_2} zwraca macierz tytulow filmow najbardziej podobnych do wybranych.
#'
#' @aliases podobne_filmy_2
#' @param dist Macierz pseudo-odleglosci powstala przy pomocy funkcji \code{dist_end}.
#' @param wybrane Wektor numeryczny zawierajacy liczby naturalne pomiedzy 1 a \code{ncol(dane)}. Wyznacza numery filmow, dla ktorych liczona bedzie macierz pseudo-odleglosci. Domyslnie \code{wybrane = 1:ncol(dist)}.
#' @param ile Wektor numeryczny dlugosci 1. Liczba naturalna okreslajaca ile najbardziej podobnych filmow chcemy znalezc. Domyslnie \code{ile = 3}.
#' @param wagi Wektor numeryczny liczb nieujemnych dlugosci 5.
#' @return Macierz o wymiarach \code{ile} na \code{length(wybrane)} zawierajaca najbardziej podobne filmy. Element \code{(i,j)} tej macierzy to \code{i}-ty najbardziej podobny tytul filmu do filmu \code{dane$tytul_uproszczony[wybrane][j]}.
#' @examples
#' data(filmy)
#' dist <- dist_end(dane = filmy[1:200,], wybrane = 1:2, wagi = c(1, 3, 2, 2, 8))
#' podobne_filmy_2(dist, ile = 5)
#' @seealso \code{\link{dist_end}}, \code{\link{podobne_filmy}}
#'

podobne_filmy_2 <- function(dist, wybrane = 1:ncol(dist), ile = 3){
  dist[which(dist == 0)] <- 1
  dist_ile <- apply(dist, MARGIN = 2, function(x){sort.int(x, partial = ile)[ile]})

  wynik <- matrix(rep("", length(wybrane)*ile), nrow = ile, ncol = length(wybrane))
  colnames(wynik) <- colnames(dist)

  for(i in 1:length(wybrane)){
    w <- which(dist[,i] <= dist_ile[i])[1:ile]
    porz <- order(dist[w,i])
    wynik[,i] <- rownames(dist)[w][porz]
  }
  return(list(wynik = wynik, ktore = w[porz]))
}
