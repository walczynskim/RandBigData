#' Zobrazuj podobienstwo pomiedzy filmami.
#'
#' Funkcja \code{skalowanie} wyznacza reprezentacje graficzna podobienstwa pomiedzy wybranymi filmami.
#'
#' @aliases skalowanie
#' @param dist Macierz pseudo-odleglosci powstala przy pomocy funkcji \code{dist_end}.
#' @param dim Wymiar reprezentacji graficznej. Domyslnie \code{dim = 2}. Inna mozliwa opcja to \code{dim = 3}.
#' @param rgl Wektor logiczny dlugosci 1 okreslajacy czy reprezentacja trojwymiarowa moze miec mozliwosc obracania.
#' @return Funkcja \code{skalowanie} zwraca wartosc \code{NULL}.
#' @examples
#' data(filmy)
#' dist <- t(dist_end(dane = filmy[1:200,], wybrane = 1:11, wagi = c(1, 3, 2, 2, 8)))
#' skalowanie(dist, dim = 3, rgl = TRUE)
#' @seealso \code{\link{dist_end}}, \code{\link{podobne_filmy}}
#'

skalowanie <- function(dist, dim = 2, rgl = FALSE){
  kowar <- cov(dist)
  eigen <- eigen(kowar)
  rzut_1 <- dist%*%eigen$vectors[,1]
  rzut_2 <- dist%*%eigen$vectors[,2]
  rzut_3 <- dist%*%eigen$vectors[,3]
  dane <- data.frame(rzut_1 = rzut_1, rzut_2 = rzut_2, rzut_3 = rzut_3, nazwy = rownames(dist))
  if(dim == 2){
    ggplot(data = dane, aes(as.numeric(rzut_1), as.numeric(rzut_2), label = nazwy))+
      geom_point()+
      labs(list(x = "pierwszy rzut kanoniczny", y = "drugi rzut kanoniczny"))+
      geom_text(angle = 45)
  }
  else if(dim == 3 && rgl == FALSE){
    with(data = data.frame(rzut1 = rzut_1, rzut2 = rzut_2, rzut3 = rzut_3),
         text3D(rzut1, rzut2, rzut3, cex = 1.5,
                colvar = NULL, col = gg.col(100),
                theta = 40, phi = 10,
                xlab = "pierwszy rzut kanoniczny",
                ylab = "drugi rzut kanoniczny",
                zlab = "trzeci rzut kanoniczny",
                labels = rownames(dist), cex = 0.6,
                bty = "g", ticktype = "detailed", d = 6,
                adj = 0.5, font = 1))
  }
  else if(dim == 3 && rgl == TRUE){
    nazwy <- rownames(dist)
    nazwy <- stri_replace_all_regex(nazwy, "ą|ć|ę|ł|ń|ó|ś|ź|ż|Ą|Ć|Ę|Ł|Ń|Ó|Ś|Ź|Ż", "_")
    open3d()
    plot3d(rzut_1, rzut_2, rzut_3,
           xlab = "pierwszy rzut kanoniczny",
           ylab = "drugi rzut kanoniczny",
           zlab = "trzeci rzut kanoniczny")
    text3d(rzut_1, rzut_2, rzut_3,
           text = nazwy,
           adj = 0)
  }
}
