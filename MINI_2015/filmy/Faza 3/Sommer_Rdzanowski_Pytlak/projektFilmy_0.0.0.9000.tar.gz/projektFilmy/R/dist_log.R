#' Wyznacz macierz pseudo-odleglosci dla wybranych obserwacji.
#'
#' Funkcja \code{dist_log} zwraca macierz pseudo-odleglosci pomiedzy obserwacjami oparta o funkcje liniowa.
#'
#' @aliases dist_log
#' @param x Wektor numeryczny.
#' @param wybrane Wektor numeryczny zawierajacy liczby naturalne pomiedzy 1 a \code{length(x)}. Wyznacza numery obserwacji, dla ktorych liczona bedzie macierz pseudo-odleglosci. Domyslnie \code{wybrane = 1}.
#' @param a Liczba wchodzaca do wzoru funkcji, na podstawie ktorej liczona jest macierz pseudo-odleglosci.
#' @param imputacja Wektor logiczny dlugosci jeden okreslajacy, czy nalezy dokonac imputacji wartosci brakujacych w macierzy pseudo-odleglosci.
#' @return Macierz o wymiarach \code{length(x)} na \code{length(wybrane)} zawierajaca liczby z przedzialu \code{[0,1]}. Element \code{(i,j)} macierzy otrzymanej przy pomocy funkcji \code{dist_log} okresla logarytmiczna pseudo-odleglosc pomiedzy \code{i}-ta i \code{j}-ta obserwacja.
#' @examples
#' dist_log(x = c(1:100, NA), wybrane = c(1:3, 101), imputacja = TRUE)
#' @seealso \code{\link{dist_exp}}, \code{\link{dist_lin}}, \code{\link{dist_procent}}
#'

dist_log <- function(x, wybrane = 1, a, imputacja = TRUE){
  w1 <- is.na(x)
  w2 <- is.na(x[wybrane])
  max <- max(x, na.rm = T)
  min <- min(x, na.rm = T)
  if(max == min){return(matrix(rep(0, length(x)*length(wybrane)), ncol = length(wybrane)))}
  if(all(w1) || all(w2)){
    if(imputacja){
      macierz <- matrix(rep(0.5, length(x)*length(wybrane)), ncol = length(wybrane))
      if(length(wybrane) == 1){
        macierz[wybrane,] <- 0
      }
      else{
        diag(macierz[wybrane,]) <- 0
      }
      return(macierz)
    }
    else{
      macierz <- matrix(rep(NA, length(x)*length(wybrane)), ncol = length(wybrane))
      if(length(wybrane) == 1){
        macierz[wybrane,] <- 0
      }
      else{
        diag(macierz[wybrane,]) <- 0
      }
      return(macierz)
    }
  }
  macierz <- outer(x, x[wybrane], function(t1, t2){ log(1+a*abs(t1 - t2)/(max-min))/log(a+1) })
  if(imputacja){
    srednia <- mean(macierz, na.rm = T)
    macierz[is.na(macierz)] <- srednia
    if(length(wybrane) == 1){
      macierz[wybrane,] <- 0
    }
    else{
      diag(macierz[wybrane,]) <- 0
    }
    return(macierz)
  }
  else{
    if(length(wybrane) == 1){
      macierz[wybrane,] <- 0
    }
    else{
      diag(macierz[wybrane,]) <- 0
    }
    return(macierz)
  }
}
