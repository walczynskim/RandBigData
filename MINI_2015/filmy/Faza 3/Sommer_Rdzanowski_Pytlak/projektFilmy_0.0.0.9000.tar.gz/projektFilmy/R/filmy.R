#' Informacje o filmach
#'
#' Ramka danych zawiera informacje o ponad 42000 filmow.
#'
#' @format Ramka danych ze 42649 wierszami i 46 zmiennymi:
#' \describe{
#'   \item{tytul_filmweb}{intuicyjnie pojmowane}
#'   \item{rok_produkcji}{intuicyjnie pojmowane}
#'   \item{link_filmweb}{intuicyjnie pojmowane}
#'   \item{filmweb_box_office}{intuicyjnie pojmowane}
#'   \item{filmweb_dluzszy_opis_filmu}{intuicyjnie pojmowane}
#'   \item{filmweb_gatunek}{intuicyjnie pojmowane}
#'   \item{filmweb_ile_osob_chce_zobaczyc}{intuicyjnie pojmowane}
#'   \item{filmweb_kraj_produkcji}{intuicyjnie pojmowane}
#'   \item{filmweb_krotki_opis_filmu}{intuicyjnie pojmowane}
#'   \item{filmweb_ktory_w_world_rankingu}{intuicyjnie pojmowane}
#'   \item{filmweb_liczba_komentarzy}{intuicyjnie pojmowane}
#'   \item{filmweb_liczba_oddanych_glosow}{intuicyjnie pojmowane}
#'   \item{filmweb_minuty_trwania_filmu}{intuicyjnie pojmowane}
#'   \item{filmweb_ocena_filmu}{intuicyjnie pojmowane}
#'   \item{filmweb_premiera_polska}{intuicyjnie pojmowane}
#'   \item{filmweb_premiera_swiat}{intuicyjnie pojmowane}
#'   \item{tytul_uproszczony}{intuicyjnie pojmowane}
#'   \item{tytul_wikipedia}{intuicyjnie pojmowane}
#'   \item{link_wikipedia}{intuicyjnie pojmowane}
#'   \item{wikipedia_gatunek}{intuicyjnie pojmowane}
#'   \item{wikipedia_kraj_produkcji}{intuicyjnie pojmowane}
#'   \item{wikipedia_jezyk}{intuicyjnie pojmowane}
#'   \item{wikipedia_czas_trwania}{intuicyjnie pojmowane}
#'   \item{wikipedia_rezyseria}{intuicyjnie pojmowane}
#'   \item{wikipedia_budzet}{intuicyjnie pojmowane}
#'   \item{wikipedia_waluta}{intuicyjnie pojmowane}
#'   \item{imdb_tytul_ang}{intuicyjnie pojmowane}
#'   \item{link_imdb}{intuicyjnie pojmowane}
#'   \item{tytul_imdb}{intuicyjnie pojmowane}
#'   \item{imdb_dla_kogo}{intuicyjnie pojmowane}
#'   \item{imdb_czas_trwania}{intuicyjnie pojmowane}
#'   \item{imdb_gatunek}{intuicyjnie pojmowane}
#'   \item{imdb_data_premiery}{intuicyjnie pojmowane}
#'   \item{imdb_ocena}{intuicyjnie pojmowane}
#'   \item{imdb_liczba_glosow}{intuicyjnie pojmowane}
#'   \item{imdb_liczba_recenzji_uzyt}{intuicyjnie pojmowane}
#'   \item{imdb_liczba_recenzji_kryt}{intuicyjnie pojmowane}
#'   \item{imdb_ocena_met}{intuicyjnie pojmowane}
#'   \item{imdb_recenzje_met}{intuicyjnie pojmowane}
#'   \item{imdb_streszczenie}{intuicyjnie pojmowane}
#'   \item{imdb_rezyseria}{intuicyjnie pojmowane}
#'   \item{imdb_scenariusz}{intuicyjnie pojmowane}
#'   \item{imdb_obsada}{intuicyjnie pojmowane}
#'   \item{imdb_slowa_kluczowe}{intuicyjnie pojmowane}
#'   \item{imdb_kraj_produkcji}{intuicyjnie pojmowane}
#'   \item{imdb_jezyk}{intuicyjnie pojmowane}
#' }
"filmy"
