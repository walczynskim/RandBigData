library("shiny")

shinyUI(fluidPage(
  titlePanel(strong("Co dziś obejrzeć?")),
  sidebarLayout(
    mainPanel(
      tabsetPanel("main",
        tabPanel("Instrukcja",
          h3("Witaj!"),
          "Witaj w aplikacji 'Co dziś obejrzeć?'. Dzięki temu programowi od razu
          będziesz wiedział jaki film mógłby Ci się spodobać! Wystarczy, że po
          prawej stronie wprowadzisz swoje preferencje, a w zakładce 'Polecane'
          pojawi się mapa 10 filmów, które są polecane specjalnie dla Ciebie. 
          Aplikacja korzysta z bazy 262 388 filmów, więc na pewno znajdziesz 
          coś dla siebie!",
          br(),
          "Karolina Wyszyńska & Krzysztof Rudaś"
          ),
        tabPanel("Polecane 1",
          br(),
          h3(strong(textOutput("error")), style="color:red", align="center"),
          plotOutput("wykres")
          )
        ,
        tabPanel("Polecane 2",
          br(),
          h3(strong(textOutput("error2")), style="color:red", align="center"),
          plotOutput("wykres2")
          )
        )
     
              ),
    sidebarPanel(h2(strong("Preferencje")),
                 h4("Tytuł ulubionego filmu"),
                 textInput("tytul", label="", value="Podaj tytuł"),
                 h4("Wybierz dwie cechy, które są dla Ciebie najważniejsze"),
                 selectInput("cecha1", label=h6("Cecha 1"), choices=list(
                   "Rok produkcji"="Rok", "Fabuła"="Fabula", 
                   "Gatunek filmu"="Gatunki", "Scenarzyści"="Scenarzysci", 
                   "Reżyserowie"="Rezyserowie",
                   "Kraje produkcji"= "Kraje produkcji", "Obsada główna"="Aktorzy",
                   "Występujące gwiazdy"="Gwiazdy", "Producenci"="Producenci",
                   "Oceny flmu"="Oceny"),
                   selected="Rok"),
                 selectInput("cecha2", label=h6("Cecha 2"), choices=list(
                   "Rok produkcji"="Rok", "Fabuła"="Fabula", 
                   "Gatunek filmu"="Gatunki", "Scenarzyści"="Scenarzysci", 
                   "Reżyserowie"="Rezyserowie",
                   "Kraje produkcji"= "Kraje produkcji", "Obsada główna"="Aktorzy",
                   "Występujące gwiazdy"="Gwiazdy", "Producenci"="Producenci",
                   "Oceny flmu"="Oceny"),
                   selected="Rok"),
                 radioButtons("plec", label=h4("Twoja płeć"), 
                              choices=list("Kobieta"="K", "Mężczyzna"="M"), selected="K"),
                 numericInput("wiek", label=h4("Ile masz lat?"), value=18),
                 actionButton("zatwierdz", "Wyszukaj")
    )
  )
))
