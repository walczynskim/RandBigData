library("shiny")
library("RSQLite")
library("WyszynskaRudasIMDB")

sciezkaDoBazy <- "PelnaBazaFilmow_zap.sql"

shinyServer(function(input, output) {
  
  #ERROR w przypadku błędnych danych
  output$error <- renderText({
    #Uzależniam tylko od przycisku
    input$zatwierdz
    
    isolate({
    #Łączę się z bazą by zobaczyć czy mam taki film
    polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
    film <- dbGetQuery(polaczenie, paste0(
      "SELECT IDFilm, TytulPolski FROM Filmy WHERE TytulPolski='", input$tytul,"'"))
    dbDisconnect(polaczenie)

    if(nrow(film)==0){return("Przykro nam - takiego filmu nie ma w bazie...")}
    if(input$cecha1==input$cecha2){
      return("Wybierz dwie różne cechy!")}
    if(input$wiek<=0 | input$wiek>=120){
      return("Podałeś nieprawidłowy wiek!")
    } else{return("")}
    })
  })
  
  output$error2 <- renderText({
    #Uzależniam tylko od przycisku
    input$zatwierdz
    
    isolate({
      #Łączę się z bazą by zobaczyć czy mam taki film
      polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
      film <- dbGetQuery(polaczenie, paste0(
        "SELECT IDFilm, TytulPolski FROM Filmy WHERE TytulPolski='", input$tytul,"'"))
      dbDisconnect(polaczenie)
      
      if(nrow(film)==0){return("Przykro nam - takiego filmu nie ma w bazie...")}
      if(input$cecha1==input$cecha2){
        return("Wybierz dwie różne cechy!")}
      if(input$wiek<=0 | input$wiek>=120){
        return("Podałeś nieprawidłowy wiek!")
      } else{return("")}
    })
  })
  
  #Mapa filmów
  output$wykres <- renderPlot({
    #Uzależniam tylko od przycisku
    input$zatwierdz
    
    isolate({
    #Łączę się z bazą, żeby wyszukać film
    polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
    film <- dbGetQuery(polaczenie, paste0(
      "SELECT IDFilm, TytulPolski FROM Filmy WHERE TytulPolski='", input$tytul,"'"))
    dbDisconnect(polaczenie)
    
    if(input$cecha1==input$cecha2 | input$wiek<=0 | input$wiek>=120 | nrow(film)==0){
      #Jeśli coś jest źle wprowadzone zwracam pusty wykres
      t <- seq(-pi, pi, by=0.01)
      return(plot(t, sin(t), type="l", axes=FALSE, col="white", xlab="", ylab=""))
    } else {
      #Jeśli wszystko jest dobrze zwracam poprawny wykres
      
      #Obliczam wektor wspołczynników
      wektorWspolczynnikow <- WektorWspolczynnikow(c(input$cecha1, input$cecha2),
                                                   input$plec, input$wiek)
      polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
      poz<-1
      if(nrow(film)>1)
      {
         for(i in 1:nrow(film))
         {
            
            if(nrow(dbGetQuery(polaczenie,paste0("SELECT IDFilm1 FROM Odleglosci where IDFilm1=",film[i,1])))!=0|
               nrow(dbGetQuery(polaczenie,paste0("SELECT IDFilm2 FROM Odleglosci where IDFilm2=",film[i,1])))!=0)
            {
               poz<-i
               break
            }
            
         }
      }
      dbDisconnect(polaczenie)
      #Macierz odległości
      macierz <- StworzMacierzOdleglosci(film[poz,1], wektorWspolczynnikow, sciezkaDoBazy)

      #I rysuję mapę
      return(RysujMape(macierz))
    }
    })
  })
  
  #HeatMapa
  output$wykres2 <- renderPlot({
    #Uzależniam tylko od przycisku
    input$zatwierdz
    
    isolate({
      #Łączę się z bazą, żeby wyszukać film
      polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
      film <- dbGetQuery(polaczenie, paste0(
        "SELECT IDFilm, TytulPolski FROM Filmy WHERE TytulPolski='", input$tytul,"'"))
      dbDisconnect(polaczenie)
      
      if(input$cecha1==input$cecha2 | input$wiek<=0 | input$wiek>=120 | nrow(film)==0){
        #Jeśli coś jest źle wprowadzone zwracam pusty wykres
        t <- seq(-pi, pi, by=0.01)
        return(plot(t, sin(t), type="l", axes=FALSE, col="white", xlab="", ylab=""))
      } else {
        #Jeśli wszystko jest dobrze zwracam poprawny wykres
        
        #Obliczam wektor wspołczynników
        wektorWspolczynnikow <- WektorWspolczynnikow(c(input$cecha1, input$cecha2),
                                                     input$plec, input$wiek)
        polaczenie <- dbConnect(SQLite(), sciezkaDoBazy)
        poz<-1
        if(nrow(film)>1)
        {
           for(i in 1:nrow(film))
           {
              
              if(nrow(dbGetQuery(polaczenie,paste0("SELECT IDFilm1 FROM Odleglosci where IDFilm1=",film[i,1])))!=0|
                 nrow(dbGetQuery(polaczenie,paste0("SELECT IDFilm2 FROM Odleglosci where IDFilm2=",film[i,1])))!=0)
              {
                 poz<-i
                 break
              }
              
           }
        }
        dbDisconnect(polaczenie)
        #Macierz odległości
        macierz <- StworzMacierzOdleglosci(film[poz,1], wektorWspolczynnikow, sciezkaDoBazy)
        #I rysuję mapę
        return(RysujHeatMape(macierz))
      }
    })
  })
})