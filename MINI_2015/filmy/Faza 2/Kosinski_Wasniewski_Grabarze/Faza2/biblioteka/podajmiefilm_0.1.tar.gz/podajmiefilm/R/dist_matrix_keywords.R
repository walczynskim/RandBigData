#' Creating distance matrix
#'
#'
#' Function \code{dist_matrix_yrglc} creates dist matrix from data frame containing keywords.
#'
#'
#' @param movies data frame with movies' data gotten from movie_info function.
#'
#' @examples
#' dist_matrix_keywords(dataFrame)
#'
#' @import tm
#' @import Matrix
#' @import irlba
#'
#' @author Marcin Kosinski, Mikolaj wasniewski Pawel Grabowski




dist_matrix_keywords <- function(movies) {
  # stworzenie macierzy wystapien aktorow, rezyserow albo scenarzystow dla tytulow
  strsplit_comma_tokenizer <- function(x)
    unlist(strsplit(as.character(x), ",[ ]"))

  keywordsCorpus <- Corpus(VectorSource(movies$keywords))

  keywordsDTM <- DocumentTermMatrix(keywordsCorpus,
                                    control = list(tokenize=strsplit_comma_tokenizer))

  # przejscie z DTM na macierz rzadka (sparseMatrix), dzieki czemu
  # na tym obiekcie mozna w ogole cos policzyc

  keywordsSparse <- sparseMatrix(i = keywordsDTM$i, j = keywordsDTM$j,
                                 x = keywordsDTM$v, dimnames = keywordsDTM$dimnames)

  # specjalna funkcja do liczena sum w kolumnach na macierzy rzadkiej
  keywordsColSums <- colSums(keywordsSparse)
  # > summary(keywordsColSums)
  # Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
  # 1.00    1.00    2.00   11.47    5.00 2583.00


  # > dim(keywordsSparse)
  # [1]  9334 67682

  # wyrzucamy slowa kluczowe, ktore nie pojawily sie w co najmniej 5 filmach
  keywordsSparseSmart <- keywordsSparse[,which(keywordsColSums > 5)]

  # > dim(keywordsSparseSmart)
  # [1]  9334 16049

  ###################################################################
  ###################################################################
  ## Dla tak `malowymiarowej macierzy` moze juz nie jest potrzebne SVD?
  ###################################################################
  ###################################################################

  # dopasowuje czesciowy rozklad SVD dzieki algorytmowi irlba:
  # "Augmented Implicitly Restarted Lanczos Bidiagonalization Methods", J. Baglama and L. Reichel, SIAM J. Sci. Comput. 2005.
  # . It is a fast and memory-efficient way to compute a partial SVD.


  keywordsSVD <- irlba( keywordsSparseSmart, nu = 1000, nv = 1000)

  # po rozkladzie biore pierwsze 1000 wektorow
  keywordsU <- keywordsSVD$u


  # dopasowuje macierz odleglosci do obiektu rzedu 9,3 tys x 1 tys
  # czas obliczen: okolo poltorej godziny
  keywordsDist <- dist( keywordsU )
}

