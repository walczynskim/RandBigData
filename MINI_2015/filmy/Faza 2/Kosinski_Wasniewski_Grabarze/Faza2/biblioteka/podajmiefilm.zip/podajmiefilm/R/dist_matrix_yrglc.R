#' Creating distance matrix
#'
#'
#' Function \code{dist_matrix_yrglc} creates dist matrix from data frame containing only
#' year, rating, genre, country, language parametres.
#'
#'
#' @param movies data frame with movies' data gotten from movie_info function.
#'
#' @examples
#' dist_matrix_yrglc(dataFrame)
#'
#' @import tm
#' @import Matrix
#'
#' @author Marcin Kosinski, Mikolaj wasniewski Pawel Grabowski



dist_matrix_yrglc <- function(movies) {
  # stworzenie macierzy wystapien aktorow, rezyserow albo scenarzystow dla tytulow
  strsplit_comma_tokenizer <- function(x)
    unlist(strsplit(as.character(x), ",[ ]"))

  genreCorpus <- Corpus(DataframeSource(movies[,c("genre","country", "language")]))

  genreDTM <- DocumentTermMatrix(genreCorpus,
                                 control = list(tokenize=strsplit_comma_tokenizer))

  # przejscie z DTM na macierz rzadka (sparseMatrix), dzieki czemu
  # na tym obiekcie mozna w ogole cos policzyc

  genreSparse <- sparseMatrix(i = genreDTM$i, j = genreDTM$j,
                              x = genreDTM$v, dimnames = genreDTM$dimnames)

  cbind( movies[, c("rating","year")], as.matrix(genreSparse)) -> moviesInfo
  # > dim(moviesInfo)
  # [1] 9334  287


  moviesInfoDist <- dist(moviesInfo)
}
