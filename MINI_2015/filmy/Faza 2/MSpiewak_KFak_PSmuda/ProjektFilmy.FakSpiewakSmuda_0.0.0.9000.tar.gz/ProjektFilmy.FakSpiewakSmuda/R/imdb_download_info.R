#' Pobieranie informacji o filmach z bazy IMDb wersja 2.
#'
#' Funkcja \code{imdb_download_info } pobiera wszystkie dane o filmach z podanych lat i zapisuje do
#' ramki danych w folderze ~/dane/glowne/rok.csv.
#'
#' @aliases imdb_download_info(from,min,max)
#' 
#' @param from filmy z roku...
#' @param min minimalna liczba linijek do pobrania
#' @param maksymalna liczba linijek do pobrania
#' 
#' @return zapis do pliku(ow) w folderze ~/dane/glowne/rok.csv dane filmow z podanych lat.
#' @import stringi
#' @export


imdb_download_info <- function(from,min,max){
  stopifnot(min<=max)
  
  if (!file.exists(file.path("dane"))) {
    dir.create(file.path("dane"))
  }
  if (!file.exists(file.path("dane/glowne"))) {
    dir.create(file.path("dane/glowne"))
  }
  path <- file.path(getwd(), "movies_link",paste0(from,".csv"))      
  if (length(path) == 0) cat("\nNie wybrałeś  plików do ściągnięcia!\n") 
  tableName <- paste0("dane/glowne/",from,".csv")
  linki <- read.table(path, header = TRUE)$link
  if(length(linki) < max) max <- liczba_linkow
  if(length(linki) < min) stop("Nie ma tylu linkow")
  if(!file.exists(tableName))
    write.table(t(c("id", "title", "year", "duration", "genres",
                    "rating", "votes", "DirectedBy", "Cast", "Writing",
                    "ProducedBy","MusicBy", "CinematographyBy",
                    "production_countries", "language", "color", "keywords")),
                file = tableName,
                row.names = FALSE, col.names = FALSE, sep = ";")
  con <- file(tableName)
  open(con, "a+")
  for(i in min:max){
    link <- as.character(linki[i])
    cat(i,": ", link,"\n")
    id <- stri_extract_last_regex(link[i], "(?<=/title/).+")
    a <- from_main_page(link)
    b <- from_full_cast_n_crew(link)
    c <- from_page_source(link)
    d <- keywords(link)
    suppressWarnings(write.table(
      as.data.frame(c(id, a, b, c, d)),
      file = tableName,
      append = TRUE, sep = ";",
      row.names = FALSE, col.names = FALSE))
  }
  close(con)
  cat("\nDone\n")
}