#' Wyj?tkowa srednia arytmetyczna macierzy podobienstwa
#'
#' Funkcja \code{movies_Dist} wyznacza srednia arytmetyczna macierzy, w ten sposob, 
#' ze jesli dodajemy do siebie n macierzy oraz na k z nich na (i,j) miejscu stoi NA, wowczas
#' srednia arytmetyczna liczymy nastepujaco: \n
#' (A_1(i,j)+...+A_{n-k}(i,j))/(n-k)
#' 
#' @usage movies_Dist(matricesList)
#' @param matricesList lista macierzy
#'
#' @return
#' wyjatkowa srednia arytmetyczna macierzy podobienstwa
#' 
#' @export


movies_Dist <- function(matricesList){
  z <- length(matricesList)
  n <- dim(matricesList[[1]])[1]
  X <- array(unlist(matricesList), dim=c(n,n,z))
  distMatrix <- apply(X,c(1,2),function(x) mean(x, na.rm=TRUE))
  return(distMatrix)
}


