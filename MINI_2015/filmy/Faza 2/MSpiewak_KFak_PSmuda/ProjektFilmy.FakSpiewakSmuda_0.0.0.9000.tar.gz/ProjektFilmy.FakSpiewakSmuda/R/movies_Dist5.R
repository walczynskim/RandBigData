#' Funkcja liczaca wartosc podobienstwa
#'
#' Funkcja \code{movies_Dist5} liczy wartosc podobienstwa miedzy dwom danymi filmami
#' wzgledem podanej charakterystyki
#' 
#' @usage movies_Dist5(x,y)
#' @param x, y - wartosci charakterystyki dla dwoch dowolnych filmow
#' 
#' @details funkcja jest przeznaczona dla takich charakterystyk jak:
#' Year
#' 
#' @return
#' wartosc podobienstwa
#'
#' @export

movies_Dist5 <- function(x,y){
  p <- (5-abs(as.numeric(x)-as.numeric(y)))/5
  return(p)
}
