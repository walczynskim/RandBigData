#' Funkcja liczaca wartosc podobienstwa
#'
#' Funkcja \code{movies_Dist10} liczy wartosc podobienstwa miedzy dwom danymi filmami
#' wzgledem podanej charakterystyki
#' 
#' @usage movies_Dist10(x,y)
#' @param x, y - wartosci charakterystyki dla dwoch dowolnych filmow
#' 
#' @details funkcja jest przeznaczona dla takich charakterystyk jak:
#' Overall_Rating, Males, Females, Aged_under_18, Males_under_18, 
#' Females_under_18, Aged_18.29, Males_Aged_18.29, Females_Aged_18.29, 
#' Aged_30.44, Males_Aged_30.44, Females_Aged_30.44, Aged_45., Males_Aged_45., 
#' Females_Aged_45., IMDb_staff;
#'
#' @return
#' wartosc podobienstwa
#'
#' @export

movies_Dist10 <- function(x,y){
  p <- (10-abs(as.numeric(x)-as.numeric(y)))/10
  return(p)
}