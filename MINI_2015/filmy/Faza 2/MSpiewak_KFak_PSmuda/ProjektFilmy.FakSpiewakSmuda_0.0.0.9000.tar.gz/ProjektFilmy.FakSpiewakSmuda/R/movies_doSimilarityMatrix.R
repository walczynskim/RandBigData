#' Macierz podobienstwa
#'
#' Funkcja \code{movies_doSimilarityMatrix} liczy macierz podobienstwa ze wzgledu na dana 
#' charakterystyke
#' 
#' @usage movies_doSimilarityMatrix(po_czym, n, FUN)
#' @param po_czym  nazwa charakterystyki dla ktorej mamy liczyc macierz podobienstwa 
#' @param n  liczba filmow, dla ktorych ma byc utworzona macierz, 
#' liczymy od filmu najpozniej wyprodukowanego do filmu najwczesniej wyprodukowane 
#' @param FUN funkcja, odpowiadajaca sposobie liczenia danej charakterystyki
#' @param freeCl liczba klastr?w nie bior?cych udzialu w procesie liczenia macierzy podobienstwa
#'
#' @return
#' macierz podobienstwa
#' 
#' @details
#' Odpowiedni funkcje dla charakterystyk:
#' 'moviesIntersect' - Title, Genres, DirectedBy, Writing, ProducedBy, MusicBy, 
#' CinematographyBy, Production_countries, Language, Color, Keywords;
#' 
#' 'moviesWeightedIntersect' - Cast;
#' 
#' 'moviesDist5` - Year;
#' 
#' `moviesDist10` - Overall_Rating, Males, Females, Aged_under_18, 
#' Males_under_18, Females_under_18, Aged_18.29, Males_Aged_18.29, 
#' Females_Aged_18.29, Aged_30.44, Males_Aged_30.44, Females_Aged_30.44, 
#' Aged_45., Males_Aged_45., Females_Aged_45., IMDb_staff.
#'
#'@import
#' stringi
#' parallel
#' @export


movies_doSimilarityMatrix <- function(po_czym, n, FUN, freeCl=0){
  slowaRozdzielone <- movies_ExtractWords(po_czym)
  slowaRozdzielone <- tail(slowaRozdzielone,n)
  start.time <- Sys.time()
  ile <- detectCores()
  cl <- makeCluster(ile-freeCl)
  clusterExport(cl, c("slowaRozdzielone","FUN"), envir=environment())
  X <- parSapply(cl, slowaRozdzielone, function(x){
    sapply(slowaRozdzielone, function(y){
      if(all(is.na(x),is.na(y))==FALSE)
        FUN(x,y) else
          NA
    })
  })
  stopCluster(cl)
  stop.time <- Sys.time()
  
  rownames(X) <- colnames(X) <- 1:n
  assign(po_czym,X)
  save(list=po_czym, file=paste0(po_czym,".rda"))
  return(stop.time-start.time)
}