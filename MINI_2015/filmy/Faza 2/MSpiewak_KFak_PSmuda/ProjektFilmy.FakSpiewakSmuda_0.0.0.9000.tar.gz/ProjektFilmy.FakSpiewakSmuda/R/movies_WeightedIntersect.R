#' Funkcja liczaca wartosc podobienstwa
#'
#' Funkcja \code{movies_WeightedIntersect} liczy wartosc podobienstwa miedzy dwom danymi filmami
#' wzgledem podanej charakterystyki
#' 
#' @usage movies_WeightedIntersect(x,y)
#' @param x, y - wartosci charakterystyki dla dwoch dowolnych filmow
#' 
#' @details funkcja jest przeznaczona dla takich charakterystyk jak:
#' Cast
#'
#' @return
#' wartosc podobienstwa
#'
#' @export

movies_WeightedIntersect <- function(x,y){
  if("na"%in%x) x <- x[-which(x%in%"na")] 
  if("na"%in%y) y <- y[-which(y%in%"na")]
  head=2; weightUp=8/10; weightDown=2/10
  czolowka <- weightUp*length(intersect(x[1:head],y[1:head]))/length(union(x[1:head],y[1:head]))
  reszta <- weightDown*length(intersect(x[-c(1:head)],y[-c(1:head)]))/length(union(x[-c(1:head)],y[-c(1:head)]))
  return(czolowka+reszta)
}