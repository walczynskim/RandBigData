#' Funkcja liczaca wartosc podobienstwa
#'
#' Funkcja \code{movies_Intersect} liczy wartosc podobienstwa miedzy dwom danymi filmami
#' wzgledem podanej charakterystyki
#' 
#' @usage movies_Intersect(x,y)
#' @param x, y - wartosci charakterystyki dla dwoch dowolnych filmow
#' 
#' @details funkcja jest przeznaczona dla takich charakterystyk jak:
#' Title, Genres, DirectedBy, Writing, ProducedBy, MusicBy, CinematographyBy, 
#' Production_countries, Language, Color, Keywords;
#'
#' @return
#' wartosc podobienstwa
#'
#' @export

movies_Intersect <- function(x,y){
  p <- length(intersect(x,y))/length(union(x,y))
  return(p)
}