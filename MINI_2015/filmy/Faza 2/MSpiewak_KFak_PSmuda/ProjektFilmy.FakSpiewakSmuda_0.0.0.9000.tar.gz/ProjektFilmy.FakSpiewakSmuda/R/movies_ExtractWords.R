#' Funkcja pomocnicza
#'
#' Funkcja \code{movies_ExtractWords} ma celu rozdzielenie slow oddzielonych przecinkami
#' 
#' @usage movies_ExtractWords(po_czym)
#' @param po_czym - nazwa charakterystyki dotyczacej filmow dla ktorej ma byc dokonane 
#' rozbicie slow
#'
#' @return
#' funkcja zwraca wektor rozdzielonych slow
#'
#'@import
#' stringi
#' 
#' @export

movies_ExtractWords <- function(po_czym){
  sapply(movies10IMDB[,po_czym], function(x){
    x <- as.character(x)
    tolower(
      ifelse(po_czym=='Title',
             stri_extract_all_words(x),
             strsplit(x,","))[[1]])
  })
}