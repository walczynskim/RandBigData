#' Oblicz macierz podobieństwa między filmami
#'
#' Funkcja \code{dist_procent}
#'
#' @param x wektor liczbowy odpowiadajacy za pewna ilosciowa charakterystyke filmow
#' @param wybrane wektor liczbowy okreslajacy numer wierszy dla filmow, dla ktorych szukamy podobne filmy
#' @param imputacja jednoelementowy wektor logiczny okreslajacy, czy wartosci NA w kazdej kolumnie zostawiamy niezmienione (FALSE), czy uzupelniamy je srednia ze wszystkich okreslonych wartosci w kolumnie (TRUE)
#'
#' @return funkcja \code{dist_procent} zwraca macierz liczbowa
#' @import stringi
#'


dist_procent <- function(x, wybrane = 1:5, imputacja = TRUE){
   w1 <- which(is.na(x))
   w2 <- which(is.na(x[wybrane]))
   n <- length(x)
   macierz <- matrix(rep(0, length(wybrane)*n), nrow = n, ncol = length(wybrane))
   i <- j <- 2
   for(i in 1:n){
      for(j in 1:length(wybrane)){
         t1 <- stri_trans_tolower(stri_extract_all_words(x[i])[[1]])
         t2 <- stri_trans_tolower(stri_extract_all_words(x[wybrane[j]])[[1]])
         if(is.na(t1) || is.na(t2)){
            macierz[i,j] <- NA
         }
         else{
            macierz[i,j] <- 1-length(intersect(t1, t2))/length(union(t1, t2))
         }
      }
   }
   if(imputacja){
      srednia <- mean(macierz, na.rm = T)
      macierz[is.na(macierz)] <- srednia
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
   else{
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
}












