#' Oblicz macierz podobieństwa między filmami
#'
#' Funkcja \code{podobne_filmy} dla wybranych filmow zwraca tytuły (uproszczone) filmow najbardziej podobnych
#'
#' @param dane
#' @param wybrane wektor liczbowy okreslajacy numer wierszy dla filmow, dla ktorych szukamy podobne filmy
#' @param ile
#' @param wagi
#'
#' @return funkcja \code{podobne_filmy} zwraca macierz liczbowa



podobne_filmy <- function(dane2, wybrane = 1:5, ile = 3, wagi = c(czas = 1, ocena = 1, widocznosc = 1, geo = 1, naj = 1)){
   dist <- dist_end(dane = dane2, wybrane = wybrane, wagi = wagi)
   dist[which(dist == 0)] <- 1
   dist_ile <- apply(dist, MARGIN = 2, function(x){sort.int(x, partial = ile)[ile]})

   wynik <- matrix(rep("", length(wybrane)*ile), nrow = ile, ncol = length(wybrane))
   colnames(wynik) <- colnames(dist)

   for(i in 1:length(wybrane)){
      wynik[,i] <- rownames(dist)[which(dist[,i] <= dist_ile[i])]
   }
   return(wynik)
}


# podobne_filmy(dane = dane[1:5000,], wybrane = 1:20, ile = 10)


