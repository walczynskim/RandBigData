#' Oblicz macierz podobieństwa między filmami
#'
#' Funkcja \code{dist_lin}
#'
#' @param x wektor numeryczny odpowiadajacy za pewna ilosciowa charakterystyke filmow
#' @param wybrane wektor numeryczny okreslajacy numer wierszy dla filmow, dla ktorych szukamy podobne filmy
#' @param ogr najwieksza liczba calkowita, ktora jest wbudowana w pakiecie R
#' @param imputacja jednoelementowy wektor logiczny okreslajacy, czy wartosci NA w kazdej kolumnie zostawiamy niezmienione (FALSE), czy uzupelniamy je srednia ze wszystkich okreslonych wartosci w kolumnie (TRUE)
#'
#' @return funkcja \code{dist_lin} zwraca macierz liczbowa



dist_lin <- function(x, wybrane = 1:5, ogr = .Machine$integer.max, imputacja = TRUE){
   w1 <- which(is.na(x))
   w2 <- which(is.na(x[wybrane]))
   max <- max(x, na.rm = T)
   min <- min(x, na.rm = T)
   macierz <- outer(x, x[wybrane], function(t1, t2){
      ifelse(abs(t1-t2) <= ogr, abs(t1-t2)/(max-min), 1)
   })
   if(imputacja){
      srednia <- mean(macierz, na.rm = T)
      macierz[is.na(macierz)] <- srednia
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
   else{
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
}


