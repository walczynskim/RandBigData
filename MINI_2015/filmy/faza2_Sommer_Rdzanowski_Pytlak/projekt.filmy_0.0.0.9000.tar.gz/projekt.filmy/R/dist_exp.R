#' Oblicz macierz podobieństwa między filmami
#'
#' Funkcja \code{dist_exp}
#'
#' @param x wektor liczbowy odpowiadajacy za pewna ilosciowa charakterystyke filmow
#' @param wybrane wektor liczbowy okreslajacy numer wierszy dla filmow, dla ktorych szukamy podobne filmy
#' @param a wektor liczbowy jednoelementowy
#' @param imputacja jednoelementowy wektor logiczny okreslajacy, czy wartosci NA w kazdej kolumnie zostawiamy niezmienione (FALSE), czy uzupelniamy je srednia ze wszystkich okreslonych wartosci w kolumnie (TRUE)
#'
#' @return funkcja \code{dist_exp} zwraca macierz liczbowa


dist_exp <- function(x, wybrane = 1:5, a, imputacja = TRUE){
   w1 <- which(is.na(x))
   w2 <- which(is.na(x[wybrane]))
   max <- max(x, na.rm = T)
   min <- min(x, na.rm = T)
   macierz <- outer(x, x[wybrane], function(t1, t2){ (exp(a*abs(t1-t2)/(max-min))-1)/(exp(a)-1) })
   if(imputacja){
      srednia <- mean(macierz, na.rm = T)
      macierz[is.na(macierz)] <- srednia
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
   else{
      for(i in 1:length(w1)){
         macierz[w1[i], w2[i]] <- 0
      }
      return(macierz)
   }
}

