#' Zilustruj podobne filmy.
#'
#' Funkcja \code{skalowanie_wielowymiarowe} zwraca wykres ilustrujacy najbardziej podobne filmy do wybranych przez nas.
#'
#' @param macierz Macierz, w ktorej wierszami sa wszystkie filmy z bazy, a kolumnami filmy wybrane przez uzytkownika.
#'
#' @return Funkcja \code{skalowanie_wielowymiarowe} zwraca wykres.
#' @import ggplot2
#' @import MASS

skalowanie_wielowymiarowe <- function(macierz){

  odleglosc <- dist(macierz)
  skalowanie <- isoMDS(odleglosc)

  punkty <- skalowanie$points[which(rownames(macierz) %in% colnames(macierz)),]
  srednia <- apply(punkty, 2, mean)

  odl <- as.matrix(dist(rbind(skalowanie$points, srednia)))
  skalowanie <- isoMDS(odl)
  z <- which(rownames(odl) %in% names(sort(odl[nrow(odl),])[2:(11+ncol(macierz))]))

  zzz <- data.frame(rbind(skalowanie$points[z,], srednia))
  zzz$tytul <- c(rownames(skalowanie$points[z,]), "")
  ktore <- which(zzz$tytul %in% colnames(macierz))
  zzz$color <- c(rep("black", length(z)), "yellow")
  zzz$color[ktore] <- "red"
  zzz$v <- rep_len(c(-1, 1), length(z)+1)

  ggplot(zzz, aes(x=X1, y=X2, fill=color, label=tytul))+
    geom_point(size=15, shape=21, color="black", alpha=0.5)+
    geom_text(aes(color=color, vjust=v), angle=45)+
    theme_bw() +
    theme(legend.position="none",
          axis.text = element_blank(),
          axis.ticks = element_blank()) +
    xlab(NULL) +
    ylab(NULL)

}

# b <- fread("C:\\Users\\Marta\\Desktop\\filmy_dane\\wszystko_o_filmach.txt")
# bb <- data.frame(b)
# bbb <- bb[1:40, c(2, 10, 11, 12, 14)]
# d <- dist(bbb)
#
# # wejsciowe:
# macierz <- as.matrix(d)[,c(6,7, 11)]
# nazwy <- bb[1:40,1]
# rownames(macierz) <- nazwy
# colnames(macierz) <- nazwy[c(6,7, 11)]
# macierz
#
# skalowanie_wielowymiarowe(macierz)














