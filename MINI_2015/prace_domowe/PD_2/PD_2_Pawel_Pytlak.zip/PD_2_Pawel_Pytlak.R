## Analiza tweetów dotyczących 85. Międzynarodowego Salonu Samochodowego w 
## Genewie

library(twitteR)
library(stringi)
library(tm)
library(wordcloud)
library(rvest)
library(ggplot2)

# dokonuję autoryzacji
consumerKey <- "mruTEgk5DpvU0XM8dk3aPRhVx"
consumerSecret <- "B2NOHpA7uVrap95LOwTssStx8HfWUgSDbtTo0OJhQrXQEmi1oT"
access_token <- "51761035-QqJMM7EYxwwV5QnGAelnEq6HVg6RQrUYOFMyw9pho"
access_secret <- "FteRrg5TjcjyW37qMfLBeXaDsFeYQ7AUFgWFmHS1cJqO5"

setup_twitter_oauth(consumerKey, consumerSecret, access_token, 
                    access_secret)

# pobieram tweety z odpowiednim słowem kluczowym
gims <- searchTwitter("#GIMS", n = 3264, lang = "en", 
                      since = "2015-03-05", until = "2015-03-17")

# przekształcam pobrane dane na ramkę danych i wyciągam samą treść
df_gims <- twListToDF(gims)
tweety <- df_gims$text

# usuwam z treści tweetów adresy URL, znaki interpunkcyjne oraz zamieniam 
# wielkie litery na małe
usun_adresy <- stri_replace_all_regex(tweety, "http(s?)\\S*", "")
corpus <- Corpus(VectorSource(usun_adresy))
male_litery <- tm_map(corpus, content_transformer(tolower))
bez_interpunkcji <- tm_map(male_litery, removePunctuation)

# usuwam słowa pomijane i inne, niemające znaczenia w kontekście 
# prowadzonej przeze mnie analizy
xpo6 <- html("http://xpo6.com/list-of-english-stop-words/")
slowa <- html_nodes(xpo6, "code:nth-child(2)")
slowa_txt <- html_text(slowa)
wydziel <- unlist(stri_extract_words(slowa_txt))

wyrzuc_slowa <- c(wydziel, stopwords("english"), "rt", "gims", 
                  "gvamotorshow", "geneva", "genevamotorshow", 
                  "geneva motor show", "geneva2015", "salonautogeneve", 
                  "genevemotorshow", "motor show", "show", "car", "cars", 
                  "2015", "youtube", "r", "s") 
bez_slow <- tm_map(bez_interpunkcji, removeWords, wyrzuc_slowa)

# na końcu usuwam białe znaki
bez_spacji <- tm_map(bez_slow, stripWhitespace)

# wykrywam słowa o największej częstotliwości występowania i tworzę na ich
# postawie chmurę słów
dtm <- DocumentTermMatrix(bez_spacji)
findFreqTerms(dtm, lowfreq = 200)
wordcloud(bez_spacji, min.freq = 250)

# wydobywam dokładne liczności 20 najczęściej występujących słów
tekst <- unlist(sapply(bez_spacji, `[`, "content"))
czestotliwosc <- table(unlist(stri_extract_words(tekst)))
posortowane <- sort(czestotliwosc, decreasing = TRUE)
najczestsze <- head(posortowane, 20)


nazwy <- unlist(dimnames(najczestsze))
wartosci <- as.numeric(najczestsze)
ramka <- data.frame(slowo = nazwy, licznosc = wartosci)

# tworzę wykres słupkowy 20 najczęstszych słów
ggplot(ramka, aes(x = slowo, y = licznosc)) + geom_bar(stat = "identity") + 
   xlab("Slowa") + ylab("Licznosci") + coord_flip()








