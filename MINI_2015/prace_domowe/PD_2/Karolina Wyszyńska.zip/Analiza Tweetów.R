############################################################################
###############   ANALIZA OBRAZU POLSKI NA TWEETERZE   #####################
############################################################################

#Biblioteki
library(streamR)
library(ROAuth)
library(stringi)
#Folder roboczy
path<-"D://Projekty/polska/"

#Dane potrzebne do zalogowania
requestURL <- "XXXXXXXX"
accessURL <- "XXXXXXXXX"
authURL <- "XXXXXXXX"
consumerKey <- "XXXXXXXX"
consumerSecret <- "XXXXXXXX"
oauthKey <- "XXXXXXX"
oauthSecret <- "XXXXXXXX"

#Proces autoryzacji
paczka <- OAuthFactory$new(consumerKey = consumerKey, consumerSecret = consumerSecret,
    oauthKey = oauthKey, oauthSecret = oauthSecret,
    requestURL = requestURL, accessURL = accessURL, authURL = authURL)
paczka$handshake(cainfo = system.file("CurlSSL", "cacert.pem", package = "RCurl"))

#Nasłuch o Polsce - nasłuchuję słów o Polsce po polsku, angielsku i hiszpańsku
name<-paste(path,"Tweet",stri_replace_all_fixed(
   as.character(Sys.time()),":","-"),".json",collapse="",sep="")
file.create(name)
filterStream( file=name,
              track=c("Poland","polish","pole",
                 "Polska","polski","polak","polka",
                 "polaco","Polonia","polaca"),
              timeout=60*60)

#Zczytuję wszystkie pliki, które udało mi się wcześniej zapisać
Pliki<-list.files(path)
Tweety<-NULL
klucz<-stri_paste(c("Poland","polish","pole",
                 "Polska","polski","polak","polka",
                 "polaco","Polonia","polaca"),collapse="|")

for(i in seq_along(Pliki)){
   #Wczytuję Tweety
   parsedTweets <- parseTweets(stri_paste(path,Pliki[i],collapse="",sep=""),
    simplify = FALSE, verbose = TRUE)
   #Wybieram te, które faktycznie mnie interesują(część była sciągniętych
   #przy ustawionym location na cały świat)
   dobre_tweety<-unlist(stri_match_all_regex(parsedTweets[,"text"],klucz))
   parsedTweets<-parsedTweets[which(!is.na(dobre_tweety)),]
   dobre_tweety<-NULL #Czyszczę pamięć
   if(is.null(Tweety)){Tweety<-parsedTweets}else{
      Tweety<-rbind(Tweety,parsedTweets)}
}

#Wyjmuję do analizy sam tekst
TweetyTekst<-Tweety[,"text"]
#Usuwam puste tweety
TweetyTekst<-TweetyTekst[which(!is.na(TweetyTekst))]
#I sklejam je wszystkie razem
Tekst<-stri_paste(TweetyTekst,collapse=" ",sep=" ")
#Robie prostą obrobkę tekstu
Tekst<-stri_replace_all_regex(Tekst,"[\n\t\\:\\\\/_0-9]"," ")
Tekst<-stri_replace_all_regex(Tekst,"[.,\\(\\)@]|[ ]|[-]"," ")
Tekst<-unlist(stri_extract_all_words(Tekst))
Tekst<-stri_trans_tolower(Tekst)

Podsumowanie<-table(Tekst)
Slowa<-names(Podsumowanie)
#Wczytuję słowniki ze stopWords
polski<-stri_encode(readLines(
   "D://Projekty/Analiza tweetów/stop-words_polish_2_pl.txt"),from="UTF-8",
   to="Windows-1250")
angielski<-stri_encode(readLines(
   "D://Projekty/Analiza tweetów/stop-words_english_2_en.txt"),from="UTF-8",
   to="Windows-1250")
hiszpanski<-stri_encode(readLines(
   "D://Projekty/Analiza tweetów/stop-words_spanish_2_es.txt"),from="UTF-8",
   to="Windows-1250")
Slowa<-setdiff(Slowa,polski)
Slowa<-setdiff(Slowa,angielski)
Slowa<-setdiff(Slowa,hiszpanski)
klucz<-c("poland","polish","pole",
                 "polska","polski","polak","polka",
                 "polaco","polonia","polaca")
Slowa<-setdiff(Slowa,c(klucz,"http","https","com","t","x"))
Podsumowanie<-sort(Podsumowanie[Slowa],decreasing=TRUE)
#30 najczesciej wystepujacych slow
Podsumowanie[1:30]
# Tekst
# rt        nail      follow      beauty        luke        full       james 
# 972         446         236         229         214         154         152 
# lt      please      brooks         amp      friend selserenade         can 
# 149         148         147         146         135         130         125 
# loves         dot         new       deals    yammouni      thanks        fans 
# 124         121         119         117         115         109         105 
# read        ebay        love       proud      making       coach     analyst 
# 102         100          99          93          92          90          89 
# extremely      happen 
# 89          89 

#Widac, ze wiekszosc najczesciej uzywanych slow nie ma zabarwienia 
#ani pozytywnego - jak np. 'james'. Natomiast liczba slow pozytywnych 
#takich jak 'love' i 'beauty' przewaza nad negatywnymi. 
#Stad mozna przupyszczac ze obraz Polski i polaków w zebraych tweetach 
#jest pozytywny :)
#Ponad to dosyc wysoko uplasowalo sie takze slowo 'analyst' :)




