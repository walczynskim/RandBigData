# ---
# title: "Friends"
# author: "Martyna Spiewak"
# ---
   
# Po 9 latach od ostatniego odcinku serialu jego legenda wciaz trwa. 
# Oficjalna strone serialu na portalu facebook.com polubilo ok. 20,4 mln 
# ludzi z calego swiata. W ciagu ostatniego miesiaca na stronie 
# pojawilo sie 10 postow, ktore sa ciagle udostepniane i komentowane.
# 
# Zobaczy kto cieszy sie wciaz najwieksza popularnoscia wsrod fanow.


require("Rfacebook")
require("stringi")
require("tm")
require("wordcloud")
load("fb_oauth")
#########################################
# posty opublikowane w ciagu ostatniego miesiaca
id.df<-getPage(page="22577904575", token=fb_oauth, 
               since = stri_replace_all_regex(as.character(Sys.Date()-30), "-", "/"),
               until = stri_replace_all_regex(as.character(Sys.Date()), "-", "/"), feed=FALSE)
#########################################
# komentarze opublikowane w ciagu ostatniego miesiaca 
id_comments<-data.frame()
for(x in id.df$id){
   GetPost<-getPost(x, token=fb_oauth, likes = FALSE)
   tmp_comments<-as.data.frame(GetPost[2])
   id_comments<-rbind(id_comments, data.frame(message=tmp_comments$comments.message, likes=tmp_comments$comments.likes_count, stringsAsFactors = FALSE))
}

tmp_e<-stri_extract_all_words(id_comments$message)
tmp_e<-sapply(tmp_e, stri_trans_tolower)
tmp<-unlist(tmp_e)
tmp<-tmp[!tmp%in%stopwords()]
top500<-sort(table(unlist(tmp)), decreasing = TRUE)[1:500]


top500[1:10]
pal <- brewer.pal(6,"Dark2")
pal <- pal[-(1)]
wordcloud(names(top500),top500,c(8,.3),2,,FALSE,TRUE,.15,pal)

# W TOP10 najczesciej wystepujacych sloW w komentarzach, 
# znajduja sie wszystkie imiona gloWnych bohaterow, oprocz serialowej Moniki... 


friends<-c("joey", "chandler", "ross", "rachel", "phoebe", "monica")
mean.friends<-sapply(friends, 
            function(y) mean(id_comments[sapply(tmp_e, function(x) any(x%in%y)),2]))

barplot(mean.friends, xlab="Friends", ylab="Srednia liczba lajkow", col="grey")

# ... ale to komentarze, w ktorych jest jej imie, 
# maja najwyzsza srednia z liczby uzyskanych polubien. Ciekawe.
