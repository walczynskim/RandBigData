#' Wczytuje dane z logów.
#'
#'
#'
#'
#' @export
#'

wczytaj.dane <- function(sciezka, baza) {

    time <- as.POSIXct(Sys.time())
    setwd(sciezka)

    pliki <- wczytaj.nazwy.plikow(sciezka)

    czytaj.logi(pliki, baza)

    print(as.POSIXct(Sys.time()) - time)
}
