

wczytaj.nazwy.plikow <- function(folder) {

    # wczytaj nazwy wszystkich plików
    pliki <- list.files(folder, recursive = TRUE)

    # wybierz pliki logów
    pliki <- grep(".+\\.log", pliki, value = TRUE)

    # wybierz pliki o nazwie postaci cnk[liczba].log
    pliki <- grep("cnk", pliki, value = TRUE, fixed = TRUE)

    pliki
}
