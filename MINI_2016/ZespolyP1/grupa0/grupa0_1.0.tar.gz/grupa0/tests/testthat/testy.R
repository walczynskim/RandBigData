library(testthat)
library(grupa0)


test_that("Test1",{
  expect_error(wykres_max_czas())
  expect_error(wordcloud_urz())
  expect_error(rozklad())
  expect_error(wykres_najdluzsza_eksponat())
})
