library(testthat)
library(grupa0)

test_check("grupa0")
