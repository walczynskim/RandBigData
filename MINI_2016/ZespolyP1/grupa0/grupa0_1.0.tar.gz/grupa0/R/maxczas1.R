#' Opis danych dla maxczas1
#' 
#' S� to dane zawieraj�ce nazwy eksponat�w przy kt�rych by� odwiedzaj�cy
#' w ka�dym dniu, w kt�rym by�o otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name maxczas1
#' @usage data(maxczas1)
#' 
NULL
