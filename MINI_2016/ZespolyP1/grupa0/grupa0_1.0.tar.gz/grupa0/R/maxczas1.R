#' Opis danych dla maxczas1
#' 
#' Są to dane zawierające nazwy eksponatów, przy których był odwiedzający
#' w każdym dniu, w którym było otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name maxczas1
#' @usage data(maxczas1)
#' 
NULL
