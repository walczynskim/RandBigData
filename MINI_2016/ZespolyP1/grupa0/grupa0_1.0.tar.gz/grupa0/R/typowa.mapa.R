#' Kolejność odwiedzanych eksponatów typowej ścieżki
#'
#' Funkcja typowa.mapa() rysuje wykres, na ktorym zaznaczane są eksponaty w kolejności odwiedzenia
#' wraz z liczbą odwiedzających go w danym dniu.
#'
#' @param w_rok Oznacza rok, który ma być poddany analizie.
#' @param w_mies Oznacza miesiąc, który ma być poddany analizie.
#' @param w_dzien Oznacza dzień, który ma być poddany analizie.
#' 
#' @examples \dontrun{
#' typowa.mapa("2013","01","03")}
#'
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @export
#' 
#' 
typowa.mapa <- function(w_rok, w_mies, w_dzien){
   stopifnot(paste(w_rok, w_mies, w_dzien, sep="-") %in% typowa_sciezka$data)
   #sprawdzanie, czy wprowadzone wartosci parametrów są w danych
   tab <- typowa_sciezka %>% #tworzenie tabeli danych
      tidyr::separate(data, c("rok", "miesiac", "dzien")) %>%
      group_by(kolejnosc, eksponat) %>%
      filter(rok==w_rok & miesiac==w_mies & dzien==w_dzien) %>% #filtrowanie po dacie
      summarise(n=n()) #zliczenie wystąpien danego nru eksponatu
   md <- (max(tab$n)-min(tab$n))/2 #środek między mininum a maksimum liczby odwiedzin
   ggplot(tab, aes(kolejnosc, eksponat, group=kolejnosc)) +
      geom_tile(aes(fill = n)) + 
      #geom_text(aes(fill = n, label = n)) +
      scale_fill_gradient2(low = "blue", high = "red", mid="yellow", midpoint=md)+ #kolory legendy
      labs(list(title="Kolejnosc odwiedzanych eksponatow",x="kolejnosc", 
                y="Nr eksponatu"))   
}