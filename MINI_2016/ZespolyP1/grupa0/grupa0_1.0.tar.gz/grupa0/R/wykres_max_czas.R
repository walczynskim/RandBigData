#' Wykres rozkładu czasów dla najdłuższej ścieżki.
#'
#' Funkcja wykres_max_czas() rysuje wykres czasów zwiedzającego,
#' który spędził najwięcej czasu przy eksponatach. 
#' Na osi 'y' znajdują się czasy[s], zas na osi 'x' kolejne nuemry
#' eksponatów, do których podchodził odwiedzający.
#' Nad wartościami podane są nazwy eksponatów w CNK.
#'
#' @param podaj_rok Rok, dla którego robimy wykres.
#' @param podaj_miesiac Miesiąc, dla którego robimy wykres, podajemy jako napis.
#' @param podaj_dzien Dzień, dla którego robimy wykres, domyślnie 'NA'. 
#' Wówczas wygenerowany wykres jest dla maksymalnego dnia w podanym miesiącu.
#'
#' @examples \dontrun{
#' wykres_max_czas(podaj_rok="2013",podaj_miesiac="01")
#' wykres_max_czas(podaj_rok="2012",podaj_miesiac="06",podaj_dzien="30")}
#'
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @import stringi
#' @export

wykres_max_czas<-function(podaj_rok,podaj_miesiac,podaj_dzien=NA){
  stopifnot(length(podaj_miesiac)==1, length(podaj_rok)==1, length(podaj_dzien)==1,
  podaj_rok %in% c("2012","2013"),podaj_miesiac %in% c("01","02","03","04","05","06","07","08","09","10","11","12"))
  
  maxczas<-as.data.frame(maxczas) # ramka zawierajaca czasy spedzone przy eksponatach
  maxczas1<-as.data.frame(maxczas1)# ramka zawierajaca nazwy kolejnych eksponatow
  podaj_dzien<-as.numeric(podaj_dzien)
  if(is.na(podaj_dzien)){
    # wowczas robimy wykres maksymalnego dnia w podanym miesiacu
    X<-maxczas%>%
      filter(rok==podaj_rok & miesiac==podaj_miesiac)
    Y<-maxczas1%>%
      filter(rok==podaj_rok & miesiac==podaj_miesiac)
    maxc<-which.max(as.numeric(as.vector(X$'suma_czas[s]')))
    y<-na.omit(unlist(X[maxc,7:82]))
    y<-as.numeric(as.character(y))
    x<-1:(length(y))
    trasa<-Y[maxc,7:(length(y)+6)]
  }else{
    X<-maxczas%>%
    filter(rok==podaj_rok & miesiac==podaj_miesiac & dzien==podaj_dzien)
    if(nrow(X)==0){stop("Tego dnia CNK było nieczynne!")}
    Y<-maxczas1%>%
      filter(rok==podaj_rok & miesiac==podaj_miesiac & dzien==podaj_dzien)
    y<-na.omit(unlist(X[1,7:82]))
  y<-as.numeric(as.character(y))
  x<-1:(length(y))
  trasa<-Y[1,7:(length(y)+6)]
  }
  trasa<-stri_replace_first_regex(unlist(trasa),"cnk","")
  
  ggplot(data=data.frame(y,x), aes(x,y)) +
    geom_text(col="red",label=trasa ,size=5) +
    geom_line(col="blue")+
    labs(x="Nr eksponatu", y="Czas [s]", title='Rozkład czasów dla najdłuższej ścieżki') +
    theme(plot.title = element_text(size=20, face="bold", margin = margin(10, 10, 10, 10)),
          axis.title = element_text(face="bold",size=13)) +
    scale_x_continuous(breaks=seq(1,length(y),by=2))
  
}

