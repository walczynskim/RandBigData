#' Wykres rozkładu liczby odwiedzonych eksponatów
#'
#' Funkcja rozklad rysuje wykres pudelkowy 
#' rozkładu liczby odwiedzonych eksponatów 
#' w podziale na odcinki czasowowe.
#' Do wyboru są dane zagregowane (z 2 lat), z podzialami na: 
#' rok, kwartał, miesiąc, dzień tygodnia i dzień miesiąca.
#'
#' @param okres oznacza podział danych na określone przedziały czasowe, np."zagregowane", "rok", "kwartal", "dzie? tygodnia", "miesi?c".
#' 
#' @examples rozklad("zagregowane")
#' @examples rozklad("rok")
#' @examples rozklad("dzien_tygodnia")
#' 
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @export




#nazwa okres musi byc wpisywana w cudzysłowach!
rozklad <- function(okres){ 
#poziomy: zagregowane, rok, kwartal, miesiac, dzien tygodnia, dzien miesiaca
stopifnot(okres %in% (c(colnames(rozklady), "zagregowane")))
  #id: numer uzytkownika
  #n: liczba odwiedzonych stacji
  #rok: rok zdarzenia
  #kwartal: nr kwartału
  #miesiac: nazwa miesiąca
  #dzien_tygodnia: nazwa dnia tygodnia
  #dzien_miesiaca: nr dnia miesiąca
  # Funkcja rozklad wykres pudelkowy z uwzględnieniem podziału na odcinki czasowe
  if (okres=="zagregowane"){
  
    select(rozklady, n) %>% #ten wykres jest inaczej tworzony, bo dane zagregowane, brak podzialow
    qplot(data=., x="",y=n,fill=I("blue"), colour=I("blue"), alpha=.5, outlier.shape=1, geom="boxplot")+
      #geom_boxplot(fill="blue", colour="blue", alpha=.5, outlier.shape=3)+ 
      #wykres pudełkowy o określonych właściwościach
      geom_point(stat = "summary", fun.y = "mean", size = I(6), color = I("white"))+
      #punkt oznaczający średnią
      coord_flip()+
      #odwrócenie osi
      scale_y_log10(breaks=c(1,3,7,11,19,30,50,75,110))+
      #skala logarytmiczna
      theme(legend.position="none")+
      labs(list(title="Rozklad liczby odwiedzanych eksponatow",x="", 
      y="liczba odwiedzonych eksponatow"))
    #opis osi
    }

  else { #dla reszty
    rozklady$miesiac <-factor(rozklady$miesiac,levels(rozklady$miesiac)[c(11,6,8,3,7,1,4,10,12,9,5,2)])
    rozklady$dzien_tygodnia <- factor(rozklady$dzien_tygodnia,levels(rozklady$dzien_tygodnia)[c(4,7,6,1,3,5,2)])
    #zmiana kolejnosci poziomów
    rozklady %>% select(n, o=starts_with(okres)) %>% 
    arrange(o) %>% mutate(o=factor(o))%>%
    ggplot(aes(x=o, y=n))+
    geom_boxplot(fill="blue", colour="blue", alpha=.5, outlier.shape=19)+
    #wykres pudełkowy o określonych właściwościach
    stat_summary(fun.y = mean, geom="point",colour=I("white"), size=3)+
    #punkt oznaczający średnią
    coord_flip()+
    #odwrócenie osi
    scale_y_log10(breaks=c(1,3,7,11,19,30,50,75,110))+
    #skala logarytmiczna
    theme(legend.position="none")+
    #brak legendy
    labs(list(title="Rozklad liczby odwiedzanych eksponatow", 
    x=okres, y="liczba odwiedzonych eksponatow"))
    #opis osi
    }
}

