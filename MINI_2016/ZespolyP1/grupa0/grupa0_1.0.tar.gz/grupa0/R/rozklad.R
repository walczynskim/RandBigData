#' Wykres rozkladu czasow dla najdluzszej sciezki.
#'
#' Funkcja wykres_max_czas() rysuje wykres czasow uzytkownika,
#' ktory spedzil najwiecej czasu przy eksponatach. 
#' Na osi 'y' znajduja sie czasy[s], zas na osi 'x' kolejne numery
#' stacji do ktorych podchodzil uzytkownik.
#' Nad wartosciami podane sa numery stacji w CNK.
#'
#' @param okres Przedzial czasu dla ktorego rysujemy wykres, np."zagregowane", "rok", "kwartal", "dzien_tygodnia", "miesiac","dzien_miesiaca".
#' 
#' @examples rozklad("zagregowane")
#' @examples rozklad("rok")
#' @examples rozklad("dzien_ miesiaca")
#' 
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @export




#nazwa okres musi byc wpisywana w cudzysłowach!
rozklad <- function(okres){ #poziomy: zagregowane, rok, kwartal, miesiac, dzien tygodnia, dzien miesiaca
  
  rozklady<-data.frame(rozklady)
  rozklady$miesiac <-factor(rozklady$miesiac,levels(rozklady$miesiac)[c(11,6,8,3,7,1,4,10,12,9,5,2)])
  rozklady$dzien_tygodnia <- factor(rozklady$dzien_tygodnia,levels(rozklady$dzien_tygodnia)[c(4,7,6,1,3,5,2)])
  stopifnot(okres %in% (c(colnames(rozklady), "zagregowane")))
  #id: numer uzytkownika
  #n: liczba odwiedzonych stacji
  #rok: rok zdarzenia
  #kwartał: nr kwartału
  #miesiąc: nazwa miesiąca
  #dzień tygodnia: nazwa dnia tygodnia
  #dzień miesiąca: nr dnia miesiąca
  # Funkcja rozklad rysuje wykres skrzypcowy z nałożonym pudełkowym w zależności od wybranego okresu
  
  if (okres=="zagregowane"){ #ten wykres jest inaczej tworzony, bo dane zagregowane
    qplot("", data = rozklady , geom="violin", y=n, fill=I("orange"), alpha=.5,color=I(7))+
    #wykres skrzypcowy
    geom_boxplot(width=.25, notch=FALSE, colour=I("orange"), fill=(I("orange")),alpha=.75, outlier.colour = "black")+
    #wykres pudełkowy o określonych właściwościach
    geom_point(stat = "summary", fun.y = "mean", size = I(2.2), color = I("white"))+
    #punkt oznaczający średnią
    coord_flip()+
    #odwrócenie osi
      theme(legend.position="none", text=element_text(size=10))+
      scale_y_continuous(breaks=(0:11)*10)+
      labs(list(title="Rozklad liczby odwiedzanych stacji", x=okres, y="Liczba odwiedzonych stacji"))
    #znaczniki na osi x de facto
    #opis osi
  }else {#dla reszty
    okresy <- rozklady[,okres] #wybranie interesującej kolumny
    ggplot(rozklady, aes(factor(okresy), n, fill=factor(okresy), colour=okresy, alpha=.5))+geom_violin(trim=TRUE) +
    #wykres skrzypcowy
    geom_boxplot(width=.3, notch=FALSE, aes(colour=okresy), outlier.colour = "black")+
    #wykres pudełkowy z kolorem wartości odstających
    geom_point(stat = "summary", fun.y = "mean", size = I(2.2), colour = I("white"))+
    #punkt ze średnią
    theme(legend.position="none" #,text=element_text(size=30)
          )+
    #wielkośc fontów i brak liter
    coord_flip()+
    #odwrócenie osi
    scale_y_continuous(breaks=(0:11)*10)+
    #podziałka
    labs(list(title="Rozklad liczby odwiedzanych stacji", x=okres, y="Liczba odwiedzonych stacji"))
    #opis osi
  }
  
#dla dni miesiaca powinny byc przedziały maks. 10-elementowe Kolejny if i z factora wyciągamy, co chcemy

}


