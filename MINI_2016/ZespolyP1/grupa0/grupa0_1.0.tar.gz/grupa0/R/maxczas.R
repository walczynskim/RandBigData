#' Opis danych dla maxczas
#' 
#' Są to dane zawierające czasy spędzone przez użytkowników przy każdym eksponacie
#' w każdym dniu, w którym było otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name maxczas
#' @usage data(maxczas)
#' 
NULL
