#' Opis danych dla maxczas
#' 
#' S� to dane zawieraj�ce czasy sp�dzone przez u�ytkownik�w przy ka�dym eksponacie
#' w ka�dym dniu, w kt�rym by�o otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name maxczas
#' @usage data(maxczas)
#' 
NULL
