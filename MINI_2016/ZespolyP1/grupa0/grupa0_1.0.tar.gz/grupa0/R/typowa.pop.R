#' Najbardziej popularne i najmniej popularne eksponaty w danym dniu z liczba odwiedzajacych.
#'
#' Funkcja ta zwraca w postaci tabeli danych n najbardziej popularnych badz najmniej popularnych
#' eksponaty danym dniu wraz z liczba odwiedzajaych.
#' 
#'
#' @param dzien oznacza date, w ktorym zarejestrowano dane. Date trzeba pisac w formacie "%Y-%m-%d"
#' @param ile oznacza, ile wieszy funkcji ma byc wyswietlonych. Domyslnie 5.
#' @param kraniec oznacza, czy najbardziej popularne ("glowka"), czy najmniej popularne ("stopka"). Domyslnie "glowka"
#'
#' @examples typowa.pop("2012-01-03")
#' @examples typowa.pop("2012-01-03",10)
#' @examples typowa.pop("2012-01-03",10,"glowka")
#' @examples typowa.pop("2012-01-03",10,"stopka")
#'
#' @export
typowa.pop <- function(dzien, ile=5, kraniec="glowka"){
stopifnot(kraniec %in% c("glowka", "stopka"))
stopifnot(ile > 0)
stopifnot(dzien %in% typowa_sciezka$data)
typowa_sciezka <- typowa_sciezka[typowa_sciezka$data==dzien,]
tab<- table(typowa_sciezka$eksponat)
tab <- data.frame(tab)
colnames(tab) <- c("eksponat", "n")
tab <- tab[order(-tab$n),]
if (kraniec=="glowka"){
pop <- head(tab, ile)
print(pop)
}
else {
pop <- tail(tab, ile)
print(pop)
}
}
