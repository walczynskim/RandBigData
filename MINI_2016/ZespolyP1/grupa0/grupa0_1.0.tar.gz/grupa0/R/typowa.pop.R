#' Najbardziej popularne i najmniej popularne eksponaty
#'
#' Funkcja typowa.pop() ta zwraca w postaci tabeli danych n najbardziej popularnych bądź najmniej popularnych
#' eksponatów w danym dniu wraz z liczbą odwiedzających je.
#' 
#'
#' @param w_rok Oznacza rok, który ma być poddany analizie.
#' @param w_mies Oznacza miesiąc, który ma być poddany analizie.
#' @param w_dzien Oznacza dzień, który ma być poddany analizie.
#' @param ile Oznacza, ile wieszy funkcji ma byc wyświetlonych. Domyslnie 5.
#' @param kraniec Oznaczana najbardziej popularne ("glowka") bądż najmniej popularne ("stopka"). Domyslnie "glowka".
#'
#' @examples \dontrun{
#' typowa.pop("2012","01","03")
#' typowa.pop("2012","01","03",10,"stopka")}
#' 
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @export

typowa.pop <- function(w_rok, w_mies, w_dzien, ile=5, kraniec="glowka"){
   stopifnot(paste(w_rok, w_mies, w_dzien, sep="-") %in% typowa_sciezka$data,
             ile > 0, kraniec %in% c("glowka", "stopka"))
   #sprawdzanie, czy wprowadzone wartosci parametrów są w danych, 
   tab <- typowa_sciezka %>% tidyr::separate(data, c("rok", "miesiac", "dzien")) %>%
      filter(rok==w_rok & miesiac==w_mies & dzien==w_dzien) %>%
      group_by(eksponat) %>% summarise(n=n()) %>% arrange(desc(n))
   #wybor po roku, miesiacuo dniu, grupowanie po eksponat, 
   #zliczenie kazdego poziomu, uporzadkowanie malejaco
   if (kraniec=="glowka"){
      pop <- head(tab, ile)
      print(pop)
   }
   else {
      pop <- tail(tab, ile)
      print(pop)
   }
}
