#' Najczesciej odwiedzany eksponat
#'
#' Funkcja wordcloud_urz() rysuje dla danego czasu wordcloud, 
#' czyli chmurę nazw eksponatów, gdzie wielkość odpowiada za częstość odwiedzin
#' eksponatu.
#'
#' @param ramka Zbior danych, z którego będą wybierane eksponaty.
#' @param in_rok Rok, dla którego mają być wybierane eksponaty.
#' @param in_miesiac Miesiąc, dla którego mają być wybierane eksponaty.
#'
#' @examples \dontrun{
#' wordcloud_urz(urz,in_miesiac = "03")}
#'
#' @import dplyr
#' @import magrittr
#' @import wordcloud
#' @export

wordcloud_urz<-function(ramka=urz,in_miesiac="01",in_rok="2012"){
   stopifnot(in_rok %in% c("2012","2013"))
   stopifnot(in_miesiac %in% c("01","02","03","04","05","06","07","08","09","10","11","12"))
   
   #library(wordcloud)
   #library(dplyr)
   ramka<-data.frame(ramka)
   dane<-ramka %>% filter(rok==in_rok , mies==in_miesiac) %>% group_by(X5) %>% summarise(ile_cale=sum(ile))

   wordcloud(words = dane$X5, freq = dane$ile_cale, min.freq = 1,scale=c(3,0.3),
             max.words=200, random.order=FALSE, rot.per=0.35, 
             colors=rainbow(5) )
}
