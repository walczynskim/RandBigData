#' Opis danych z CNK typowa_sciezka
#' 
#' Dane potrzebne do wygenerowania wykresu typowej sciezki.
#' 
#' @docType data
#' @keywords datasets
#' @name typowa_sciezka
#' @usage data(typowa_sciezka)
#' 
NULL