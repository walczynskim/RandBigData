#' Opis danych dla rozklady
#' 
#' Są to dane z lat 2012-2013, które zawierają id odwiedzających, którzy logowali się 
#' ośmiokrotnie do eksponatów (mogli logować sie do tego samego).
#' Przy id podano także, ekponaty wraz kolejnością logowania się 
#' oraz datę zdarzenia.
#' 
#' @docType data
#' @keywords datasets
#' @name typowa_sciezka
#' @usage data(typowa_sciezka)
#' 
NULL