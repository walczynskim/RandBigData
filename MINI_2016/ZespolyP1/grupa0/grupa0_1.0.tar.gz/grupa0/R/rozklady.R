#' Opis danych dla rozklady
#' 
#' S� to dane zawieraj�ce logi u�ytkownik�w oraz dane o ka�dym dniu, 
#' w kt�rym by�o otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name rozklady
#' @usage data(rozklady)
#' 
NULL
