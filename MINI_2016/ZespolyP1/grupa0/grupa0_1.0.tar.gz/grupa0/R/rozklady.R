#' Opis danych dla rozklady
#' 
#' Są to dane zawierające liczbę odwiedzonych eksponatów (n) przez każdego logującego się
#' (id, unikatowego w danyn dniu) z lat 2012-2013. 
#' Prócz id i n podane są także:
#' rok, kwartał, miesiąc, dzień tygodnia i dzień miesiąca zdarzenia.
#' 
#' @docType data
#' @keywords datasets
#' @name rozklady
#' @usage data(rozklady)
#' 
NULL
