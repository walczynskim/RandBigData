#' Opis danych z CNK urz
#' 
#' Dane urz zawierają dane z lat 2012 i 2013 o częstością używania
#' danych eksponatów.
#' 
#' @docType data
#' @keywords datasets
#' @name urz
#' @usage data(urz)
#' 
NULL