#' Opis danych z CNK urz
#' 
#' Dane ile_razy_urz zawieraj� dane z lat 2012 i 2013 o cz�sto��i u�ywania
#' danych eksponat�w.
#' 
#' @docType data
#' @keywords datasets
#' @name urz
#' @usage data(urz)
#' 
NULL