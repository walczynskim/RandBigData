#' Kolejnosc odwiedzanych stacji w typowej sciezce
#'
#' Funkcja typowa.dzien rysuje wykres, na ktorym zaznaczane sa stacje w kolejnosci odwiedzenia
#' w podziale od id odwiedzajacego.
#'
#' @param dzien oznacza date, w ktorym zarejestrowano dane. Date trzeba pisac w formacie "%Y-%m-%d"
#' @example typowa.dzien("2013-01-03")
#'
#' @export
typowa.dzien <- function(dzien){
stopifnot(dzien %in% typowa_sciezka$data)

typ <- typowa_sciezka[typowa_sciezka$data==dzien,]
ggplot(typ, aes(typ$kolejnosc, y = typ$eksponat, color = typ$id, group = typ$id)) + 
     geom_point() + geom_line()+
  guides(fill=guide_legend(title="id"))+
  labs(x="kolejnosc odwiedzania", y="Nr eksponatu")+
  ggtitle(paste0("Kolejnosc eksponatow typowej sciezki dnia ", dzien))
}