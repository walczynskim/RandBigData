#' Opis danych z CNK sciezka_eksponat
#' 
#' Dane sciezka_eksponat zawierają wszystkie maksymalne ścieżki pod względem
#' liczby eksponatów w każdym dniu, w którym było otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name sciezka_eksponat
#' @usage data(sciezka_eksponat)
#' 
NULL