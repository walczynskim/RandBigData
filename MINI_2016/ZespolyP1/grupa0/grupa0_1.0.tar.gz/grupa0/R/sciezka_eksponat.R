#' Opis danych z CNK sciezka_eksponat
#' 
#' Dane sciezka_eksponat zawieraj� wszystkie maksymalne �cie�ki pod wzgl�dem
#' liczby eksponat�w w ka�dym dniu, w kt�rym by�o otwarte CNK z lat 2012 i 2013.
#' 
#' @docType data
#' @keywords datasets
#' @name sciezka_eksponat
#' @usage data(sciezka_eksponat)
#' 
NULL