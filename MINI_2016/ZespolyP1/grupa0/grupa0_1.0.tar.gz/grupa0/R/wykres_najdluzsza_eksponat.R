#' Najdluższa ścieżka dla zadanego czasu
#'
#' Funkcja wykres_najdluzsza_eksponat() rysuje najdłuższe (pod względem liczby eksponatów)
#' ścieżki dla zadanego czasu (funkcja rysuje maksymalnie 3 sciezki).
#'
#' @param ramka Zbiór danych, z którego bede wybierane ścieżki.
#' @param in_rok Rok, dla którego mają być pokazane ścieżki.
#' @param in_miesiac Miesiąc, dla którego mają być pokazane ścieżki.
#' @param in_dzien Dzień, dla którego mają być pokazane ścieżki.
#'
#' @examples \dontrun{
#' wykres_najdluzsza_eksponat(sciezka_eksponat,in_rok="2012",in_miesiac="07")}
#'
#' @import dplyr
#' @import magrittr
#' @import ggplot2
#' @import stringi
#' @import reshape2
#' @export


wykres_najdluzsza_eksponat<- function(ramka=sciezka_eksponat,in_rok="wszystkie",in_miesiac="wszystkie",in_dzien="wszystkie"){
  stopifnot(in_rok %in% c("2012","2013","wszystkie"))
  stopifnot(in_miesiac %in% c("01","02","03","04","05","06","07","08","09","10","11","12","wszystkie"))
  stopifnot(in_dzien %in% c(1:31) | in_dzien=="wszystkie")
  
  #ramka<-data.frame(ramka)
  if (in_rok=="wszystkie") {in_rok<-"\\p{N}"}
  if (in_miesiac=="wszystkie") {in_miesiac<-"\\p{N}"}
  if (in_dzien=="wszystkie") {in_dzien<-"\\p{N}"}
  
  # kolejnosc eksponatow
  kolej_dawa_lata<-c("cnk02a","cnk02b","cnk03","cnk04","cnk05","cnk06","cnk07","cnk09",
                     "cnk10","cnk11","cnk13","cnk15","cnk16","cnk17","cnk19a","cnk19b","cnk20",
                     "cnk21","cnk66","cnk67","cnk68","cnk100","cnk12","cnk32","cnk34","cnk39",
                     "cnk40","cnk41","cnk42a","cnk43","cnk44","cnk45","cnk49",
                     "cnk54","cnk55","cnk56","cnk57","cnk58a","cnk58b","cnk59","cnk60","cnk61","cnk62",
                     "cnk69","cnk71","cnk72","cnk73","cnk79","cnk30","cnk37","cnk38","cnk46a","cnk46b",
                     "cnk47","cnk48a","cnk48b","cnk48c","cnk48d","cnk48e","cnk52","cnk53","cnk65",
                     "cnk70a","cnk70b","cnk70c","cnk74a","cnk75","cnk76","cnk18","cnk22",
                     "cnk23","cnk24","cnk25","cnk26","cnk27","cnk28","cnk29a","cnk31a","cnk31b",
                     "cnk31c","cnk31d","cnk78a","cnk78b","cnk36","cnk42b","cnk63a")
  
  macierz <- ramka %>% filter( stri_detect_regex(ramka$miesiac, pattern = in_miesiac) == TRUE, 
                               stri_detect_regex(ramka$rok, pattern = in_rok) == TRUE,
                               stri_detect_regex(ramka$dzien, pattern = paste0("^",in_dzien,"$")) == TRUE) %>%
    arrange(desc(dlugosc))  %>% head(n=3)
  
  if (nrow(macierz)==0) {stop("Brak danych dla zadanych wartość!")}
  
  macierz<-macierz[,-c(1:5,7)]   
  rownames(macierz)<-macierz$id
  macierz<-macierz[,-1]
  macierz<-t(macierz)
  
  #funkcja pomocnicza
  all_na<-function(df){
    df_na<-is.na(df)
    wektor<-apply(df_na, 1, all)
    df<-df[!wektor,]
    return(df)
  }
  
  macierz_zredukowana<-all_na(macierz)
  melt_macierz<-melt(macierz_zredukowana)
  
  #melt_macierz$value<-factor(melt_macierz$value,levels=kolej_dawa_lata)
  
  if (ncol(melt_macierz)==1){
    macierz_zredukowana<-data.frame(macierz_zredukowana)
    colnames(macierz_zredukowana)<-colnames(macierz)
    melt_macierz<-cbind(melt_macierz,nr=seq_len(nrow(melt_macierz)),Id=colnames(macierz))
    
    gplot<- ggplot(melt_macierz,aes(x=nr,y=value,group=Id)) + geom_path(size=0.7,color="cornflowerblue") +
      scale_x_continuous(breaks = seq(0,nrow(melt_macierz),2)) +
      labs(x="Kolejność eksponatów",y="Eksponat",title="Ścieżki z największą liczbą odwiedzonych eksponatów" ) +
      geom_smooth(se=FALSE,linetype=2,color="cornflowerblue")
  } else{
    melt_macierz$Var2<-as.character(melt_macierz$Var2)
    colnames(melt_macierz)[2]<-"Id"
    melt_macierz$value<-ordered(melt_macierz$value,levels=kolej_dawa_lata)
    melt_macierz$Id<-as.factor(melt_macierz$Id)
    
    gplot<-ggplot(melt_macierz,aes(x=Var1,y=value,group=Id)) + geom_path(size=0.7,aes(color=Id)) +
      scale_x_continuous(breaks = seq(0,nrow(melt_macierz),2)) +
      labs(x="Kolejność eksponatów",y="Eksponat",title="Ścieżki z największą liczbą odwiedzonych eksponatów" ) + 
      geom_smooth(se=FALSE,linetype=2,aes(color=Id))
  } 
  return(list(gplot,macierz_zredukowana))
}
